const DEFAULTS = { minDelay: 30, maxDelay: 120, useLetter: false, letter: '', letterRules: [], bumpResume: true, clearRejections: true, captchaService: 'rucaptcha', polzaKey: '', captchaBreak: 10 };
const $ = (id) => document.getElementById(id);

// ---------- плавные блоки ----------
const setOpen = (id, open) => $(id).classList.toggle('open', !!open);

// Полоса с текстом: при закрытии текст не стираем, чтобы он плавно уехал вместе с полосой.
function showBanner(foldId, el, text) {
  if (text) el.textContent = text;
  setOpen(foldId, !!text);
}
const showMsg = (text) => showBanner('msgFold', $('msg'), text);

const syncLetterState = () => {
  const on = $('useLetter').checked;
  $('letter').disabled = !on;
  setOpen('letterFold', on);
  setOpen('letterOffFold', !on);
};

// Видно в заголовке, когда раздел «Перед стартом» свёрнут.
const syncPrestartSummary = () => {
  const on = [$('bumpResume').checked && 'резюме', $('clearRejections').checked && 'отказы'].filter(Boolean);
  // Подсказка в заголовке свёрнутого раздела.
  $('prestartSummary').textContent = on.length ? on.join(' + ') : 'выключено';
};

// Видно в заголовке, когда раздел «Пауза» свёрнут.
const syncPauseSummary = () => {
  $('pauseSummary').textContent = `${$('minDelay').value || '?'}–${$('maxDelay').value || '?'} сек`;
  // Очень короткие паузы hh.ru замечает: растёт шанс капчи и блокировки.
  const fast = Math.max(1, parseInt($('maxDelay').value, 10) || 0) < 10;
  $('pauseWarn').hidden = !fast;
};

// Показывает поле ключа только для выбранного сервиса капчи.
const SERVICE_NAMES = { rucaptcha: 'RuCaptcha', qwen: 'Нейросеть' };
const syncCaptchaService = () => {
  const qwen = $('captchaService').value === 'qwen';
  setOpen('rucaptchaKeyRow', !qwen);
  setOpen('polzaKeyRow', qwen);
  // RuCaptcha — общий ключ на сервере, свой нужен только нейросети
  const keyNote = !qwen ? 'общий ключ' : $('polzaKey').value.trim() ? 'ключ задан' : 'нет ключа';
  $('captchaSummary').textContent = `${SERVICE_NAMES[$('captchaService').value] || ''} · ${keyNote}`;
};

// ---------- сворачиваемые разделы ----------
// Открыт ли раздел по умолчанию. «Капча» нужна редко — свёрнута. Выбор пользователя помним в этом окне.
// «Лицензия» свёрнута, пока ключ действует; без него раскрывается сама (renderLicense).
const SECTIONS = { license: false, pause: true, prestart: true, letter: true, captcha: false, log: true };

function setSectionOpen(name, open, remember = true) {
  const btn = document.querySelector(`[data-section-toggle="${name}"]`);
  btn.setAttribute('aria-expanded', String(open));
  setOpen(btn.getAttribute('aria-controls'), open);
  if (remember) try { localStorage.setItem(`open:${name}`, open ? '1' : '0'); } catch {}
}

function initSections() {
  for (const [name, byDefault] of Object.entries(SECTIONS)) {
    let open = byDefault;
    try {
      const saved = localStorage.getItem(`open:${name}`);
      if (saved !== null) open = saved === '1';
      else if (name === 'captcha') open = localStorage.getItem('captchaOpen') === '1'; // ключ версии 1.8.3
    } catch {}
    setSectionOpen(name, open, false);
    document.querySelector(`[data-section-toggle="${name}"]`).addEventListener('click', (e) => {
      setSectionOpen(name, e.currentTarget.getAttribute('aria-expanded') !== 'true');
    });
  }
}

// Та же строка, что и на панели на странице: до какого времени действует суточный лимит hh.ru.
const limitLine = (l) => {
  if (!l || l.until <= Date.now()) return '';
  const t = new Date(l.until).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  return `Лимит 24 ч до ${t}${l.exact ? '' : ' (не позже)'}`;
};

async function loadSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  const s = { ...DEFAULTS, ...(settings || {}) };
  $('minDelay').value = s.minDelay;
  $('maxDelay').value = s.maxDelay;
  $('useLetter').checked = s.useLetter;
  $('letter').value = s.letter;
  renderRules(s.letterRules || []);
  $('captchaService').value = s.captchaService || 'rucaptcha';
  $('polzaKey').value = s.polzaKey || '';
  $('captchaBreak').value = s.captchaBreak ?? DEFAULTS.captchaBreak;
  $('bumpResume').checked = !!s.bumpResume;
  $('clearRejections').checked = !!s.clearRejections;
  syncPrestartSummary();
  syncLetterState();
  syncPauseSummary();
  syncCaptchaService();
}

async function saveSettings() {
  // Минимум — 1 секунда. Пустое поле — значение по умолчанию.
  const sec = (id, byDefault) => {
    const n = parseInt($(id).value, 10);
    return Number.isFinite(n) ? Math.max(1, n) : byDefault;
  };
  let min = sec('minDelay', DEFAULTS.minDelay);
  let max = sec('maxDelay', DEFAULTS.maxDelay);
  if (max < min) [min, max] = [max, min];
  // Пустое/некорректное поле — значение по умолчанию; явный 0 — перерыв отключён.
  const brk = parseInt($('captchaBreak').value, 10);
  const captchaBreak = Number.isFinite(brk) && brk >= 0 ? brk : DEFAULTS.captchaBreak;
  await chrome.storage.local.set({
    settings: {
      minDelay: min,
      maxDelay: max,
      useLetter: $('useLetter').checked,
      letter: $('letter').value,
      letterRules: collectRules(),
      captchaService: $('captchaService').value,
      polzaKey: $('polzaKey').value.trim(),
      captchaBreak,
      bumpResume: $('bumpResume').checked,
      clearRejections: $('clearRejections').checked,
    },
  });
}

// ---------- счётчики: плавно докручиваются до нового значения ----------
const shown = {};
function setCount(id, value) {
  const el = $(id);
  const from = shown[id] ?? 0;
  shown[id] = value;
  if (from === value) {
    el.textContent = value;
    return;
  }
  const tile = el.closest('.stat');
  tile.classList.remove('bump');
  void tile.offsetWidth; // перезапуск анимации
  tile.classList.add('bump');
  const start = performance.now();
  const dur = 550;
  const step = (now) => {
    const k = Math.min(1, (now - start) / dur);
    el.textContent = Math.round(from + (value - from) * (1 - (1 - k) ** 3));
    if (k < 1 && shown[id] === value) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

// ---------- журнал: новые записи въезжают, старые не перерисовываются ----------
const fmtTime = (t) => {
  const d = new Date(t);
  const time = d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  return d.toDateString() === new Date().toDateString()
    ? time
    : `${d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' })} ${time}`;
};

function makeEntry(e, key) {
  const row = document.createElement('div');
  row.className = `entry ${e.kind || 'info'}`;
  row.dataset.key = key;
  const time = document.createElement('span');
  time.className = 'time';
  time.textContent = fmtTime(e.t);
  const text = document.createElement('span');
  text.className = 'text';
  const m = /^([✔↷✖])\s*/.exec(e.msg || '');
  if (m) {
    const mark = document.createElement('span');
    mark.className = 'mark';
    mark.textContent = m[1];
    text.append(mark, e.msg.slice(m[0].length));
  } else {
    text.textContent = e.msg;
  }
  row.append(time, text);
  return row;
}

let logReady = false;
function renderLog(log) {
  const list = $('log');
  const items = log.slice(-100).reverse();
  const existing = new Map([...list.children].map((el) => [el.dataset.key, el]));
  const rows = items.map((e) => {
    const key = `${e.t}|${e.msg}`;
    let row = existing.get(key);
    if (!row) {
      row = makeEntry(e, key);
      if (logReady) {
        row.classList.add('enter');
        // Иначе анимация повторялась бы при каждом переносе строки в списке.
        row.addEventListener('animationend', () => row.classList.remove('enter'), { once: true });
      }
    }
    return row;
  });
  list.replaceChildren(...rows);
  logReady = true;
  $('logCount').textContent = log.length ? String(log.length) : '';
  $('logEmpty').hidden = log.length > 0;
}

// ---------- состояние ----------
const STATE_LABELS = { idle: 'Остановлено', run: 'Работает', wait: 'Пауза', stale: 'Прервано' };

async function render() {
  const { active, run, log = [], limit, chore_bump: bump, chore_clear: clear, license } =
    await chrome.storage.local.get(['active', 'run', 'log', 'limit', 'chore_bump', 'chore_clear', 'license']);
  const lic = HHLicense.status(license);
  // «Старт» доступен всегда: он перезапускает работу в текущей вкладке, даже если
  // в памяти остался «запущен» от вкладки, которую перезагрузили или закрыли.
  // Кроме одного случая — ключ ещё не введён. Истёкший или отозванный ключ «Старт» проверит заново.
  $('start').disabled = lic.reason === 'no_key';
  renderLicense(license, lic);
  $('stop').disabled = !active;
  // Отсчёт перерыва обновляет run раз в 5 с. Если обновлений давно нет — работа прервалась.
  const lastAlive = Math.max(run?.heartbeat || 0, run?.breakUntil || 0);
  const stale = !!active && Date.now() - lastAlive > 3 * 60 * 1000;
  showBanner('hintFold', $('hint'), stale
    ? 'Работа прервалась: вкладку перезагрузили, закрыли или обновили расширение. Нажмите «Старт».'
    : '');

  const state = !active ? 'idle' : stale ? 'stale' : /^(Следующее действие|Перерыв)/.test(run?.status || '') ? 'wait' : 'run';
  document.body.dataset.state = state;
  $('pillText').textContent = STATE_LABELS[state];

  for (const k of ['applied', 'skipped', 'errors', 'earlier']) setCount(k, run?.[k] ?? 0);
  showBanner('limitFold', $('limit'), limitLine(limit));
  // Статус пишет скрипт на странице. Когда запуск не идёт, старая строка — уже история,
  // показывать её не нужно: что было, видно в журнале.
  $('status').textContent = active ? run?.status || 'Запуск…' : 'Не запущено';
  $('resetCaptchaBreak').disabled = !run?.breakUntil;
  // Что делают вкладки-помощники прямо сейчас.
  const chores = [];
  if (bump?.state === 'running') chores.push('поднимаю резюме');
  if (clear?.state === 'running') {
    const pct = clear.expected ? ` (${Math.min(100, Math.floor((clear.total / clear.expected) * 100))}%)` : '';
    chores.push(`удаляю отказы${clear.total ? `: ${clear.total}${clear.expected ? ` из ${clear.expected}` : ''}${pct}` : ''}`);
  }
  $('chores').textContent = chores.length ? `В отдельной вкладке: ${chores.join(', ')}` : '';
  renderLog(log);
}

// ---------- лицензия (license.js) ----------
let licenseOpened = false;
function renderLicense(license, st) {
  $('userId').textContent = license?.userId || '…';
  $('buyLink').href = HHLicense.buyUrl(license?.userId);
  const sum = $('licenseSummary');
  sum.textContent = st.ok ? `до ${HHLicense.fmtDate(st.until)}` : st.reason === 'no_key' ? 'нет ключа' : 'не действует';
  sum.className = `summary ${!st.ok ? 'bad' : st.daysLeft <= 3 ? 'warn' : 'good'}`;

  // Полоса над кнопками: без лицензии — что делать, в последние 3 дня — когда закончится.
  let banner = '';
  if (!st.ok) banner = HHLicense.message(st, 'в разделе «Лицензия» ниже');
  else if (st.daysLeft <= 3) banner = `Лицензия заканчивается ${HHLicense.fmtDate(st.until)} (осталось ${st.daysLeft} дн.) — попросите у продавца новый ключ.`;
  $('licBanner').className = `banner ${st.ok ? 'warn' : 'danger'}`;
  showBanner('licBannerFold', $('licBanner'), banner);

  const info = [];
  if (st.ok) info.push(`Действует до ${HHLicense.fmtDate(st.until)}, осталось ${st.daysLeft} дн. Новый ключ продлевает срок.`);
  if (st.error) info.push(`Последняя проверка ключа не удалась: ${st.error}.`);
  $('licenseInfo').textContent = info.join(' ');

  // Без лицензии раздел раскрывается сам — один раз за открытие окна, дальше решает пользователь.
  if (!st.ok && !licenseOpened) {
    licenseOpened = true;
    setSectionOpen('license', true, false);
  }
}

function sayLicense(text, kind = '') {
  $('licenseMsg').textContent = text;
  $('licenseMsg').className = `note ${kind}`;
}

async function activateLicense() {
  const key = $('licenseKey').value.trim();
  if (!key) return sayLicense('Вставьте ключ, который прислал продавец.', 'bad');
  $('activate').disabled = true;
  sayLicense('Проверяю ключ…');
  let res = null;
  try {
    res = await chrome.runtime.sendMessage({ type: 'licenseActivate', key });
  } catch {}
  $('activate').disabled = false;
  if (!res) return sayLicense('Расширение не ответило — попробуйте ещё раз.', 'bad');
  if (!res.ok) return sayLicense(res.error, 'bad');
  $('licenseKey').value = '';
  sayLicense(res.already ? 'Этот ключ уже активирован.' : `Ключ принят: доступ до ${HHLicense.fmtDate(res.status.until)}.`, 'good');
}

$('activate').addEventListener('click', activateLicense);
$('licenseKey').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    activateLicense();
  }
});

$('copyUserId').addEventListener('click', async () => {
  const id = $('userId').textContent;
  if (!/\w/.test(id)) return;
  try {
    await navigator.clipboard.writeText(id);
    $('copyText').textContent = 'Скопировано';
  } catch {
    getSelection().selectAllChildren($('userId')); // скопировать можно будет вручную
  }
  setTimeout(() => ($('copyText').textContent = 'Копировать'), 1500);
});

// ---------- кнопки ----------
$('start').addEventListener('click', async () => {
  showMsg('');
  if ($('useLetter').checked && !HHLetter.hasAnyText({ letter: $('letter').value, letterRules: collectRules() })) {
    showMsg('Письма включены, но нет ни одного текста письма.');
    return;
  }
  await saveSettings();
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try {
    const res = await chrome.tabs.sendMessage(tab.id, { type: 'start' });
    if (!res?.ok) showMsg(res?.error || 'Не удалось запустить');
  } catch {
    showMsg('Откройте страницу поиска вакансий на hh.ru (если она уже открыта — обновите её).');
  }
});

$('stop').addEventListener('click', async () => {
  // stopChores закрывает и вкладки-помощники (резюме, отказы).
  await chrome.storage.local.set({ active: false, stopChores: Date.now() });
});

// Обнуляет перерыв после капчи: content script увидит это в storage и продолжит, не дожидаясь конца.
$('resetCaptchaBreak').addEventListener('click', async () => {
  const { run } = await chrome.storage.local.get('run');
  if (!run?.breakUntil) return;
  // Статус меняем сами: если скрипт на странице уже не работает, обновить строку больше некому.
  // Когда он работает, он тут же перепишет её своим отсчётом или следующим действием.
  await chrome.storage.local.set({ run: { ...run, breakUntil: 0, status: 'Таймер капчи сброшен' } });
});

// ---------- очистка журнала с вопросом про счётчики ----------
let lastFocus = null;
function openDialog() {
  lastFocus = document.activeElement;
  const d = $('clearDialog');
  d.classList.add('open');
  d.setAttribute('aria-hidden', 'false');
  setTimeout(() => $('clearAll').focus(), 50);
}
function closeDialog() {
  const d = $('clearDialog');
  d.classList.remove('open');
  d.setAttribute('aria-hidden', 'true');
  lastFocus?.focus?.();
}

async function clearLog(withCounters) {
  const patch = { log: [] };
  if (withCounters) {
    const { run } = await chrome.storage.local.get('run');
    if (run) patch.run = { ...run, applied: 0, skipped: 0, errors: 0, earlier: 0 };
    // Сигнал скрипту на странице: у него свои копии счётчиков, иначе он вернёт старые значения.
    patch.resetCounters = Date.now();
  }
  closeDialog();
  await chrome.storage.local.set(patch);
}

$('clear').addEventListener('click', openDialog);
$('clearAll').addEventListener('click', () => clearLog(true));
$('clearLogOnly').addEventListener('click', () => clearLog(false));
for (const el of document.querySelectorAll('[data-close]')) el.addEventListener('click', closeDialog);
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && $('clearDialog').classList.contains('open')) {
    e.preventDefault();
    closeDialog();
  }
});

// ---------- проверка страницы ----------
const MARKS = { ok: '✓', warn: '!', fail: '✕' };

function showCheck(items) {
  $('checkList').replaceChildren(...items.map((it, i) => {
    const li = document.createElement('li');
    li.className = `check-item ${it.status}`;
    li.style.setProperty('--i', i);
    const mark = document.createElement('span');
    mark.className = 'check-mark';
    mark.textContent = MARKS[it.status] || '?';
    const body = document.createElement('div');
    const title = document.createElement('div');
    title.className = 'check-title';
    title.textContent = it.title;
    const detail = document.createElement('div');
    detail.className = 'check-detail';
    detail.textContent = it.detail || '';
    body.append(title, detail);
    li.append(mark, body);
    return li;
  }));
  const fails = items.filter((i) => i.status === 'fail').length;
  const warns = items.filter((i) => i.status === 'warn').length;
  const summary = $('checkSummary');
  summary.className = fails ? 'bad' : warns ? '' : 'good';
  summary.textContent = fails
    ? `Найдены проблемы: ${fails}. Без их исправления отклики не пойдут.`
    : warns ? `Работать можно, но есть замечания: ${warns}.` : 'Всё в порядке — расширение видит всё, что нужно.';
}

async function runSelfCheck() {
  $('checkSummary').className = '';
  $('checkSummary').textContent = 'Проверяю…';
  $('checkList').replaceChildren();
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let res = null;
  try {
    res = await chrome.tabs.sendMessage(tab.id, { type: 'selfcheck' });
  } catch {}
  if (!res?.ok) {
    showCheck([{ status: 'fail', title: 'Скрипт на странице', detail: res?.error
      ? `ошибка проверки: ${res.error}`
      : 'не отвечает. Откройте поиск вакансий на hh.ru; если он уже открыт — обновите страницу (F5).' }]);
    return;
  }
  const items = [...res.items];
  if (res.running) {
    // Защиту от выгрузки ставит фоновая часть расширения, на странице её не видно.
    const t = await chrome.tabs.get(tab.id).catch(() => null);
    if (t) items.push(t.autoDiscardable === false
      ? { status: 'ok', title: 'Защита от выгрузки', detail: 'включена — браузер не выгрузит вкладку из памяти' }
      : { status: 'warn', title: 'Защита от выгрузки', detail: 'не включена — перезапустите работу кнопкой «Старт»' });
  }
  showCheck(items);
}

$('selfCheck').addEventListener('click', () => {
  lastFocus = document.activeElement;
  const d = $('checkDialog');
  d.classList.add('open');
  d.setAttribute('aria-hidden', 'false');
  runSelfCheck();
});
$('checkAgain').addEventListener('click', runSelfCheck);
for (const el of document.querySelectorAll('[data-close-check]')) {
  el.addEventListener('click', () => {
    const d = $('checkDialog');
    d.classList.remove('open');
    d.setAttribute('aria-hidden', 'true');
    lastFocus?.focus?.();
  });
}
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && $('checkDialog').classList.contains('open')) {
    e.preventDefault();
    $('checkDialog').classList.remove('open');
    $('checkDialog').setAttribute('aria-hidden', 'true');
  }
});

// ---------- настройки ----------
$('useLetter').addEventListener('change', () => {
  syncLetterState();
  saveSettings();
});
for (const id of ['minDelay', 'maxDelay', 'letter', 'polzaKey', 'captchaBreak']) $(id).addEventListener('change', saveSettings);
$('polzaKey').addEventListener('input', syncCaptchaService);
for (const id of ['minDelay', 'maxDelay']) $(id).addEventListener('input', syncPauseSummary);

for (const id of ['bumpResume', 'clearRejections']) {
  $(id).addEventListener('change', () => {
    syncPrestartSummary();
    saveSettings();
  });
}

$('captchaService').addEventListener('change', () => {
  syncCaptchaService();
  saveSettings();
});

// ---------- письма: шаблоны под вакансии ----------
function collectRules() {
  return [...document.querySelectorAll('#rules .rule:not(.removing)')].map((r) => ({
    keywords: r.querySelector('.rule-keys').value,
    text: r.querySelector('.rule-text').value,
  }));
}

function numberRules() {
  const rules = [...document.querySelectorAll('#rules .rule:not(.removing)')];
  rules.forEach((r, i) => (r.querySelector('.rule-num').textContent = i + 1));
  $('rulesNote').hidden = rules.length > 0;
}

function makeRule(rule = {}) {
  const el = $('ruleTemplate').content.firstElementChild.cloneNode(true);
  el.querySelector('.rule-keys').value = rule.keywords || '';
  el.querySelector('.rule-text').value = rule.text || '';
  return el;
}

function renderRules(rules) {
  $('rules').replaceChildren(...rules.map((r) => {
    const el = makeRule(r);
    el.classList.add('open');
    return el;
  }));
  numberRules();
}

$('addRule').addEventListener('click', () => {
  const el = makeRule();
  $('rules').append(el);
  numberRules();
  void el.offsetHeight; // сначала закрытое положение, затем — плавное раскрытие
  el.classList.add('open');
  setTimeout(() => el.querySelector('.rule-keys').focus(), 200);
});

function removeRule(el) {
  el.classList.add('removing');
  el.classList.remove('open');
  numberRules();
  saveSettings();
  setTimeout(() => el.remove(), 400); // после анимации сворачивания
}

$('rules').addEventListener('change', saveSettings);

// ---------- письма: вставка и предпросмотр ----------
const editorOf = (el) => el.closest('.letter-editor');
const textareaOf = (editor) => editor.querySelector('textarea');

// Вставка в место курсора; caret — сдвиг курсора от начала вставки (иначе курсор встаёт в конец).
function insertAt(ta, text, caret) {
  if (ta.disabled) return;
  const start = ta.selectionStart;
  ta.setRangeText(text, start, ta.selectionEnd, 'end');
  if (caret != null) ta.setSelectionRange(start + caret, start + caret);
  ta.focus();
  ta.dispatchEvent(new Event('input', { bubbles: true }));
  saveSettings();
}

// Пример письма: для основного — условная вакансия, для шаблона — вакансия с его первым словом.
function sampleItem(editor) {
  const rule = editor.closest('.rule');
  let title = editor.dataset.sample || 'Программист 1С';
  if (rule) {
    const word = HHLetter.keywords({ keywords: rule.querySelector('.rule-keys').value })[0];
    title = word ? word[0].toUpperCase() + word.slice(1) : 'Вакансия';
  }
  return { title, company: 'ООО «Пример»' };
}

const plural = (n, one, few, many) =>
  n % 10 === 1 && n % 100 !== 11 ? one : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? few : many;

function refreshPreview(editor, animate = true) {
  const tpl = textareaOf(editor).value.trim();
  const box = editor.querySelector('.preview-text');
  box.textContent = tpl ? HHLetter.build(tpl, sampleItem(editor)) : 'Здесь появится пример письма — сначала напишите текст.';
  if (animate) {
    box.classList.remove('swap');
    void box.offsetWidth;
    box.classList.add('swap');
  }
  const n = tpl ? HHLetter.countVariants(tpl) : 0;
  editor.querySelector('.preview-count').textContent =
    n > 1 ? `${n > 999999 ? 'больше миллиона' : n.toLocaleString('ru-RU')} ${plural(n, 'вариант', 'варианта', 'вариантов')}` : n === 1 ? 'один вариант текста' : '';
  editor.querySelector('[data-reroll]').hidden = n < 2;
}

function togglePreview(editor) {
  const fold = editor.querySelector('.preview-fold');
  const open = !fold.classList.contains('open');
  if (open) refreshPreview(editor, false);
  fold.classList.toggle('open', open);
  editor.querySelector('[data-preview]').setAttribute('aria-pressed', String(open));
}

// Один обработчик на все кнопки внутри писем (основного и шаблонов).
document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-insert], [data-spin], [data-preview], [data-reroll], [data-remove]');
  if (!btn) return;
  if (btn.matches('[data-remove]')) return removeRule(btn.closest('.rule'));
  const editor = editorOf(btn);
  if (!editor) return;
  const ta = textareaOf(editor);
  if (btn.matches('[data-insert]')) insertAt(ta, btn.dataset.insert);
  else if (btn.matches('[data-spin]')) {
    // Выделенное слово становится первым вариантом: «привет» → {привет|}, курсор — для второго.
    const sel = ta.value.slice(ta.selectionStart, ta.selectionEnd);
    insertAt(ta, `{${sel}|}`, sel.length + 2);
  } else if (btn.matches('[data-preview]')) togglePreview(editor);
  else if (btn.matches('[data-reroll]')) refreshPreview(editor);
});

// Сохраняем и во время набора: окно расширения закрывается щелчком мимо, и «change» может не успеть.
let saveTimer = 0;
document.addEventListener('input', () => {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveSettings, 500);
});

// Открытый пример обновляется по мере набора текста.
let previewTimer = 0;
document.addEventListener('input', (e) => {
  const editor = e.target.closest?.('.letter-editor, .rule');
  if (!editor) return;
  clearTimeout(previewTimer);
  previewTimer = setTimeout(() => {
    for (const ed of (editor.matches('.rule') ? editor : editor.parentElement).querySelectorAll('.letter-editor')) {
      if (ed.querySelector('.preview-fold.open')) refreshPreview(ed);
    }
  }, 350);
});

// Перерыв после капчи от прошлого запуска уже не нужен: иначе он остаётся висеть в статусе.
async function dropStaleBreak() {
  const { active, run } = await chrome.storage.local.get(['active', 'run']);
  if (!active && run?.breakUntil) await chrome.storage.local.set({ run: { ...run, breakUntil: 0 } });
}

$('ver').textContent = `версия ${chrome.runtime.getManifest().version}`;
initSections();

chrome.storage.onChanged.addListener(render);
// Фоновая часть создаёт ID при первом запуске и сверяет ключ с файлом, если давно не сверяла.
chrome.runtime.sendMessage({ type: 'licenseInit' }).catch(() => {});
dropStaleBreak();
Promise.all([loadSettings(), render()]).finally(() => {
  // Блоки уже в нужном положении — дальше раскрываются плавно.
  setTimeout(() => document.body.classList.remove('preload'), 60);
});

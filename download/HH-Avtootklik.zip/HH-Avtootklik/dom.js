// Селекторы hh.ru и помощники для работы со страницей. Без состояния — только чтение DOM.
// Скрипты расширения на странице грузятся по порядку (manifest.json) и делят общий объект HH.
(globalThis.HH ||= {}).dom = (() => {
  // Атрибуты data-qa hh.ru. Когда hh меняет вёрстку, править нужно здесь.
  const SEL = {
    card: '[data-qa~="vacancy-serp__vacancy"]',
    title: '[data-qa="serp-item__title"]',
    employer: '[data-qa="vacancy-serp__vacancy-employer"]',
    respond: '[data-qa="vacancy-serp__vacancy_response"]',
    next: '[data-qa="pager-next"]',
    page: '[data-qa="pager-page"]',
    popup: '[data-qa="vacancy-response-popup"]',
    submit: '[data-qa="vacancy-response-submit-popup"]',
    letterToggle: '[data-qa="vacancy-response-letter-toggle"]',
    letterInput: '[data-qa="vacancy-response-popup-form-letter-input"]',
    relocation: '[data-qa="relocation-warning-confirm"]',
    captcha: '[data-qa="account-captcha-input"], img[src*="captcha"], iframe[src*="captcha"]',
    login: 'a[href*="/account/login"], [data-qa="login"]',
  };

  const isSerp = () => location.pathname.startsWith('/search/vacancy');
  const isLoginPage = () => location.pathname.startsWith('/account/login');

  // Номер страницы выдачи по адресу ('0', '1', …) или null, если это не выдача.
  const serpPage = (url) => {
    const u = new URL(url, location.origin);
    return u.pathname.startsWith('/search/vacancy') ? u.searchParams.get('page') || '0' : null;
  };

  const rand = (min, max) => Math.floor(min + Math.random() * (max - min + 1));
  const text = (root, sel) => (root.querySelector(sel)?.textContent || '').trim();
  const visible = (el) => !!el && el.isConnected && el.getClientRects().length > 0;

  // Первый ВИДИМЫЙ элемент по селектору. querySelector вернул бы первый в разметке,
  // а им может оказаться скрытый дубль (hh.ru держит в DOM старые элементы окон).
  const visibleOne = (sel) => [...document.querySelectorAll(sel)].find(visible) || null;

  const btnText = (b) => (b.textContent || b.value || '').replace(/\s+/g, ' ').trim();
  const isDisabled = (b) => b.disabled || b.getAttribute('aria-disabled') === 'true';
  const buttonByText = (root, re) =>
    [...root.querySelectorAll('button, a[role="button"]')].find((b) => visible(b) && re.test(b.textContent.trim()));

  function vacancyId(btn, card) {
    const m =
      (btn?.getAttribute('href') || '').match(/vacancyId=(\d+)/) ||
      (card?.querySelector(SEL.title)?.getAttribute('href') || '').match(/vacancy\/(\d+)/);
    return m ? m[1] : null;
  }

  function pressEscape() {
    const o = { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true };
    document.activeElement?.dispatchEvent(new KeyboardEvent('keydown', o));
    document.dispatchEvent(new KeyboardEvent('keydown', o));
  }

  // Строка под счётчиками: до какого времени действует суточный лимит hh.ru ('' — лимита нет).
  const limitLine = (l) => {
    if (!l || l.until <= Date.now()) return '';
    const t = new Date(l.until).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
    return `Лимит 24 ч до ${t}${l.exact ? '' : ' (не позже)'}`;
  };

  return { SEL, isSerp, isLoginPage, serpPage, rand, text, visible, visibleOne, btnText, isDisabled, buttonByText, vacancyId, pressEscape, limitLine };
})();

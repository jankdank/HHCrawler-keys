// Шаги перед откликами: поднять резюме и удалить отказы из списка откликов.
// Всё делается кнопками сайта, как вручную. Удалённые отклики hh.ru хранит во вкладке
// «Удалённые» — их можно вернуть кнопкой «Восстановить»; работодатель отклик при этом всё равно видит.
(globalThis.HH ||= {}).makePrestart = ({ sleep, waitFor, humanClick, humanScrollTo }) => {
  const { rand, visible, isDisabled, btnText } = HH.dom;

  const BUMP = '[data-qa~="resume-update-button"]';
  const BUMP_COOLDOWN = '[data-qa~="resume-update-button-disabled"], [data-qa~="resume-renewal-manual-text"]';

  const visibleDialogs = () => [...document.querySelectorAll('[role="dialog"], [aria-modal="true"]')].filter(visible);

  // «Контакты в резюме могли устареть» после поднятия: только закрываем окно.
  // Кнопку «Заменить на новые из профиля» не трогаем — она меняет данные резюме.
  async function dismissContactsModal() {
    const dialog = visibleDialogs().find((d) => /контакт|актуальн\S* из профиля/i.test(d.innerText || ''));
    if (!dialog) return false;
    const close = [...dialog.querySelectorAll('button, [role="button"]')].find(
      (b) => visible(b) && (/^закрыть$/i.test(btnText(b)) || /закрыть|close/i.test(b.getAttribute('aria-label') || ''))
    );
    if (close) await humanClick(close);
    await waitFor(() => !dialog.isConnected || !visible(dialog), 5000);
    return true;
  }

  // Поднимает все резюме, которые можно поднять. Возвращает строку для журнала.
  async function bumpResumes() {
    const ready = await waitFor(() => document.querySelector(`${BUMP}, ${BUMP_COOLDOWN}`), 15000);
    if (!ready) return 'кнопка «Поднять в поиске» не найдена — возможно, hh.ru изменил вёрстку';
    await sleep(rand(1500, 3000)); // «осматриваем» страницу

    const buttons = [...document.querySelectorAll(BUMP)].filter((b) => visible(b) && !isDisabled(b));
    let bumped = 0;
    let unsure = 0;
    for (const btn of buttons) {
      await humanScrollTo(btn);
      await sleep(rand(800, 2000));
      await humanClick(btn);
      await sleep(rand(1200, 2500));
      await dismissContactsModal();
      const done = await waitFor(() => !btn.isConnected || !visible(btn) || isDisabled(btn), 8000);
      if (done) bumped++;
      else unsure++;
      await sleep(rand(1500, 3500));
    }

    const cooldown = [...document.querySelectorAll('[data-qa~="resume-renewal-manual-text"]')]
      .map((e) => (e.innerText || '').trim()).filter(Boolean);
    const parts = [];
    if (bumped) parts.push(`поднято ${bumped}`);
    if (unsure) parts.push(`нажато, но не подтвердилось — ${unsure}`);
    if (!buttons.length) parts.push('поднимать пока рано');
    if (cooldown.length && !bumped) parts.push(`hh.ru пишет: ${[...new Set(cooldown)].join('; ')}`);
    return parts.join(', ');
  }

  const isDeleteText = (b) => /^удалить$/i.test(btnText(b));
  const isDeleteButton = (b) => visible(b) && !isDisabled(b) && isDeleteText(b);
  const CLICKABLE = 'button, a, [role="button"]';
  // Ссылки карточки отклика: вакансия, чат, работодатель. У отклика на архивную вакансию или со скрытой
  // компанией их может не быть — тогда карточку узнаём по тексту (см. readCards).
  const CARD_LINK = 'a[href*="/vacancy/"], a[href*="topicId"], a[href*="/chat"], a[href*="/employer/"]';

  const isRejectedLabel = (el) =>
    el.childElementCount === 0 && !el.closest('a[href*="/vacancy/"]') && /^отказ(?![а-яё])/i.test((el.textContent || '').trim());

  function cardTitle(card) {
    const link = card.querySelector('a[href*="/vacancy/"]');
    const text = link?.textContent || (card.innerText || '').split('\n').map((x) => x.trim()).find((x) => x && !/^отказ/i.test(x));
    return (text || 'без названия').replace(/\s+/g, ' ').trim();
  }

  // Ключ карточки для запоминания «эту удалить не получилось» между перезагрузками списка.
  const cardKey = (card) => (card.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 120);

  // Все карточки откликов на странице: самый широкий блок вокруг «Удалить», где эта кнопка одна.
  // От панели над списком (одна кнопка «Удалить» и флажок, почти без текста) карточку отличает
  // ссылка карточки или заметный текст. rejected — есть отдельная пометка «Отказ» (вне названия вакансии).
  function readCards() {
    const cards = [];
    for (const btn of [...document.querySelectorAll(CLICKABLE)].filter(isDeleteButton)) {
      let card = null;
      for (let el = btn.parentElement, i = 0; el && el !== document.body && i < 12; el = el.parentElement, i++) {
        if ([...el.querySelectorAll(CLICKABLE)].filter(isDeleteText).length > 1) break;
        card = el;
      }
      if (!card) continue;
      if (!card.querySelector(CARD_LINK) && (card.innerText || '').replace(/\s+/g, ' ').trim().length < 40) continue;
      const rejected = [...card.querySelectorAll('*')].some(isRejectedLabel);
      cards.push({ card, btn, title: cardTitle(card), key: cardKey(card), rejected, box: card.querySelector('input[type="checkbox"]') });
    }
    return cards;
  }

  // Общая кнопка «Удалить» над списком и флажок «выделить все» рядом с ней (оба — вне карточек).
  function bulkControls(cards) {
    const inCard = (el) => cards.some((c) => c.card.contains(el));
    const bulk = [...document.querySelectorAll(CLICKABLE)].find((b) => visible(b) && isDeleteText(b) && !inCard(b));
    if (!bulk) return null;
    let all = null;
    for (let el = bulk.parentElement, i = 0; el && el !== document.body && i < 5 && !all; el = el.parentElement, i++) {
      all = [...el.querySelectorAll('input[type="checkbox"]')].find((x) => !inCard(x)) || null;
    }
    return { bulk, all };
  }

  // Флажки у hh.ru нарисованные: само поле скрыто, нажимать нужно подпись вокруг него.
  async function setChecked(input, on) {
    if (!input || input.checked === on) return;
    const target = input.closest('label') || (visible(input) ? input : input.parentElement);
    await humanClick(target);
    if (input.checked !== on) input.click();
  }

  // Подтверждение удаления, если hh.ru переспросит: «Удалить», «Да, удалить», «Подтвердить», «Ок».
  // «Отмена», «Нет» и «Закрыть» не трогаем.
  const isConfirmButton = (b) =>
    visible(b) && !isDisabled(b) && /^(да[,.]?\s*)?(удалить( отклик| все| выбранные)?|подтвердить|ок|ok|да)$/i.test(btnText(b));

  async function confirmIfAsked() {
    const confirm = await waitFor(() => {
      const d = visibleDialogs().find((x) => /удал/i.test(x.innerText || ''));
      return d && [...d.querySelectorAll(CLICKABLE)].find(isConfirmButton);
    }, 2500);
    if (confirm) await humanClick(confirm);
  }

  // Пачка: отмечаем отказы и жмём общую «Удалить». Если на странице только отказы — «выделить все»,
  // иначе флажки только у отказов. Возвращает удалённые названия или null, если пачкой не вышло.
  async function deleteBatch(cards) {
    const rejected = cards.filter((c) => c.rejected);
    const ctl = bulkControls(cards);
    if (!ctl || rejected.some((c) => !c.box)) return null;

    if (ctl.all && rejected.length === cards.length) await setChecked(ctl.all, true);
    else for (const c of rejected) {
      await setChecked(c.box, true);
      await sleep(rand(250, 700));
    }
    await sleep(rand(600, 1400));

    // Отмечено что-то кроме отказов — снимаем всё и удаляем по одному: так надёжнее.
    const wrong = cards.filter((c) => !c.rejected && c.box?.checked);
    const selected = rejected.filter((c) => c.box.checked);
    if (wrong.length || !selected.length || isDisabled(ctl.bulk)) {
      if (ctl.all?.checked) await setChecked(ctl.all, false);
      for (const c of cards) if (c.box?.checked) await setChecked(c.box, false);
      return null;
    }

    await humanScrollTo(ctl.bulk);
    await humanClick(ctl.bulk);
    await confirmIfAsked();
    await waitFor(() => selected.every((c) => !c.card.isConnected || !visible(c.card)), 15000);
    return selected.filter((c) => !c.card.isConnected || !visible(c.card)).map((c) => c.title);
  }

  // Сколько отказов сейчас в списке — по счётчику у фильтра «Отказ» («Отказ 148», «Отказы · 148»).
  // Если счётчика на странице нет — null: тогда процент не считаем, показываем только число удалённых.
  function rejectionsTotal() {
    // Только само слово фильтра («Отказ», «Отказы») и число; названия вакансий («Отказоустойчивый … 2») не годятся.
    const re = /^отказ(?:ы|ов|а)?[\s·•:()\-–—]*(\d[\d\s]*)\)?$/i;
    for (const el of document.querySelectorAll('a, button, [role="tab"], [role="button"], li, span, div, h1, h2, h3')) {
      if (el.childElementCount > 3 || !visible(el) || el.closest('a[href*="/vacancy/"]')) continue;
      const t = (el.textContent || '').replace(/\s+/g, ' ').trim();
      if (t.length > 40) continue;
      const m = re.exec(t);
      if (m) return Number(m[1].replace(/\D/g, ''));
    }
    return null;
  }

  const EMPTY_RE = /нет откликов|откликов пока нет|ничего не найдено|нет ни одного отклика|пока нет откликов/i;

  // Снимок страницы для диагностики: что расширение видит. Попадает в журнал, если что-то пошло не так.
  function snapshot() {
    const cards = readCards();
    return {
      cards: cards.length,
      rejected: cards.filter((c) => c.rejected).length,
      deletes: [...document.querySelectorAll(CLICKABLE)].filter(isDeleteButton).length,
      chip: rejectionsTotal(),
    };
  }

  // Удаляет все отклики с отказом, видимые на странице: пачками через флажки (или по одному,
  // если пачкой нельзя), подгружая список кнопкой «Показать ещё». Карточку, которую удалить не вышло,
  // пропускает и идёт дальше — одна проблемная не должна останавливать остальные.
  // skip — ключи карточек, которые не удалились в прошлых порциях (их не трогаем).
  // Возвращает { removed: [названия], failed: [{ key, title }], loaded, snap }.
  // Перезагрузку страницы для следующей порции делает content.js — пока удаление идёт.
  async function clearRejections(onProgress = () => {}, onTotal = () => {}, skip = []) {
    // Ждём, пока список действительно отрисуется (карточки, пустое состояние или счётчик 0), а не просто
    // любую ссылку на вакансию: на странице их хватает и вне списка.
    const ready = await waitFor(() => readCards().length > 0 || EMPTY_RE.test(document.body.innerText.slice(0, 20000)) || rejectionsTotal() === 0, 20000);
    if (!ready) return { removed: [], failed: [], loaded: false, snap: snapshot() };
    await sleep(rand(1500, 3000));

    // Обычно страница уже открыта с фильтром state=DISCARD (только отказы). Если нет —
    // пробуем вкладку-фильтр «Отказ».
    const filtered = /state=discard/i.test(location.search);
    const tab = !filtered && [...document.querySelectorAll('a, button, [role="tab"]')].find((el) => visible(el) && /^отказ\S*(\s*\d+)?$/i.test(btnText(el)));
    if (tab && tab.getAttribute('aria-selected') !== 'true') {
      await humanClick(tab);
      await sleep(rand(2000, 3500));
    }

    onTotal(rejectionsTotal()); // сколько отказов осталось в списке (null — счётчика нет)

    const skipKeys = new Set(skip);
    const removed = [];
    const failed = [];
    const failedNodes = new Set();
    let moreClicks = 0;
    let rescans = 0;
    let batchWorks = true; // если пачкой не вышло один раз — дальше по одному
    for (let step = 0; step < 600; step++) {
      const cards = readCards();
      const rejected = cards.filter((c) => c.rejected && !skipKeys.has(c.key) && !failedNodes.has(c.card));
      if (!rejected.length) {
        // Видимые отказы кончились — подгружаем следующую порцию, если список это умеет.
        const more = [...document.querySelectorAll(CLICKABLE)].find((b) => visible(b) && !isDisabled(b) && /^(показать|загрузить) ещё/i.test(btnText(b)));
        if (more && moreClicks < 30) {
          moreClicks++;
          await humanScrollTo(more);
          await humanClick(more);
          await sleep(rand(2000, 3500));
          continue;
        }
        // Список мог ещё не дорисоваться: прежде чем решить, что отказов нет, смотрим ещё раз.
        if (rescans < 2) {
          rescans++;
          await sleep(3500);
          continue;
        }
        break;
      }
      rescans = 0;

      if (batchWorks && rejected.length > 1) {
        const batch = await deleteBatch(cards);
        if (batch?.length) {
          removed.push(...batch);
          onProgress(removed.length);
          await sleep(rand(1500, 3000));
          continue;
        }
        batchWorks = false;
      }

      // По одному: «Удалить» на карточке. Не вышло — ещё одна попытка, потом пропускаем карточку.
      const one = rejected[0];
      await humanScrollTo(one.card);
      await sleep(rand(600, 1400));
      let gone = false;
      for (let attempt = 0; attempt < 2 && !gone; attempt++) {
        await humanClick(one.btn);
        await confirmIfAsked();
        gone = await waitFor(() => !one.card.isConnected || !visible(one.card) || !visible(one.btn), attempt ? 8000 : 12000);
      }
      if (!gone) {
        failedNodes.add(one.card);
        failed.push({ key: one.key, title: one.title });
        continue;
      }
      removed.push(one.title);
      onProgress(removed.length);
      await sleep(rand(1000, 2500));
    }
    return { removed, failed, loaded: true, snap: snapshot() };
  }

  return { bumpResumes, clearRejections, rejectionsTotal };
};

// HH Автоотклик — content script.
// Работает на странице поиска hh.ru: по очереди нажимает «Откликнуться» у вакансий,
// проходит модалку отклика и делает случайную паузу между откликами.
(() => {
  if (window.__hhAutoApply) return;
  window.__hhAutoApply = true;

  // Модули (manifest.json грузит их раньше этого файла): селекторы и помощники — dom.js,
  // паузы — timing.js, «человеческие» действия — human.js, хранилище и журнал — store.js,
  // панель — panel.js, проверка страницы — selfcheck.js, письма — letter.js.
  const { SEL, isSerp, isLoginPage, serpPage, rand, text, visible, visibleOne, btnText, isDisabled, buttonByText, vacancyId, pressEscape, limitLine } = HH.dom;

  // Ключ активного сервиса капчи ('' — сервис не настроен).
  const captchaKey = (s) =>
    ((s.captchaService === 'qwen' ? s.polzaKey : s.rucaptchaKey) || '').trim();
  const HEARTBEAT_TTL = 10 * 60 * 1000; // после закрытия вкладки/браузера запуск не «воскресает»
  const DAILY_LIMIT = 200; // hh.ru: не более 200 откликов за 24 часа
  const DAY = 24 * 60 * 60 * 1000;
  const MAX_ERROR_STREAK = 5; // столько ошибок подряд — повод остановиться и проверить страницу
  const LEFT_REASON = 'открылась отдельная страница отклика (вопросы работодателя / письмо)';

  let limitInfo = null; // { until, exact } — до какого времени действует суточный лимит

  let active = false;
  let owned = false; // эта вкладка — владелец текущего запуска
  let myTabId = null;

  const whoami = async () => {
    try {
      return await chrome.runtime.sendMessage({ type: 'whoami' });
    } catch {
      return null; // расширение обновили или перезапустили
    }
  };

  const { sleep, waitFor, stopAll } = HH.makeTiming(() => active);

  // ---------- хранилище ----------
  const store = HH.store;
  const { log, settings } = HH.store;

  let run = null; // { tabId, applied, skipped, errors, done[], pending, returnUrl, heartbeat, status }

  async function saveRun(patch = {}) {
    Object.assign(run, patch, { heartbeat: Date.now() });
    if (owned) await store.set({ run });
    renderPanel();
  }

  const setStatus = (status) => saveRun({ status });

  chrome.storage.onChanged.addListener((changes) => {
    if (changes.limit) {
      limitInfo = changes.limit.newValue || null;
      renderPanel();
    }
    // «Очистить журнал и счётчики» в окне расширения: обнуляем и свою копию, иначе следующая запись вернёт старые числа.
    if (changes.resetCounters && run) {
      run.applied = run.skipped = run.errors = run.earlier = 0;
      if (owned) saveRun();
      else renderPanel();
    }
    if (!changes.active && !changes.run) return;
    // Кнопка «сбросить таймер капчи» в окне расширения обнулила перерыв.
    if (owned && run?.breakUntil && changes.run && !changes.run.newValue?.breakUntil) run.breakUntil = 0;
    if (owned && changes.run && changes.run.newValue?.tabId !== myTabId) {
      // Запуск перехватила другая вкладка — эта останавливается, ничего не записывая.
      owned = false;
      if (run) run.status = 'Работа продолжается в другой вкладке';
    }
    const was = active;
    active = owned && (changes.active ? !!changes.active.newValue : active);
    if (was && !active) stopAll();
    renderPanel();
  });

  // При уходе со страницы (перезагрузка, переход) браузер тоже шлёт
  // visibilitychange — это не «вкладку скрыли», в журнал такое не пишем.
  let unloading = false;
  for (const ev of ['beforeunload', 'pagehide']) window.addEventListener(ev, () => { unloading = true; });
  window.addEventListener('pageshow', () => { unloading = false; });

  document.addEventListener('visibilitychange', () => {
    if (!active || unloading) return;
    log(document.hidden
      ? 'Вкладка скрыта (свёрнуто окно или отключён RDP) — браузер замедляет работу'
      : 'Вкладка снова на экране').catch(() => {});
  });

  const { humanScrollTo, humanClick, humanType } = HH.makeHuman({ sleep });

  async function closeModal() {
    const modal = findModal();
    if (!modal) return;
    const closeBtn = modal.querySelector('[data-qa*="close"], [aria-label="Закрыть"], [aria-label="Close"]');
    if (closeBtn) await humanClick(closeBtn);
    else pressEscape();
    await waitFor(() => !findModal(), 4000);
  }

  // ---------- распознавание состояния страницы ----------
  function findModal() {
    const popup = document.querySelector(SEL.popup);
    if (visible(popup)) return popup;
    return [...document.querySelectorAll('[role="dialog"]')].find(visible) || null;
  }

  // Капча на экране: видимое поле/картинка капчи или любое видимое окно с текстом
  // «не робот» (findModal() сначала вернул бы окно отклика, а не окно капчи).
  const captchaShown = () =>
    !!visibleOne(SEL.captcha) ||
    [...document.querySelectorAll(`[role="dialog"], [aria-modal="true"], ${SEL.popup}`)].some(
      (d) => visible(d) && /не робот/i.test(d.textContent || '')
    );

  // ---------- автоматическое решение капчи (RuCaptcha) ----------
  const CAP = {
    img: 'img[data-qa="account-captcha-picture"], img[src*="captcha"]',
    input: '[data-qa="account-captcha-input"], input[name*="captcha" i]',
    submit: '[data-qa="account-captcha-submit"], [data-qa="account-login-submit"]',
    refresh: '[data-qa="account-captcha-refresh"], [data-qa*="captcha"][data-qa*="refresh"]',
  };

  function _blobToBase64(blob) {
    return new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(String(fr.result).split(',')[1]);
      fr.onerror = reject;
      fr.readAsDataURL(blob);
    });
  }

  // Проверяет, что на холсте есть картинка, а не пустой белый/прозрачный лист
  // (иначе решатель получит пустышку и вернёт мусор вроде «вход»).
  function _canvasNotBlank(canvas) {
    try {
      const w = canvas.width, h = canvas.height;
      if (!w || !h) return false;
      const data = canvas.getContext('2d').getImageData(0, 0, w, h).data;
      let min = 255, max = 0, opaque = false;
      for (let i = 0; i < data.length; i += 4) {
        if (data[i + 3] !== 0) opaque = true;
        const lum = (data[i] + data[i + 1] + data[i + 2]) / 3;
        if (lum < min) min = lum;
        if (lum > max) max = lum;
      }
      return opaque && max - min > 15; // есть контраст и не всё прозрачно
    } catch (_) {
      return true; // не смогли проверить — считаем валидной
    }
  }

  // Картинка капчи -> чистый base64 (без префикса data:).
  // Каким способом взята последняя картинка капчи ('data' | 'canvas' | 'fetch') —
  // для диагностики: повторная загрузка картинки может «сжечь» капчу.
  let lastCaptureMethod = '';

  async function captchaImageBase64(img) {
    const rawSrc = img.getAttribute('src') || '';
    if (rawSrc.startsWith('data:')) {
      lastCaptureMethod = 'data';
      const comma = rawSrc.indexOf(',');
      return comma >= 0 ? rawSrc.slice(comma + 1) : rawSrc;
    }
    const src = img.currentSrc || img.src || rawSrc;

    // 1) Основной способ — canvas c ОТОБРАЖЁННОЙ картинки: она гарантированно
    //    соответствует текущей капче. Прошлый баг был в том, что drawImage
    //    вызывался до готовности изображения (пустой холст) — теперь ждём
    //    декодирования через img.decode() и проверяем, что холст не пуст.
    try {
      try {
        await img.decode();
      } catch (_) {}
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth || img.width || 300;
      canvas.height = img.naturalHeight || img.height || 100;
      canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
      if (_canvasNotBlank(canvas)) {
        const data = canvas.toDataURL('image/png').split(',')[1];
        lastCaptureMethod = 'canvas';
        return data;
      }
    } catch (_) {
      // canvas «испорчен» кросс-доменной картинкой — пробуем fetch ниже
    }

    // 2) Fallback — прямая загрузка src (тот же домен, с куками).
    if (src) {
      const resp = await fetch(src, { credentials: 'include', cache: 'no-store' });
      if (resp.ok) {
        const blob = await resp.blob();
        if (blob && blob.size > 200) {
          lastCaptureMethod = 'fetch';
          return await _blobToBase64(blob);
        }
      }
    }

    throw new Error('не удалось получить картинку капчи');
  }

  // Окно именно капчи — определяем от поля ввода: диалог, в котором оно лежит,
  // а если окно без role="dialog" — ближайший контейнер с текстом «не робот».
  // Окно отклика (findModal) сюда не годится: там кнопка «Откликнуться».
  function captchaModal(input) {
    const el = input || visibleOne(CAP.input);
    if (!el) return findModal() || document.body;
    const dialog = el.closest('[role="dialog"], [aria-modal="true"]');
    if (dialog) return dialog;
    for (let p = el.parentElement; p && p !== document.body; p = p.parentElement) {
      if (/не робот|пройдите капчу/i.test(p.textContent || '')) return p;
    }
    return document.body;
  }

  // Кнопка «Отправить» окна капчи. Кнопки с «отклик» в тексте не берём ни при
  // каких условиях — это «Откликнуться» самой вакансии.
  function findCaptchaSubmit(input) {
    const el = input || visibleOne(CAP.input);
    const SUBMIT_RE = /^(отправить|продолжить|подтвердить|готово)$/i;
    const ok = (b) => visible(b) && !/отклик/i.test(btnText(b));

    const modal = captchaModal(el);
    if (modal !== document.body) {
      const scoped = modal.querySelector(CAP.submit) || buttonByText(modal, SUBMIT_RE);
      if (scoped && ok(scoped)) return scoped;
    }

    // Окно не опознали — ближайшая видимая «Отправить» под полем капчи.
    if (!el) return null;
    const below = el.getBoundingClientRect().bottom;
    return (
      [...document.querySelectorAll('button, [role="button"], input[type="submit"]')]
        .filter((b) => ok(b) && SUBMIT_RE.test(btnText(b)))
        .map((b) => ({ b, dy: b.getBoundingClientRect().top - below }))
        .filter((x) => x.dy >= -5)
        .sort((a, b) => a.dy - b.dy)[0]?.b || null
    );
  }

  // Жмёт «Отправить» в окне капчи и возвращает нажатую кнопку (null — не нашли).
  // Запасного варианта вроде Enter / отправки формы нет намеренно: так можно
  // отправить форму отклика вместо капчи.
  async function submitCaptcha(input) {
    const btn = findCaptchaSubmit(input);
    if (!btn) return null;
    // Нажатие по неактивной кнопке ничего не отправит — ждём, пока hh.ru её включит.
    if (isDisabled(btn)) await waitFor(() => !isDisabled(btn), 3000).catch(() => {});
    await humanClick(btn);
    return btn;
  }

  // Кнопка ↻ (новая картинка). Её легко спутать с крестиком закрытия окна —
  // обе иконки. А закрытие выглядит как «капча исчезла», и расширение приняло бы
  // его за успешное решение. Поэтому ищем ↻ по месту: она стоит в одном ряду
  // с кнопкой «English», под картинкой капчи.
  function findRefreshButton(modal) {
    const byAttr =
      modal.querySelector(CAP.refresh) ||
      modal.querySelector(
        '[aria-label*="обнов" i], [title*="обнов" i], [aria-label*="refresh" i], [title*="refresh" i]'
      );
    if (visible(byAttr)) return byAttr;

    const buttons = [...modal.querySelectorAll('button, [role="button"]')].filter(visible);
    const meta = (b) =>
      `${b.getAttribute('aria-label') || ''} ${b.getAttribute('title') || ''} ${b.getAttribute('data-qa') || ''}`;
    const isClose = (b) => /закр|close/i.test(meta(b));
    const isAction = (b) => /english|отправ|продолж|подтверд|готово|войти/i.test(btnText(b));
    const midY = (el) => {
      const r = el.getBoundingClientRect();
      return (r.top + r.bottom) / 2;
    };

    const byText = buttons.find((b) => /обнов|refresh/i.test(btnText(b)));
    if (byText) return byText;

    const english = buttons.find((b) => /^english$/i.test(btnText(b)));
    if (english) {
      const r = english.getBoundingClientRect();
      const sameRow = buttons.find(
        (b) => b !== english && !isClose(b) && midY(b) >= r.top && midY(b) <= r.bottom
      );
      if (sameRow) return sameRow;
    }

    // Запасной вариант — кнопка строго между картинкой и полем ввода
    // (крестик окна — выше картинки, крестик очистки — внутри поля).
    const img = visibleOne(CAP.img);
    const input = visibleOne(CAP.input);
    if (visible(img) && visible(input)) {
      const top = img.getBoundingClientRect().bottom;
      const bottom = input.getBoundingClientRect().top;
      return (
        buttons.find((b) => !isClose(b) && !isAction(b) && midY(b) > top && midY(b) < bottom) || null
      );
    }
    return null;
  }

  // Обновляет картинку капчи: 'ok' — нажали ↻, 'none' — кнопку не нашли,
  // 'closed' — после нажатия окно капчи пропало (нажали не ту кнопку).
  async function refreshCaptcha() {
    const btn = findRefreshButton(captchaModal());
    if (!btn) return 'none';
    await humanClick(btn);
    await sleep(rand(700, 1500));
    return captchaShown() ? 'ok' : 'closed';
  }

  // Латинские и цифровые «двойники» кириллических букв: распознавалка иногда
  // выдаёт их вместо русских — на вид то же слово, но hh.ru его не примет.
  const CYR_LOOKALIKE = {
    a: 'а', b: 'в', c: 'с', e: 'е', h: 'н', k: 'к', m: 'м', n: 'п', o: 'о', p: 'р',
    r: 'г', t: 'т', u: 'и', x: 'х', y: 'у', 0: 'о', 3: 'з', 4: 'ч', 6: 'б',
  };

  // Ответ решателя -> строчные русские слова через один пробел ('' — пусто).
  function normalizeCaptchaAnswer(raw) {
    return String(raw || '')
      .toLowerCase()
      .replace(/[a-z0-9]/g, (ch) => CYR_LOOKALIKE[ch] || ch)
      .replace(/[^а-яё\s]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  // hh.ru под полем пишет «Неверный текст. Пожалуйста, повторите попытку.»
  const captchaError = () => /неверн\S*\s+текст|повторите попытку/i.test(captchaModal().innerText || '');

  // Ввод ответа капчи «как с клавиатуры»: на каждый символ keydown → keypress →
  // beforeinput → input → keyup с паузами живого набора. Подстановка значения
  // одними событиями input (как в humanType) проверку капчи может не пройти.
  async function typeCaptcha(el, value) {
    el.focus();
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    const key = (type, k) => el.dispatchEvent(new KeyboardEvent(type, { key: k, bubbles: true, cancelable: true }));
    // Прошлый ответ стираем, как выделение + Backspace.
    if (el.value) {
      key('keydown', 'Backspace');
      setter.call(el, '');
      el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' }));
      key('keyup', 'Backspace');
      await sleep(rand(150, 400));
    }
    let current = '';
    for (const ch of value) {
      key('keydown', ch);
      key('keypress', ch);
      el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, inputType: 'insertText', data: ch }));
      current += ch;
      setter.call(el, current);
      el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: ch }));
      key('keyup', ch);
      // В скрытой вкладке таймеры спят до минуты — там печатаем без пауз.
      if (!document.hidden) await sleep(rand(70, 200));
    }
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // Пытается пройти капчу через выбранный сервис, до 5 раз с обновлением картинки.
  // Возвращает true, если капча пройдена.
  async function tryPassCaptcha(s) {
    if (!captchaKey(s)) return false;
    const serviceName = s.captchaService === 'qwen' ? 'Qwen (polza.ai)' : 'RuCaptcha';
    const srcNow = () => visibleOne(CAP.img)?.getAttribute('src') || '';

    // Новая картинка по ↻. Если окно при этом пропало — это не решение капчи,
    // а нажатие не той кнопки: останавливаемся, а не «повторяем вакансию».
    const refresh = async () => {
      if ((await refreshCaptcha()) !== 'closed') return true;
      await log('Окно капчи закрылось при обновлении картинки — пройдите капчу вручную', 'error');
      return false;
    };

    for (let attempt = 1; attempt <= 5 && active; attempt++) {
      const img = visibleOne(CAP.img);
      const input = visibleOne(CAP.input);
      if (!visible(img) || !visible(input)) return !captchaShown();

      await setStatus(`Решаю капчу через ${serviceName} (попытка ${attempt}/5)…`);

      let base64;
      try {
        base64 = await captchaImageBase64(img);
      } catch (e) {
        await log(`Капча: не удалось получить картинку (попытка ${attempt}/5) — ${e.message}`, 'skip');
        if (attempt < 5 && (await refresh())) continue;
        return false;
      }

      let resp;
      try {
        resp = await chrome.runtime.sendMessage({ type: 'solveCaptcha', imageBase64: base64 });
      } catch (e) {
        resp = { error: String(e) };
      }
      if (resp && resp.error === 'no_key') return false;

      // hh.ru принимает ответ только слитно: «пеню стадионных» -> «пенюстадионных».
      // Вариант с пробелом отклоняется (проверено на реальных капчах).
      const answer = normalizeCaptchaAnswer(resp && resp.text).replace(/ /g, '');
      if (!answer) {
        await log(`Капча не распознана (попытка ${attempt}/5)${resp?.error ? ': ' + resp.error : ''}`, 'skip');
        if (attempt < 5 && (await refresh())) continue;
        return false;
      }

      await log(`Капча распознана: «${answer}» (попытка ${attempt}/5)`);
      const prevSrc = srcNow();
      await typeCaptcha(input, answer);
      await sleep(rand(300, 700));

      // Диагностика: что на самом деле уходит в hh.ru.
      const notes = [];
      if (lastCaptureMethod === 'fetch') notes.push('картинка скачана повторно (canvas недоступен)');
      if (input.value !== answer) notes.push(`в поле оказалось «${input.value}»`);
      const submitBtn = findCaptchaSubmit(input);
      if (submitBtn && isDisabled(submitBtn)) notes.push('кнопка «Отправить» была неактивна');

      const errorBefore = captchaError(); // после ввода hh.ru обычно убирает старую ошибку
      const sentAt = Date.now();
      const clicked = await submitCaptcha(input);
      if (!clicked) {
        await log('Не нашёл кнопку «Отправить» в окне капчи — останавливаюсь, чтобы не нажать лишнего', 'error');
        return false;
      }
      if (!/^отправить$/i.test(btnText(clicked))) notes.push(`нажата кнопка «${btnText(clicked)}»`);

      // Ждём исхода: окно закрылось (успех), картинка сменилась или появилось
      // «Неверный текст» (отказ) — без него пришлось бы ждать все 12 секунд.
      await waitFor(
        () => !captchaShown() || srcNow() !== prevSrc || (!errorBefore && captchaError()),
        12000
      ).catch(() => {});
      // Окно после верного ответа закрывается не мгновенно — даём hh.ru закончить.
      await sleep(rand(700, 1200));

      if (!captchaShown()) {
        await log('Капча пройдена ✅', 'ok');
        return true;
      }
      const reaction =
        !errorBefore && captchaError()
          ? 'написал «Неверный текст»'
          : srcNow() !== prevSrc
            ? 'сменил картинку без сообщения об ошибке'
            : `не отреагировал за ${Math.round((Date.now() - sentAt) / 1000)} с`;
      await log(
        `hh.ru отклонил ответ (попытка ${attempt}/5): ${reaction}${notes.length ? '; ' + notes.join('; ') : ''}`,
        'skip'
      );
      // При неверном ответе hh.ru оставляет ту же картинку — берём новую по ↻.
      if (attempt < 5 && srcNow() === prevSrc && !(await refresh())) return false;
    }
    return !captchaShown();
  }

  // «В течение 24 часов можно совершить не более 200 откликов», «Вы исчерпали лимит откликов» и т. п.
  // Слово «отклик» обязательно: иначе сработало бы на тексты вакансий вроде «достигать лимитов».
  const LIMIT_RE = /не более \d+ отклик|лимит\S*(\s+\S+){0,2}\s+отклик|слишком много отклик/i;
  const limitReached = (root = document.body) => LIMIT_RE.test(root?.innerText || '');

  // Сообщение о лимите может быть всплывающим уведомлением, которое исчезнет через пару секунд,
  // поэтому следим за всем, что появляется на странице, и запоминаем факт.
  let limitHit = false;
  new MutationObserver((mutations) => {
    if (!active || limitHit) return;
    for (const m of mutations) {
      for (const n of m.type === 'characterData' ? [m.target] : m.addedNodes) {
        if (!LIMIT_RE.test(n.textContent || '')) continue; // дешёвый фильтр без пересчёта вёрстки
        const el = n.nodeType === Node.ELEMENT_NODE ? n : n.parentElement;
        if (!el || /^(SCRIPT|STYLE|TEMPLATE|NOSCRIPT)$/.test(el.tagName) || !visible(el)) continue;
        if (LIMIT_RE.test(el.innerText || '')) {
          limitHit = true; // ожидания в applyTo и основной цикл проверяют этот флаг
          return;
        }
      }
    }
  }).observe(document.documentElement, { childList: true, subtree: true, characterData: true });

  const checkLimit = () => {
    if (limitHit || limitReached()) throw new Error('limit');
  };

  // Свой учёт успешных откликов за последние 24 часа — на случай, если hh.ru не покажет сообщение.
  async function recentApplies() {
    const { applies = [] } = await store.get('applies');
    return applies.filter((t) => Date.now() - t < DAY);
  }

  async function countApply() {
    const list = await recentApplies();
    list.push(Date.now());
    await store.set({ applies: list });
    return list.length;
  }

  // Запоминает, до какого времени действует лимит, и возвращает текст для журнала.
  // Если в нашем учёте уже 200 откликов — время точное: когда самый старый из них выйдет из 24 часов.
  // Если лимит показал hh.ru раньше (часть откликов сделана вручную или до обновления) — берём
  // верхнюю оценку «сейчас + 24 часа»: к этому времени лимит точно снимется.
  async function limitMessage() {
    const list = await recentApplies();
    const exact = list.length >= DAILY_LIMIT;
    const until = exact ? list[list.length - DAILY_LIMIT] + DAY : Date.now() + DAY;
    limitInfo = { until, exact };
    await store.set({ limit: limitInfo });
    return `Лимит hh.ru: не более ${DAILY_LIMIT} откликов за 24 часа. ${limitLine(limitInfo)}`;
  }

  function nextCard() {
    for (const card of document.querySelectorAll(SEL.card)) {
      const btn = card.querySelector(SEL.respond);
      if (!visible(btn) || !/Откликнуться/i.test(btn.textContent)) continue;
      const id = vacancyId(btn, card);
      if (!id || run.done.includes(id)) continue;
      return { card, btn, id, title: text(card, SEL.title) || `Вакансия ${id}`, company: text(card, SEL.employer) };
    }
    return null;
  }

  // Вакансии, обработанные раньше (до этого запуска или вручную): на карточке вместо «Откликнуться» —
  // «Вы откликнулись», «Вам отказали», «Вы отказались», «Вас пригласили». Цикл их пропускает, но считает
  // в счётчике «ранее» — один раз на вакансию, — чтобы счётчики сходились с прогрессом по выдаче.
  const EARLIER_RE = /вы откликнулись|вам отказали|вы отказались|вас пригласили/i;

  function countEarlier(uptoCard) {
    const cards = [...document.querySelectorAll(SEL.card)];
    const end = uptoCard ? cards.indexOf(uptoCard) : -1;
    const seen = new Set(run.earlierIds || []);
    let added = 0;
    for (const card of end >= 0 ? cards.slice(0, end) : cards) {
      const btn = card.querySelector(SEL.respond);
      if (visible(btn) && /Откликнуться/i.test(btn.textContent)) continue;
      const id = vacancyId(btn, card) || text(card, SEL.title);
      // Свои отклики этого запуска (run.done) сюда не относятся — они уже в «откликах»/«пропущено».
      if (!id || run.done.includes(id) || seen.has(id) || !EARLIER_RE.test(card.innerText || '')) continue;
      seen.add(id);
      added++;
    }
    if (added) {
      run.earlier = (run.earlier || 0) + added;
      run.earlierIds = [...seen];
    }
    return added;
  }

  // Состояние отклика на карточке: true — кнопки «Откликнуться» больше нет, false — она на месте,
  // null — карточку не найти. Карточку ищем заново: hh.ru может перерисовать выдачу.
  function responded(item) {
    const card = item.card.isConnected
      ? item.card
      : [...document.querySelectorAll(SEL.card)].find((c) =>
          c.querySelector(`${SEL.respond}[href*="vacancyId=${item.id}"], a[href*="/vacancy/${item.id}"]`));
    if (!card) return null;
    const btn = card.querySelector(SEL.respond);
    return !(visible(btn) && /Откликнуться/i.test(btn.textContent));
  }

  // Письмо собирает letter.js (общий с окном расширения): шаблон по словам в названии,
  // варианты {а|б} и подстановки {vacancy}/{company}.

  // ---------- письмо после отклика ----------
  // После отклика без письма hh.ru пишет «Ваш отклик отправлен работодателю. Вы можете приложить
  // сопроводительное письмо…» с кнопкой «Приложить письмо». Где именно появится форма (в окне,
  // в карточке, на отдельной странице), заранее неизвестно, поэтому ищем по тексту и по новым полям.
  const ATTACH_RE = /^приложить(\s+сопроводительное)?\s+письмо$/i;
  // «Приложить письмо» сюда не входит: повторное нажатие на неё сворачивает форму, а не отправляет.
  const SEND_RE = /^(отправить|отправить письмо|приложить|сохранить|сохранить письмо|готово)$/i;
  const LETTER_OK_RE = /письмо\s+(отправлено|приложено|доставлено|добавлено|сохранено)/i;
  const BTN = 'button, [role="button"], input[type="submit"]';

  const attachButtons = () =>
    [...document.querySelectorAll('button, a, [role="button"]')].filter((b) => visible(b) && ATTACH_RE.test(btnText(b)));
  const visibleTextareas = () => [...document.querySelectorAll('textarea')].filter(visible);

  // Где искать кнопку отправки: форма поля, окно с полем, затем всё более широкие родители поля.
  function letterScopes(ta) {
    const scopes = [];
    const form = ta.closest('form');
    if (form) scopes.push(form);
    const modal = findModal();
    if (modal?.contains(ta)) scopes.push(modal);
    let el = ta.parentElement;
    for (let i = 0; el && el !== document.body && i < 15; i++, el = el.parentElement) scopes.push(el);
    return scopes;
  }

  // Кнопка отправки письма. Из подходящих берём ближайшую ПОСЛЕ поля: кнопки формы идут под полем,
  // а ссылка «Приложить письмо» — над ним.
  function sendButtonNear(ta) {
    const known = document.querySelector('[data-qa="vacancy-response-letter-submit"]');
    if (visible(known)) return known;
    const after = (b) => ta.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING;
    for (const scope of letterScopes(ta)) {
      const cands = [...scope.querySelectorAll(BTN)].filter((b) => visible(b) && !ATTACH_RE.test(btnText(b)));
      const match = (b) =>
        SEND_RE.test(btnText(b)) || /submit/i.test(b.getAttribute('data-qa') || '') || (scope.tagName === 'FORM' && b.type === 'submit');
      const found = cands.find((b) => match(b) && after(b)) || cands.find(match);
      if (found) return found;
    }
    return null;
  }

  // Для журнала: какие кнопки видны рядом с полем, если нужную найти не удалось.
  function buttonsAround(ta) {
    for (const scope of letterScopes(ta)) {
      const texts = [...scope.querySelectorAll(BTN)].filter(visible).map(btnText).filter((t) => t && !ATTACH_RE.test(t));
      if (texts.length) return [...new Set(texts)].slice(0, 6).map((t) => `«${t.slice(0, 30)}»`).join(', ');
    }
    return 'нет';
  }

  // Вписывает письмо и отправляет. Возвращает null при успехе или причину неудачи.
  async function sendLetter(ta, letter, before = new Set()) {
    await setStatus('Прикладываю письмо');
    await humanType(ta, letter);
    await sleep(rand(800, 2000));
    const btn = await waitFor(() => {
      const b = sendButtonNear(ta);
      return b && !isDisabled(b) ? b : null;
    }, 5000);
    if (!btn) {
      const b = sendButtonNear(ta);
      const field = ta.getAttribute('data-qa') || 'без data-qa';
      return b
        ? `кнопка «${btnText(b)}» неактивна (поле ${field})`
        : `не нашлась кнопка отправки (поле ${field}; кнопки рядом: ${buttonsAround(ta)})`;
    }
    const label = btnText(btn);
    const box = ta.parentElement?.parentElement?.parentElement || ta.parentElement;
    await humanClick(btn);
    const closed = await waitFor(() => !visible(ta) || (box?.isConnected && LETTER_OK_RE.test(box.innerText)), 15000);
    if (!closed) return `после «${label}» форма письма не закрылась`;
    await sleep(rand(1500, 2500));
    // Если снова видно «Приложить письмо» — форму просто закрыли, письмо не ушло.
    if (attachButtons().some((b) => !before.has(b))) return `после «${label}» снова видна кнопка «Приложить письмо»`;
    return null;
  }

  // Нажимает «Приложить письмо», которого не было до отклика (before), и отправляет письмо.
  // Возвращает пометку для журнала.
  async function attachLetterAfterResponse(letter, before) {
    const btn = await waitFor(() => attachButtons().find((b) => !before.has(b)), 5000);
    if (!btn) return 'без письма: hh.ru не предложил его приложить';
    const oldAreas = new Set(visibleTextareas());
    await sleep(rand(1000, 2500));
    // Если кнопка уведёт на другую страницу с полной загрузкой, письмо допишет resume().
    await saveRun({ pending: { ...run.pending, submitted: true, letter: true } });
    await humanClick(btn);
    const ta = await waitFor(() => visibleTextareas().find((t) => !oldAreas.has(t) && !t.value.trim()), 10000);
    if (!ta) return 'письмо не отправилось: не появилось поле для письма';
    const err = await sendLetter(ta, letter, before);
    return err ? `письмо не отправилось: ${err}` : 'письмо приложено';
  }

  // Та же отправка на отдельной странице, куда увела кнопка «Приложить письмо» (после перезагрузки).
  async function attachLetterOnThisPage(p) {
    try {
      const s = await settings();
      const letter = HHLetter.letterFor(s, p);
      if (!letter) return '';
      const emptyArea = () => visibleTextareas().find((t) => !t.value.trim());
      // Страница вакансии может снова показать «Ваш отклик отправлен… Приложить письмо» — раскрываем форму.
      if (!(await waitFor(() => emptyArea() || attachButtons()[0], 10000))) return 'письмо не отправилось: не нашлось поле для письма';
      if (!emptyArea()) {
        await sleep(rand(1000, 2500));
        await humanClick(attachButtons()[0]);
      }
      const ta = await waitFor(emptyArea, 10000);
      if (!ta) return 'письмо не отправилось: не нашлось поле для письма';
      const err = await sendLetter(ta, letter);
      return err ? `письмо не отправилось: ${err}` : 'письмо приложено';
    } catch (e) {
      if (e.message === 'stopped') throw e;
      return `письмо не отправилось: ${e.message}`;
    }
  }

  // ---------- один отклик ----------
  // Возвращает 'applied' | 'skipped' | 'error' | 'limit' | 'captcha' и причину.
  async function applyTo(item, s) {
    await setStatus(`Открываю: ${item.title}`);
    await humanScrollTo(item.card);
    await sleep(rand(1500, 4000)); // «читаем» карточку

    const letter = HHLetter.letterFor(s, item); // при каждом отклике свой вариант текста
    const attachBefore = new Set(letter ? attachButtons() : []); // «Приложить письмо» от прошлых откликов

    // Пока на экране окно капчи, «Откликнуться» не жмём никогда: сначала капча.
    if (captchaShown()) return ['captcha'];

    // letterOwed: письмо хотим приложить, но оно ещё не ушло. Если отклик прервёт капча или сбой,
    // а отклик всё же уйдёт, цикл найдёт эту отметку и приложит письмо (см. settleOwedLetter).
    await saveRun({
      pending: { id: item.id, title: item.title, company: item.company, submitted: false },
      letterOwed: letter ? { id: item.id, title: item.title, company: item.company } : null,
    });
    await humanClick(item.btn);

    const first = await waitFor(() => {
      if (limitHit) return 'limit';
      if (!isSerp()) return 'left';
      if (captchaShown()) return 'captcha';
      if (visible(document.querySelector(SEL.relocation))) return 'relocation';
      if (findModal()) return 'modal';
      if (!item.btn.isConnected || !/Откликнуться/i.test(item.btn.textContent)) return 'applied';
      return null;
    }, 15000);

    // При лимите hh.ru может показать только всплывающее уведомление, а кнопка останется прежней.
    if (!first) return limitHit || limitReached() ? ['limit'] : ['error', 'после нажатия ничего не произошло'];
    if (first === 'limit') {
      await closeModal();
      return ['limit'];
    }
    if (first === 'left') return ['skipped', LEFT_REASON];
    if (first === 'captcha') return ['captcha'];

    if (first === 'relocation') {
      await sleep(rand(700, 1500));
      await humanClick(document.querySelector(SEL.relocation));
      await waitFor(() => !isSerp() || findModal() || !item.btn.isConnected, 8000);
      if (!isSerp()) return ['skipped', LEFT_REASON];
    }

    let modal = findModal();
    if (!modal) {
      // Кнопка могла пропасть из-за SPA-перехода на страницу отклика — адрес меняется чуть позже.
      if (await waitFor(() => !isSerp(), 2000)) return ['skipped', LEFT_REASON];
      if (limitHit || limitReached()) return ['limit'];
      await sleep(rand(1500, 2500)); // даём карточке перерисоваться
      if (limitHit) return ['limit'];
      const ok = responded(item);
      if (ok === false) return ['error', 'отклик не подтвердился: кнопка «Откликнуться» осталась на месте'];
      let note = ok ? 'отклик в один клик' : 'отклик в один клик, не подтверждён';
      if (letter) {
        note += `, ${await attachLetterAfterResponse(letter, attachBefore)}`;
        if (findModal()) await closeModal();
      }
      return ['applied', note];
    }

    await sleep(rand(1000, 2500));
    if (captchaShown()) return ['captcha'];
    if (limitReached(modal)) {
      await closeModal();
      return ['limit'];
    }

    const submit = modal.querySelector(SEL.submit) || buttonByText(modal, /^Откликнуться$/i);
    if (!submit) {
      // После «быстрого» отклика hh показывает окно «Ваш отклик отправлен работодателю… Приложить письмо».
      const done = /отклик (отправлен|доставлен)|вы откликнулись|резюме доставлено/i.test(modal.textContent);
      const note = done && letter ? `, ${await attachLetterAfterResponse(letter, attachBefore)}` : '';
      if (findModal()) await closeModal();
      return done ? ['applied', `отклик в один клик${note}`] : ['skipped', 'непонятная форма отклика'];
    }

    // Анкета/тест работодателя — пропускаем.
    // (радиокнопки тут не признак анкеты — ими выбирают резюме, если их несколько).
    if (modal.querySelectorAll('textarea').length > 1 || /ответьте на вопрос|вопросы работодателя/i.test(modal.textContent)) {
      await closeModal();
      return ['skipped', 'нужно ответить на вопросы работодателя'];
    }

    // Сопроводительное письмо.
    let letterInForm = false; // письмо ушло вместе с откликом
    let input = modal.querySelector(SEL.letterInput) || modal.querySelector('textarea');
    const letterRequired = visible(input) && (submit.disabled || /обязательн/i.test(modal.textContent));
    if (letter) {
      if (!visible(input)) {
        const toggle = modal.querySelector(SEL.letterToggle) || buttonByText(modal, /сопроводительное письмо/i);
        if (toggle) {
          await humanClick(toggle);
          input = await waitFor(() => {
            const el = modal.querySelector(SEL.letterInput) || modal.querySelector('textarea');
            return visible(el) ? el : null;
          }, 5000);
        }
      }
      if (visible(input) && !input.value.trim()) {
        await setStatus(`Пишу письмо: ${item.title}`);
        await humanType(input, letter);
        await sleep(rand(800, 2000));
      }
      letterInForm = visible(input) && !!input.value.trim();
    } else if (letterRequired) {
      await closeModal();
      return ['skipped', s.useLetter ? 'обязательно сопроводительное письмо (нет подходящего текста письма)' : 'обязательно сопроводительное письмо (письма выключены)'];
    }

    if (submit.disabled) {
      await closeModal();
      return ['skipped', 'кнопка отправки неактивна'];
    }

    await setStatus(`Отправляю: ${item.title}`);
    run.pending.submitted = true;
    if (letterInForm) run.letterOwed = null; // письмо уходит вместе с откликом
    await saveRun();
    await humanClick(submit);

    const after = await waitFor(() => {
      if (limitHit) return 'limit';
      if (!isSerp()) return 'left';
      if (captchaShown()) return 'captcha';
      const m = findModal();
      if (!m) return 'closed';
      if (limitReached(m)) return 'limit';
      if (!m.querySelector(SEL.submit) && /отклик (отправлен|доставлен)|вы откликнулись/i.test(m.textContent)) return 'closed';
      return null;
    }, 15000);

    // Как и в resume(): форма уже отправлена, поэтому засчитываем отклик.
    if (after === 'left') return ['applied', 'после отправки hh.ru открыл отдельную страницу'];
    if (after === 'captcha') return ['captcha'];
    if (after === 'limit') {
      await closeModal();
      return ['limit'];
    }
    if (after === 'closed') {
      await sleep(rand(1000, 2000));
      // hh.ru мог закрыть форму и показать уведомление о лимите вместо отправки.
      if (limitHit) return ['limit'];
      // В форме не нашлось поля для письма — прикладываем его после отклика, если hh.ru предложит.
      const note = letter && !letterInForm ? await attachLetterAfterResponse(letter, attachBefore) : '';
      if (findModal()) await closeModal(); // окно «добавьте письмо»/чат после отклика
      return ['applied', note];
    }
    const err = (findModal()?.innerText || '').replace(/\s+/g, ' ').slice(0, 160);
    await closeModal();
    if (limitHit || limitReached()) return ['limit'];
    return ['error', err || 'форма не закрылась'];
  }

  // ---------- навигация ----------
  // Полная загрузка другой страницы: работу продолжит новый экземпляр скрипта (resume).
  async function leaveTo(url) {
    location.replace(url);
    await sleep(30000);
    throw new Error('страница не перезагрузилась');
  }

  // hh.ru увёл со страницы поиска (например, на страницу отклика с вопросами и письмом) — возвращаемся назад.
  async function backToSearch() {
    await setStatus('Возвращаюсь к поиску');
    await sleep(rand(2000, 4000));
    checkLimit(); // сообщение о лимите может быть на отдельной странице отклика
    // «Назад» — только если предыдущая запись истории это та же страница выдачи в этом же документе (SPA-переход).
    const nav = window.navigation;
    const prev = nav?.currentEntry && nav.entries()[nav.currentEntry.index - 1];
    if (prev?.sameDocument && serpPage(prev.url) !== null && serpPage(prev.url) === serpPage(run.returnUrl)) {
      history.back();
      if (await waitFor(() => isSerp() && document.querySelector(SEL.card), 10000)) {
        await sleep(rand(1500, 3000));
        return;
      }
    }
    await leaveTo(run.returnUrl);
  }

  // Плавно долистывает выдачу до конца, чтобы «просмотреть» все вакансии и дойти до пагинации.
  async function scrollToBottom() {
    for (let i = 0; i < 100 && !document.hidden; i++) {
      const bottom = document.documentElement.scrollHeight - window.innerHeight;
      if (window.scrollY >= bottom - 10) break;
      window.scrollTo(0, Math.min(bottom, window.scrollY + window.innerHeight * (0.5 + Math.random() * 0.5)));
      await sleep(rand(120, 350));
    }
    window.scrollTo(0, document.documentElement.scrollHeight);
    await sleep(rand(1000, 2000));
  }

  // Ссылка на следующую страницу: кнопка «дальше», а если её нет — ближайший номер страницы после текущей.
  function nextPageLink() {
    const next = document.querySelector(SEL.next);
    if (next?.getAttribute('href') && next.getAttribute('aria-disabled') !== 'true') return next;
    const cur = Number(serpPage(location.href));
    return (
      [...document.querySelectorAll(SEL.page)]
        .map((a) => ({ a, n: Number(serpPage(a.getAttribute('href') || '')) }))
        .filter(({ n }) => n > cur)
        .sort((x, y) => x.n - y.n)[0]?.a || null
    );
  }

  async function openPage(link) {
    const url = new URL(link.getAttribute('href'), location.origin).href;
    const before = location.href;
    const oldCard = document.querySelector(SEL.card);
    await saveRun({ returnUrl: url });
    await humanClick(link);
    // Полная перезагрузка — цикл продолжит новый экземпляр скрипта; SPA — ждём новые карточки и продолжаем здесь.
    const ok = await waitFor(() => location.href !== before && !oldCard?.isConnected && document.querySelector(SEL.card), 15000);
    if (!ok) await leaveTo(url);
    await sleep(rand(2000, 4000));
  }

  // ---------- письмо, которое не успели приложить ----------
  // Отклик могли прервать (капча, сбой), а он всё равно ушёл: на карточке уже «Вы откликнулись», цикл
  // эту вакансию пропустит — и письмо останется неприложенным, а отклик — несчитанным. Поэтому в начале
  // каждого шага смотрим на отметку run.letterOwed: если отклик ушёл, открываем страницу вакансии,
  // где hh.ru показывает «Приложить письмо» именно для неё, и дальше работает resume().
  // Возвращает true, если ушли на страницу вакансии.
  async function settleOwedLetter() {
    const owed = run.letterOwed;
    run.letterOwed = null;
    await saveRun();
    await sleep(rand(1500, 2500)); // даём странице обработать отклик
    // Карточку ищем по номеру: после перерисовки выдачи старая ссылка на неё не годится.
    const card = [...document.querySelectorAll(SEL.card)].find((c) => vacancyId(c.querySelector(SEL.respond), c) === owed.id);
    const btn = card?.querySelector(SEL.respond);
    const responded = !!card && !(visible(btn) && /Откликнуться/i.test(btn.textContent));
    if (!responded) return false; // отклик не ушёл — обычный путь попробует эту вакансию снова
    await log(`Отклик на «${owed.title}» #${owed.id} ушёл без письма — открываю вакансию, чтобы приложить`, 'skip');
    await saveRun({ pending: { ...owed, submitted: true, letter: true }, status: 'Прикладываю письмо к вакансии' });
    if (!active) return false;
    location.href = new URL(`/vacancy/${owed.id}`, location.origin).href;
    await sleep(30000);
    throw new Error('страница не открылась');
  }

  // ---------- прогресс по выдаче ----------
  // Позиция — место текущей вакансии в выдаче (страница × вакансий на странице + номер карточки),
  // поэтому вакансии, на которые уже откликались раньше, тоже считаются пройденными.
  // Всего — «Найдено N вакансий», но не больше 2000: дальше hh.ru выдачу не листает.
  const RESULTS_CAP = 2000;

  function serpTotal() {
    const m = /найден\S*\s+([\d\s]+)\s+ваканс/i.exec(document.querySelector('[data-qa="title"]')?.textContent || '');
    const found = m ? Number(m[1].replace(/\D/g, '')) : 0;
    return found ? Math.min(found, RESULTS_CAP) : 0;
  }

  function trackProgress(indexOnPage) {
    const total = serpTotal() || run.progress?.total || 0;
    if (!isSerp() || !total) return;
    const page = Number(serpPage(location.href));
    const perPage = Number(new URL(location.href).searchParams.get('items_on_page')) || 20;
    const prev = run.progress || {};
    // На новой странице запоминаем, сколько вакансий уже обработано к её началу.
    const doneBase = prev.page === page ? prev.doneBase : run.done.length;
    // Номер карточки на странице может оказаться меньше реального прогресса (карточки уходят из списка,
    // страница перерисовывается), а обработанные вакансии не обманут: позиция не меньше их числа.
    const handled = run.done.length - doneBase;
    const pos = Math.min(total, page * perPage + Math.max(indexOnPage, handled));
    run.progress = { startPos: prev.startPos ?? pos, startedAt: prev.startedAt ?? Date.now(), page, doneBase, pos, total };
  }

  // ---------- основной цикл ----------
  let loopRunning = false;

  async function loop() {
    if (loopRunning) return;
    loopRunning = true;
    renderPanel();
    try {
      while (active) {
        const lic = await licenseStatus();
        if (!lic.ok) {
          await stopForLicense(lic);
          break;
        }
        if (isLoginPage()) {
          await finish('hh.ru просит войти в аккаунт — войдите и нажмите «Старт»', 'error');
          break;
        }
        if (!isSerp()) {
          await backToSearch();
          continue;
        }
        if (run.breakUntil) {
          // Перерыв после неудачной капчи (назначает takeCaptchaBreak).
          // Прерывается досрочно кнопкой «сбросить таймер капчи» — она обнуляет run.breakUntil.
          const early = !(await countdownUntil(run.breakUntil, 'Перерыв после капчи, продолжу через', () => !run.breakUntil));
          await saveRun({ breakUntil: 0 });
          await log(early ? 'Таймер капчи сброшен вручную — продолжаю отклики' : 'Перерыв после капчи окончен — продолжаю отклики');
        }
        if (run.pause) {
          await countdown(run.pause);
          await saveRun({ pause: 0 });
        }
        if (run.letterOwed && (await settleOwedLetter())) return; // ушли на страницу вакансии — продолжит resume()
        const s = await settings();
        const item = nextCard();
        const pageCards = [...document.querySelectorAll(SEL.card)];
        trackProgress(item ? pageCards.indexOf(item.card) + 1 : pageCards.length);
        if (countEarlier(item?.card)) await saveRun(); // пройденные «ранее обработанные» — в счётчик

        if (!item) {
          await setStatus('Долистываю страницу до конца');
          await scrollToBottom();
          if (nextCard()) continue;
          const next = nextPageLink();
          if (!next) {
            await finish('Вакансии в выдаче закончились');
            break;
          }
          await log(`Страница ${Number(serpPage(location.href)) + 1} пройдена → страница ${Number(serpPage(next.getAttribute('href'))) + 1}`);
          await setStatus('Перехожу на следующую страницу');
          await sleep(rand(3000, 8000));
          await openPage(next);
          continue;
        }

        let result, reason;
        try {
          [result, reason] = await applyTo(item, s);
        } catch (e) {
          if (['stopped', 'limit', 'context'].includes(e.message)) throw e;
          // Неожиданный сбой на одной вакансии — не повод останавливать всю работу.
          if (findModal()) await closeModal().catch(() => {});
          [result, reason] = ['error', `сбой: ${e.message}`];
        }
        run.done.push(item.id);
        run.pending = null;
        if (result !== 'captcha') run.letterOwed = null; // отклик завершён обычным путём

        if (result === 'captcha') {
          const hasKey = !!captchaKey(s);
          const solved = hasKey ? await tryPassCaptcha(s) : false;
          if (solved) {
            if (findModal()) await closeModal();
            run.captchaSeen = (run.captchaSeen || 0) + 1;
            run.done.pop(); // повторяем эту же вакансию (капча уже пройдена)
            run.pending = null;
            await saveRun();
            if (run.captchaSeen > 10) {
              if (await takeCaptchaBreak(s, 'Слишком много капч подряд')) break;
              await finish('Слишком много капч подряд — остановка. Попробуйте позже.', 'error');
              break;
            }
            await log('Капча решена автоматически — продолжаю', 'ok');
            await sleep(rand(1500, 3000));
            continue;
          }
          await saveRun();
          if (hasKey) {
            run.done.pop(); // после перерыва попробуем эту же вакансию снова
            if (await takeCaptchaBreak(s, 'Капчу не удалось решить за 5 попыток')) break;
          }
          await finish(
            hasKey
              ? 'Капчу не удалось решить за 5 попыток — пройдите её вручную и запустите снова'
              : 'hh.ru показал капчу — пройдите её вручную и запустите снова',
            'error'
          );
          break;
        }
        if (result === 'limit') throw new Error('limit');

        run.captchaSeen = 0; // серия капч прервана обычным результатом
        let appliedToday = 0;
        if (result === 'applied') {
          run.applied++;
          appliedToday = await countApply();
          await log(`✔ ${item.title} — ${item.company} #${item.id}${reason ? ` (${reason})` : ''}`, 'ok');
        } else if (result === 'skipped') {
          run.skipped++;
          await log(`↷ ${item.title} #${item.id} — ${reason}`, 'skip');
        } else {
          run.errors++;
          await log(`✖ ${item.title} #${item.id} — ${reason}`, 'error');
        }
        // Одна пауза из настроек после отклика, пропуска и ошибки. Отсчёт идёт в начале следующего шага —
        // уже на странице поиска, даже если возврат на неё перезагрузил страницу.
        run.pause = rand(s.minDelay, s.maxDelay);
        // Много ошибок подряд — почти всегда сломалась страница (вёрстка, выход из аккаунта),
        // а не вакансии. Дальше перебирать выдачу впустую незачем.
        run.errorStreak = result === 'error' ? (run.errorStreak || 0) + 1 : 0;
        await saveRun();
        if (limitHit || appliedToday >= DAILY_LIMIT) throw new Error('limit');
        if (run.errorStreak >= MAX_ERROR_STREAK) {
          await finish(`Остановлено: ${MAX_ERROR_STREAK} ошибок подряд — нажмите «Проверить страницу» в окне расширения`, 'error');
          break;
        }
      }
    } catch (e) {
      try {
        if (e.message === 'context') {
          contextLost();
        } else if (e.message === 'limit') {
          if (findModal()) pressEscape();
          await finish(await limitMessage(), 'error');
        } else if (e.message !== 'stopped') {
          await log(`Ошибка: ${e.message}`, 'error');
          if (!(await recoverByReload())) await finish('Остановлено из-за ошибки', 'error');
        } else {
          if (findModal()) pressEscape();
          await saveRun({ status: 'Остановлено', pending: null });
        }
      } catch (e2) {
        if (e2.message === 'context') contextLost();
      }
    } finally {
      loopRunning = false;
      renderPanel();
    }
  }

  // Неожиданный сбой вне отклика (переход по страницам, возврат к поиску): перезагружаем
  // выдачу и продолжаем — не чаще 3 раз за 30 минут, чтобы не ходить по кругу.
  async function recoverByReload() {
    const now = Date.now();
    const recent = (run.recoveries || []).filter((t) => now - t < 30 * 60 * 1000);
    if (recent.length >= 3) return false;
    run.recoveries = [...recent, now];
    run.pending = null;
    await saveRun({ status: 'Перезагружаю страницу после сбоя' });
    await log('Перезагружаю страницу и продолжаю работу');
    location.replace(run.returnUrl || location.href);
    return true;
  }

  // Расширение обновили или перезапустили: этот скрипт больше не может ни читать настройки,
  // ни писать журнал. Останавливаемся и просим перезагрузить страницу.
  let contextGone = false;
  function contextLost() {
    contextGone = true; // дальше панель показывает только это сообщение
    active = false;
    owned = false;
    stopAll();
    HH.panel.alert('Расширение обновлено — перезагрузите страницу (F5) и нажмите «Старт»');
  }

  async function countdown(sec) {
    await countdownUntil(Date.now() + sec * 1000, 'Следующее действие через');
  }

  // «45 с» или «9 мин 05 с».
  function fmtLeft(sec) {
    return sec >= 60 ? `${Math.floor(sec / 60)} мин ${String(sec % 60).padStart(2, '0')} с` : `${sec} с`;
  }

  // Отсчёт до момента времени end (мс): считаем по часам, а не шагами, поэтому
  // если браузер разбудил вкладку позже или её перезагрузили, лишнее не копится.
  // cancelled() — необязательная проверка досрочного прерывания; возвращает false, если прервали.
  async function countdownUntil(end, label, cancelled = () => false) {
    for (let left = Math.ceil((end - Date.now()) / 1000); left > 0; left = Math.ceil((end - Date.now()) / 1000)) {
      if (cancelled()) return false;
      await setStatus(`${label} ${fmtLeft(left)}`);
      await sleep(Math.min(5000, end - Date.now()));
    }
    return !cancelled();
  }

  // Капча не пройдена. Если в настройках задан перерыв — назначаем его и
  // перезагружаем страницу (так закрывается окно капчи). Ждать и продолжать
  // будет новый экземпляр скрипта: resume() → loop() → отсчёт до run.breakUntil.
  // Возвращает false, если перерыв отключён (0) — тогда запуск останавливается.
  async function takeCaptchaBreak(s, why) {
    const min = Math.max(0, Math.floor(Number(s.captchaBreak) || 0));
    if (!min) return false;
    run.pending = null;
    run.pause = 0;
    run.captchaSeen = 0;
    run.breakUntil = Date.now() + min * 60000;
    await saveRun();
    const until = new Date(run.breakUntil).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
    await log(`${why} — перерыв ${min} мин (до ${until}), потом продолжу сам`, 'skip');
    if (isSerp()) location.reload();
    else location.replace(run.returnUrl);
    await sleep(30000);
    throw new Error('страница не перезагрузилась');
  }

  async function finish(msg, kind = 'info') {
    active = false;
    if (!owned) return;
    await store.set({ active: false });
    await log(msg, kind);
    run.status = msg;
    run.pending = null;
    await store.set({ run });
    renderPanel();
  }

  // ---------- лицензия (license.js) ----------
  // Файл ключей проверяет фоновая часть; здесь — только чтение её записи, без сети.
  async function licenseStatus() {
    const { license } = await store.get('license');
    return HHLicense.status(license);
  }

  // Перед стартом — свежая сверка с файлом: ключ могли отозвать или выдать новый.
  async function licenseCheckNow() {
    try {
      const st = await chrome.runtime.sendMessage({ type: 'licenseCheck' });
      if (st) return st;
    } catch {}
    return licenseStatus();
  }

  // Срок вышел посреди работы: останавливаемся вместе с вкладками-помощниками.
  async function stopForLicense(st) {
    await store.set({ stopChores: Date.now() });
    await finish(HHLicense.message(st), 'error');
  }

  // ---------- вкладки-помощники (поднятие резюме, удаление отказов) ----------
  // Основная вкладка просит фоновую часть открыть помощника. Сначала — «Мои резюме»: ждём, пока
  // резюме поднимутся и вкладка закроется. Потом отклики идут здесь, а отказы удаляются параллельно
  // в своей вкладке (если включено). Код самих действий — prestart.js.
  const CHORE_LABELS = { bump: 'Поднятие резюме', clear: 'Очистка отказов' };
  const BUMP_WAIT = 3 * 60 * 1000;
  const MAX_CLEAR_ROUNDS = 50;

  async function openChore(chore) {
    try {
      const res = await chrome.runtime.sendMessage({ type: 'openChore', chore, origin: location.origin });
      if (res?.ok) return true;
      await log(`${CHORE_LABELS[chore]}: не удалось открыть вкладку${res?.error ? ` (${res.error})` : ''}`, 'error');
    } catch (e) {
      if (/context invalidated/i.test(e.message) || !store.alive()) throw new Error('context');
    }
    return false;
  }

  async function launch(s) {
    if (s.bumpResume && (await openChore('bump'))) {
      await setStatus('Поднимаю резюме в отдельной вкладке');
      const end = Date.now() + BUMP_WAIT;
      for (;;) {
        const { chore_bump: st } = await store.get('chore_bump');
        if (st?.state !== 'running') break;
        if (Date.now() > end) {
          await chrome.runtime.sendMessage({ type: 'closeChore', chore: 'bump', note: 'не дождался' }).catch(() => {});
          await log('Поднятие резюме: вкладка не ответила за 3 минуты — продолжаю без неё', 'skip');
          break;
        }
        await sleep(2000);
      }
    }
    if (s.clearRejections) await openChore('clear'); // работает параллельно, не ждём
    loop();
  }

  // ---------- работа во вкладке-помощнике ----------
  // Своё «идёт/остановлено»: помощник не зависит от основного запуска и останавливается
  // только кнопкой «Стоп» (stopChores), а не когда отклики закончились.
  let choreActive = false;

  async function clearChore(ps, t) {
    const { clearProgress } = await store.get('clearProgress');
    const c = clearProgress || { total: 0, titles: [], rounds: 0, expected: 0, startedAt: Date.now() };
    // Прогресс: во вкладке (панель), в окне расширения и между перезагрузками списка (clearProgress).
    const publish = (done) => {
      // Удалено больше, чем «всего»: счётчик на странице был не тот — процент не показываем.
      if (c.expected && done > c.expected) c.expected = 0;
      const status = c.expected ? `Удаляю отказы: ${done} из ${c.expected}` : `Удаляю отказы: ${done}`;
      HH.panel.renderChore({ title: 'Удаление отказов', done, expected: c.expected, startedAt: c.startedAt, status });
      store.set({ chore_clear: { state: 'running', total: done, expected: c.expected } }).catch(() => {});
    };
    HH.panel.setOnStop(() => chrome.storage.local.set({ stopChores: Date.now() }));
    publish(c.total);
    const r = await ps.clearRejections(
      (n) => publish(c.total + n),
      // Счётчик у фильтра «Отказ» — сколько отказов осталось в списке: всего = уже удалено + остаток.
      (left) => {
        if (left != null) c.expected = c.total + left;
        publish(c.total);
      },
      c.skip || [] // карточки, которые не удалились в прошлых порциях, не трогаем
    );
    c.total += r.removed.length;
    for (const title of r.removed) if (c.titles.length < 10) c.titles.push(title);
    c.skip = [...new Set([...(c.skip || []), ...r.failed.map((f) => f.key)])];
    c.failedTitles = [...new Set([...(c.failedTitles || []), ...r.failed.map((f) => f.title)])];
    c.rounds++;
    if (r.removed.length && c.rounds < MAX_CLEAR_ROUNDS) {
      // Порция удалена — перезагружаем список: подтянется следующая. Итог копится в clearProgress.
      await store.set({ clearProgress: c, chore_clear: { state: 'running', total: c.total, expected: c.expected } });
      await t.sleep(rand(1500, 3000));
      location.reload();
      return null;
    }
    await store.set({ clearProgress: null });
    if (!r.loaded && !c.total) return `список откликов не загрузился (${describeSnap(r.snap)})`;

    const failedNote = c.failedTitles.length
      ? ` Не получилось удалить ${c.failedTitles.length}: ${c.failedTitles.slice(0, 5).map((x) => `«${x}»`).join(', ')}${c.failedTitles.length > 5 ? ' и др.' : ''}.`
      : '';
    // Если по счётчику у фильтра отказы ещё остались, а расширение их не удалило — показываем, что оно видит.
    const leftNote = r.snap.chip > 0 || r.snap.rejected > 0 ? ` На странице осталось: ${describeSnap(r.snap)}.` : '';
    if (!c.total) return `отказов для удаления не нашёл (${describeSnap(r.snap)}).${failedNote}`;
    const list = c.titles.map((x) => `«${x}»`).join(', ');
    return `удалено ${c.total}: ${list}${c.total > c.titles.length ? ' и др.' : '.'} Вернуть можно во вкладке «Удалённые».` + failedNote + leftNote +
      (c.rounds >= MAX_CLEAR_ROUNDS && r.removed.length ? ` Остановился после ${MAX_CLEAR_ROUNDS} перезагрузок списка — остаток удалю при следующем старте.` : '');
  }

  // «карточек 20, с пометкой «Отказ» 17, кнопок «Удалить» 21, счётчик у фильтра 17» — для журнала.
  function describeSnap(sn) {
    return `карточек ${sn.cards}, с пометкой «Отказ» ${sn.rejected}, кнопок «Удалить» ${sn.deletes}, счётчик у фильтра ${sn.chip ?? 'не найден'}`;
  }

  async function runChore(chore) {
    choreActive = true;
    const t = HH.makeTiming(() => choreActive);
    const h = HH.makeHuman({ sleep: t.sleep });
    const ps = HH.makePrestart({ sleep: t.sleep, waitFor: t.waitFor, humanClick: h.humanClick, humanScrollTo: h.humanScrollTo });
    chrome.storage.onChanged.addListener((changes) => {
      if (changes.stopChores?.newValue) {
        choreActive = false;
        t.stopAll();
      }
    });
    await new Promise((r) => setTimeout(r, rand(1500, 3000))); // страница дорисовывается
    let note;
    try {
      if (isLoginPage()) note = 'hh.ru просит войти в аккаунт';
      else if (chore === 'bump') note = await ps.bumpResumes();
      else note = await clearChore(ps, t);
    } catch (e) {
      if (e.message === 'context') return;
      note = e.message === 'stopped' ? 'остановлено' : `не получилось: ${e.message}`;
    }
    if (note === null) return; // страница перезагружается — работу продолжит новый экземпляр скрипта
    await log(`${CHORE_LABELS[chore]}: ${note}`).catch(() => {});
    chrome.runtime.sendMessage({ type: 'choreDone', chore, note }).catch(() => {});
  }

  async function start() {
    if (!isSerp()) return { ok: false, error: 'Откройте страницу поиска вакансий hh.ru' };
    if (loopRunning && owned) return { ok: true };
    myTabId ??= await whoami();
    if (myTabId == null) return { ok: false, error: 'Не удалось определить вкладку — обновите страницу' };
    const lic = await licenseCheckNow();
    if (!lic.ok) return { ok: false, error: HHLicense.message(lic) };
    if ((await recentApplies()).length >= DAILY_LIMIT) return { ok: false, error: await limitMessage() };
    // Прежняя отметка о лимите снимается: если лимит ещё действует, hh.ru покажет его снова.
    limitHit = false;
    limitInfo = null;
    await store.set({ limit: null });
    while (loopRunning) await new Promise((r) => setTimeout(r, 100)); // прежний цикл этой вкладки ещё завершается
    // Если запуск шёл в другой вкладке, она увидит новый tabId и остановится сама.
    const s = await settings();
    run = { tabId: myTabId, applied: 0, skipped: 0, errors: 0, done: [], pending: null, returnUrl: location.href, heartbeat: Date.now(), status: 'Запуск' };
    owned = true;
    active = true;
    await store.set({ active: true, run });
    // Версия в журнале: после обновления расширения открытая вкладка hh.ru
    // продолжает работать со старым скриптом, пока её не перезагрузить.
    await log(`Старт v${chrome.runtime.getManifest().version}: ${decodeURIComponent(location.search).slice(0, 120)}`);
    launch(s).catch((e) => {
      if (e.message === 'context') contextLost();
      else if (e.message !== 'stopped') loop();
    });
    return { ok: true };
  }

  chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
    if (msg?.type === 'start') {
      start().then(reply);
      return true;
    }
    if (msg?.type === 'ping') reply({ ok: true, isSerp: isSerp(), running: loopRunning });
    if (msg?.type === 'selfcheck') {
      (async () =>
        HH.selfCheck({
          version: chrome.runtime.getManifest().version,
          recentApplies: (await recentApplies()).length,
          dailyLimit: DAILY_LIMIT,
          limitOnPage: limitReached(),
          license: await licenseStatus(),
        }))()
        .then((items) => reply({ ok: true, items, running: loopRunning && active }))
        .catch((e) => reply({ ok: false, error: e.message }));
      return true;
    }
  });

  // ---------- продолжение после перезагрузки/перехода ----------
  async function resume() {
    myTabId = await whoami();
    const { active: a, run: r, limit } = await store.get(['active', 'run', 'limit']);
    limitInfo = limit || null;
    // Продолжаем только в той вкладке, где запускали: другие вкладки hh.ru запуск не трогают.
    if (!a || !r || myTabId == null || r.tabId !== myTabId) return;
    // Во время перерыва после капчи запуск «жив» до его конца (+ обычный запас),
    // даже если вкладку выгружали и отсчёт на ней не шёл.
    const lastAlive = Math.max(r.heartbeat || 0, r.breakUntil || 0);
    if (Date.now() - lastAlive > HEARTBEAT_TTL) {
      await store.set({ active: false });
      return;
    }
    run = r;
    owned = true;
    active = true;
    limitHit = false;
    // Страница, отданная сервером целиком, не порождает «новых» элементов — проверяем её текст сразу.
    const stopIfLimit = async () => {
      if (!limitHit && !limitReached()) return false;
      await finish(await limitMessage(), 'error');
      return true;
    };

    if (isLoginPage()) {
      await finish('hh.ru просит войти в аккаунт — войдите и нажмите «Старт»', 'error');
      return;
    }

    if (!isSerp()) {
      // Клик по «Откликнуться» увёл со страницы поиска (анкета/тест работодателя).
      if (run.pending) {
        const p = run.pending;
        run.done.push(p.id);
        if (p.submitted) {
          run.applied++;
          await countApply();
          const note = p.letter ? await attachLetterOnThisPage(p) : '';
          await log(`✔ ${p.title} #${p.id}${note ? ` (${note})` : ''}`, 'ok');
        } else {
          run.skipped++;
          await log(`↷ ${p.title} #${p.id} — ${LEFT_REASON}`, 'skip');
        }
        run.pending = null;
        const s = await settings();
        run.pause = rand(s.minDelay, s.maxDelay);
      }
      await saveRun({ status: 'Возвращаюсь к поиску' });
      renderPanel();
      await new Promise((r2) => setTimeout(r2, rand(3000, 6000)));
      if (await stopIfLimit()) return;
      if (active) location.href = run.returnUrl;
      return;
    }

    if (run.pending) {
      run.done.push(run.pending.id);
      run.pending = null;
    }
    await saveRun({ returnUrl: location.href });
    await new Promise((r2) => setTimeout(r2, rand(2000, 4000)));
    if (await stopIfLimit()) return;
    loop();
  }

  // ---------- плавающая панель (panel.js) ----------
  function renderPanel() {
    if (run && !contextGone) HH.panel.render({ run, active, limitText: limitLine(limitInfo) });
  }

  HH.panel.setOnStop(async () => {
    active = false;
    try {
      await store.set({ active: false, stopChores: Date.now() });
      await log('Остановлено пользователем');
    } catch (e) {
      if (e.message === 'context') return contextLost();
    }
    renderPanel();
  });

  (async () => {
    let chore = null;
    try {
      chore = await chrome.runtime.sendMessage({ type: 'myChore' });
    } catch {}
    if (chore) return runChore(chore);
    return resume();
  })().catch((e) => {
    if (e.message === 'context') contextLost();
  });
})();

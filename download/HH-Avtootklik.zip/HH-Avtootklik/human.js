// «Человеческие» действия: плавная прокрутка, клик со всеми событиями мыши, ввод текста.
// sleep приходит из timing.js — все паузы прерываются кнопкой «Стоп».
(globalThis.HH ||= {}).makeHuman = ({ sleep }) => {
  const { rand, visible } = HH.dom;

  async function humanScrollTo(el) {
    const target = el.getBoundingClientRect().top + window.scrollY - window.innerHeight * (0.25 + Math.random() * 0.2);
    if (document.hidden) {
      // Скрытую страницу никто не видит, а каждый шаг прокрутки стоил бы минуту.
      window.scrollTo(0, target);
      return;
    }
    const steps = rand(4, 9);
    const start = window.scrollY;
    for (let i = 1; i <= steps; i++) {
      window.scrollTo(0, start + ((target - start) * i) / steps);
      await sleep(rand(60, 180));
    }
  }

  async function humanClick(el) {
    if (!el) throw new Error('нет элемента для нажатия');
    if (!visible(el)) el.scrollIntoView({ block: 'center' });
    await sleep(rand(250, 700));
    const r = el.getBoundingClientRect();
    const o = {
      bubbles: true,
      cancelable: true,
      clientX: r.left + r.width * (0.3 + Math.random() * 0.4),
      clientY: r.top + r.height * (0.3 + Math.random() * 0.4),
      button: 0,
    };
    el.dispatchEvent(new PointerEvent('pointerover', o));
    el.dispatchEvent(new MouseEvent('mouseover', o));
    await sleep(rand(80, 300));
    el.dispatchEvent(new PointerEvent('pointerdown', o));
    el.dispatchEvent(new MouseEvent('mousedown', o));
    await sleep(rand(60, 160));
    el.dispatchEvent(new PointerEvent('pointerup', o));
    el.dispatchEvent(new MouseEvent('mouseup', o));
    el.click();
  }

  // Посимвольный ввод. Нативный сеттер value + событие input — так React видит изменение.
  async function humanType(el, value) {
    el.focus();
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    const chars = [...value];
    let current = '';
    for (const ch of chars) {
      // В скрытой вкладке каждый символ ждал бы до минуты (письмо в 130 символов — больше 2 часов),
      // поэтому остаток вставляется целиком, как из буфера обмена.
      current = document.hidden ? value : current + ch;
      setter.call(el, current);
      el.dispatchEvent(new Event('input', { bubbles: true }));
      if (current === value) break;
      await sleep(ch === ' ' || ch === '\n' ? rand(40, 160) : rand(15, 70));
    }
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  return { humanScrollTo, humanClick, humanType };
};

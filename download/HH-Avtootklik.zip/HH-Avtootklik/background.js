importScripts('license.js');

// Сообщает content script номер его вкладки: запуск привязан к одной вкладке
// и не «перепрыгивает» в другие открытые страницы hh.ru.
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg?.type === 'whoami') {
    reply(sender.tab?.id ?? null);
    return; // синхронный ответ
  }
  if (msg?.type === 'solveCaptcha') {
    // Решение капчи выполняем здесь (в service worker): у него есть
    // host_permissions на сервисы, поэтому CORS не мешает.
    handleSolveCaptcha(msg.imageBase64)
      .then((text) => reply({ text }))
      .catch((e) => reply({ error: e?.code || String((e && e.message) || e) }));
    return true; // ответ придёт асинхронно
  }
});

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

// Выбирает сервис по настройкам и решает капчу.
async function handleSolveCaptcha(imageBase64) {
  const { settings } = await chrome.storage.local.get('settings');
  const service = settings?.captchaService || 'rucaptcha';

  if (service === 'qwen') {
    const key = (settings?.polzaKey || '').trim();
    if (!key) {
      const err = new Error('no_key');
      err.code = 'no_key';
      throw err;
    }
    return solveWithQwen(key, imageBase64);
  }

  return solveWithSharedKey(imageBase64);
}

// ---------- RuCaptcha через сервер (общий ключ) ----------
// Ключ RuCaptcha есть только на сервере. Расширение отдаёт картинку и свой ID, сервер проверяет
// лицензию и лимит, отправляет капчу в RuCaptcha своим ключом и отдаёт ответ.
const SHARED_ERRORS = {
  no_license: 'нет действующей лицензии',
  limit: 'лимит капч через общий ключ исчерпан — попробуйте позже',
  service_unavailable: 'сервис капчи временно недоступен',
  not_configured: 'общий ключ капчи не настроен на сервере',
  bad_image: 'не удалось передать картинку',
  rejected: 'RuCaptcha отклонил картинку',
  unsolvable: 'RuCaptcha не смог решить капчу',
  unknown_task: 'сервер потерял задачу',
};

async function sharedCall(path, body) {
  const { userId } = await licenseTask(readLicense);
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 20000);
  try {
    const resp = await fetch(HHLicense.CAPTCHA_URL + path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      cache: 'no-store',
      signal: ctl.signal,
      body: JSON.stringify({ ext_id: userId, ...body }),
    });
    const data = await resp.json().catch(() => ({}));
    if (!data.ok) throw new Error(SHARED_ERRORS[data.reason] || `сервер: ${data.reason || resp.status}`);
    return data;
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('сервер капчи не ответил');
    if (e instanceof TypeError) throw new Error('нет связи с сервером капчи');
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

async function solveWithSharedKey(imageBase64) {
  const { id } = await sharedCall('', { image: imageBase64 });
  await sleep(6000);
  const deadline = Date.now() + 120000;
  while (Date.now() < deadline) {
    const data = await sharedCall('/result', { id });
    if (data.ready) return String(data.text || '').trim();
    await sleep(5000);
  }
  throw new Error('Превышено время ожидания решения капчи');
}

// ---------- Qwen (polza.ai, vision) ----------
const POLZA_URL = 'https://api.polza.ai/api/v1/chat/completions';
const QWEN_MODEL = 'qwen/qwen3-vl-8b-instruct';
// Слова просим через пробел: из такого ответа без потерь получаются оба формата
// (с пробелом и слитно), а из слитного пробел уже не восстановить.
const QWEN_PROMPT =
  'На картинке капча — искажённые русские слова (обычно два). ' +
  'Выведи их строчными русскими буквами (только кириллица), разделяя слова ' +
  'одним пробелом. Без кавычек, пояснений и знаков препинания.';

async function solveWithQwen(apiKey, imageBase64) {
  const payload = {
    model: QWEN_MODEL,
    temperature: 0,
    max_tokens: 40,
    messages: [
      {
        role: 'user',
        content: [
          { type: 'text', text: QWEN_PROMPT },
          {
            type: 'image_url',
            image_url: { url: `data:image/png;base64,${imageBase64}` },
          },
        ],
      },
    ],
  };

  // Сеть до polza.ai бывает нестабильной — делаем несколько повторов.
  let lastErr = null;
  for (let attempt = 0; attempt < 4; attempt++) {
    try {
      const resp = await fetch(POLZA_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify(payload),
      });
      if (!resp.ok) {
        const txt = await resp.text();
        throw new Error(`polza HTTP ${resp.status}: ${txt.slice(0, 120)}`);
      }
      const data = await resp.json();
      const content = data?.choices?.[0]?.message?.content || '';
      return String(content).trim();
    } catch (e) {
      lastErr = e;
      await sleep(1200 + attempt * 800);
    }
  }
  throw lastErr || new Error('polza: не удалось получить ответ');
}

// ---------- защита вкладки от выгрузки ----------
// Пока идёт работа, вкладка с запуском не выгружается браузером из памяти — то же, что выключить
// «Auto Discardable» для неё в browser://discards. После остановки настройка возвращается.
// Замедление и заморозку скрытой вкладки это не отменяет: для них — флаги запуска браузера (README).
async function syncKeepTab() {
  const { active, run, keepTabId = null } = await chrome.storage.local.get(['active', 'run', 'keepTabId']);
  const want = active && run?.tabId != null ? run.tabId : null;
  if (want === keepTabId) return;
  if (keepTabId != null) await chrome.tabs.update(keepTabId, { autoDiscardable: true }).catch(() => {}); // вкладку могли закрыть
  if (want != null) await chrome.tabs.update(want, { autoDiscardable: false }).catch(() => {});
  await chrome.storage.local.set({ keepTabId: want });
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && (changes.active || changes.run)) syncKeepTab();
});
chrome.runtime.onStartup.addListener(syncKeepTab);
chrome.runtime.onInstalled.addListener(syncKeepTab);

// ---------- вкладки-помощники: поднятие резюме и удаление отказов ----------
// При «Старт» основная вкладка просит открыть помощника. Помощник — обычная вкладка hh.ru в фоне:
// его скрипт спрашивает «какая у меня задача?» (myChore), выполняет её и сообщает об окончании
// (choreDone), после чего вкладка закрывается. Состояние — в chore_bump / chore_clear.
const CHORE_URLS = {
  bump: '/applicant/resumes',
  clear: '/applicant/negotiations?filter=all&state=DISCARD',
};

async function getChoreTabs() {
  const { choreTabs = {} } = await chrome.storage.local.get('choreTabs');
  return choreTabs;
}

async function openChore(chore, origin) {
  const choreTabs = await getChoreTabs();
  for (const [id, c] of Object.entries(choreTabs)) {
    if (c !== chore) continue;
    const alive = await chrome.tabs.get(Number(id)).then(() => true, () => false);
    if (alive) return Number(id); // такая вкладка уже работает — второй не открываем
    delete choreTabs[id];
  }
  const tab = await chrome.tabs.create({ url: origin + CHORE_URLS[chore], active: false });
  choreTabs[tab.id] = chore;
  const extra = chore === 'clear' ? { clearProgress: null } : {};
  await chrome.storage.local.set({ choreTabs, [`chore_${chore}`]: { state: 'running', at: Date.now() }, ...extra });
  // Вкладку отказов браузер не выгрузит (как «Auto Discardable» в browser://discards).
  // Вкладке резюме это не нужно: она закрывается через несколько секунд.
  if (chore === 'clear') chrome.tabs.update(tab.id, { autoDiscardable: false }).catch(() => {});
  return tab.id;
}

async function finishChore(tabId, note, state = 'done') {
  const choreTabs = await getChoreTabs();
  const chore = choreTabs[tabId];
  if (!chore) return;
  delete choreTabs[tabId];
  await chrome.storage.local.set({ choreTabs, [`chore_${chore}`]: { state, note, at: Date.now() } });
  chrome.tabs.remove(tabId).catch(() => {});
}

// «Стоп» в окне расширения или на панели: закрываем все вкладки-помощники.
async function stopChores() {
  for (const id of Object.keys(await getChoreTabs())) await finishChore(Number(id), 'остановлено', 'stopped');
}

// Журнал пишет только фоновая часть, по очереди: вкладки работают одновременно,
// и прямые записи из нескольких вкладок затирали бы друг друга.
let logQueue = Promise.resolve();
function appendLog(entry) {
  const next = logQueue.then(async () => {
    const { log = [] } = await chrome.storage.local.get('log');
    log.push(entry);
    await chrome.storage.local.set({ log: log.slice(-300) });
  });
  logQueue = next.catch(() => {});
  return next;
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  const tabId = sender.tab?.id;
  switch (msg?.type) {
    case 'log':
      appendLog(msg.entry).then(() => reply(true), () => reply(false));
      return true;
    case 'sleep':
      // Пауза для скрытой вкладки: таймеры фоновой части браузер не замедляет, а ответ
      // доходит до вкладки сразу. Сама вкладка ждала бы до минуты на каждую паузу.
      setTimeout(() => reply(true), Math.max(0, Math.min(Number(msg.ms) || 0, 5 * 60 * 1000)));
      return true;
    case 'openChore':
      openChore(msg.chore, msg.origin).then((id) => reply({ ok: true, tabId: id }), (e) => reply({ ok: false, error: e.message }));
      return true;
    case 'myChore':
      getChoreTabs().then((t) => reply(tabId != null ? t[tabId] || null : null));
      return true;
    case 'choreDone':
      finishChore(tabId, msg.note).then(() => reply(true));
      return true;
    case 'closeChore':
      getChoreTabs().then(async (t) => {
        for (const [id, c] of Object.entries(t)) if (c === msg.chore) await finishChore(Number(id), msg.note || 'закрыто', 'stopped');
        reply(true);
      });
      return true;
    case 'licenseInit':
      initLicense().then(reply, () => reply(null));
      return true;
    case 'licenseCheck':
      checkLicense().then((lic) => reply(HHLicense.status(lic)), () => reply(null));
      return true;
    case 'licenseActivate':
      activateLicense(msg.key).then(reply, (e) => reply({ ok: false, error: e.message }));
      return true;
    default:
      return undefined; // остальные сообщения обрабатывает обработчик выше
  }
});

// Вкладку-помощника закрыли руками — отмечаем, чтобы основная вкладка не ждала её.
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const t = await getChoreTabs();
  if (t[tabId]) await finishChore(tabId, 'вкладку закрыли', 'stopped');
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.stopChores?.newValue) stopChores();
});

// ---------- лицензия (license.js) ----------
// Лицензию проверяет сервер. Только фоновая часть ходит на него и пишет запись license: окно
// расширения и вкладки её лишь читают. Так ID не создаётся дважды, а проверки не затирают друг друга.
let licenseQueue = Promise.resolve();
function licenseTask(fn) {
  const next = licenseQueue.then(fn);
  licenseQueue = next.catch(() => {});
  return next;
}

async function readLicense() {
  const { license } = await chrome.storage.local.get('license');
  if (license?.userId) return license;
  const fresh = { userId: HHLicense.newUserId(), exp: 0, checkedAt: 0, reason: '', error: '' };
  await chrome.storage.local.set({ license: fresh });
  return fresh;
}

// Спрашивает сервер (при вводе ключа передаёт его). Сеть недоступна — прежнее состояние остаётся
// (license.js даёт запас 3 дня). Ответ сервера принимается, только если подпись верна.
async function refreshLicense(key) {
  const lic = await readLicense();
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 15000);
  try {
    const resp = await fetch(HHLicense.API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      cache: 'no-store',
      signal: ctl.signal,
      body: JSON.stringify({ ext_id: lic.userId, ...(key ? { key } : {}) }),
    });
    const data = await resp.json().catch(() => ({}));
    if (data.ok) {
      if (data.ext_id === lic.userId && (await HHLicense.verifyToken(data))) {
        Object.assign(lic, { exp: data.exp * 1000, reason: '', error: '', checkedAt: Date.now() });
      } else {
        lic.error = 'подпись сервера не подтверждена'; // не доверяем — прежнее состояние остаётся
      }
    } else {
      // Сервер явно сказал: лицензии нет / истекла / отозвана / неверный ключ.
      // exp (прошедший) приходит и здесь — по нему отличаем «истекла» от «нет ключа».
      Object.assign(lic, { exp: (data.exp || 0) * 1000, reason: data.reason || 'no_key', error: '', checkedAt: Date.now() });
    }
  } catch (e) {
    lic.error = e.name === 'AbortError' ? 'сервер не ответил за 15 секунд'
      : e instanceof TypeError ? 'нет связи с сервером лицензий' : String(e.message || e);
  } finally {
    clearTimeout(timer);
  }
  lic.triedAt = Date.now();
  await chrome.storage.local.set({ license: lic });
  return lic;
}

const checkLicense = () => licenseTask(() => refreshLicense());

// Окно расширения открылось: ID нужен сразу, а проверку на сервере — если она давно не проходила.
async function initLicense() {
  const lic = await licenseTask(readLicense);
  if (Date.now() - (lic.triedAt || 0) > 60 * 60 * 1000) checkLicense();
  return lic;
}

function activateLicense(raw) {
  const key = HHLicense.norm(raw);
  return licenseTask(async () => {
    if (!key) return { ok: false, error: 'Введите ключ' };
    const lic = await refreshLicense(key);
    if (lic.error) return { ok: false, error: `Не удалось проверить ключ: ${lic.error}` };
    const st = HHLicense.status(lic);
    if (st.ok) return { ok: true, status: st };
    if (lic.reason === 'bad_key') {
      return { ok: false, error: 'Такого ключа для вашего ID нет. Проверьте ключ; если его выдали только что — повторите через минуту.' };
    }
    return { ok: false, error: HHLicense.message(st, 'в этом окне') };
  });
}

// Проверка раз в 6 часов: так доходят отзыв ключа и продление, и не кончаются 3 дня без проверки.
const LICENSE_ALARM = 'license';
async function scheduleLicense() {
  if (!(await chrome.alarms.get(LICENSE_ALARM))) chrome.alarms.create(LICENSE_ALARM, { periodInMinutes: 6 * 60 });
  checkLicense();
}
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === LICENSE_ALARM) checkLicense();
});
chrome.runtime.onStartup.addListener(scheduleLicense);
chrome.runtime.onInstalled.addListener(scheduleLicense);

// Лицензия: доступ по ключу на 30 дней.
//
// Владелец ведёт публичный текстовый файл (FILE_URL), по строке на ключ:
//   UserID - Key
// UserID расширение создаёт само при первом запуске и показывает в окне. Пользователь вводит ключ;
// если в файле есть строка с его UserID и этим ключом, доступ открывается на 30 дней с момента ввода.
// Продление — новая строка с новым ключом: 30 дней добавляются к концу текущего срока.
// Строку удалили из файла — ключ перестаёт действовать при следующей проверке.
//
// Общий файл: его подключают фоновая часть (скачивает файл и единственная пишет запись license),
// окно расширения и скрипт на странице (только читают). Здесь — только расчёты, без сети и хранилища.
var HHLicense = (() => {
  // Файл должен быть публичным: расширение читает его без входа в GitHub. HEAD — основная ветка.
  const FILE_URL = 'https://raw.githubusercontent.com/jankdank/HHCrawler-keys/HEAD/licenses.txt';
  const DAY = 24 * 60 * 60 * 1000;
  const TERM = 30 * DAY; // срок одного ключа
  const OFFLINE_GRACE = 3 * DAY; // столько расширение работает, если файл ключей не скачивается
  const ID_ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ'; // без I, L, O, U — их путают с 1, 0 и V
  // Бот, где продаются ключи. Ссылка передаёт ID (start=hh_<ID>), и бот сразу предлагает способ оплаты.
  const BOT_URL = 'https://t.me/LicenseHelper_bot';
  const buyUrl = (userId) => (userId ? `${BOT_URL}?start=hh_${userId}` : BOT_URL);

  // Ключи и ID сравниваются без учёта регистра и пробелов.
  const norm = (s) => String(s || '').replace(/\s+/g, '').toUpperCase();

  function newUserId() {
    const chars = [...crypto.getRandomValues(new Uint8Array(8))].map((b) => ID_ALPHABET[b % 32]).join('');
    return `${chars.slice(0, 4)}-${chars.slice(4)}`;
  }

  // Текст файла → { pairs: сколько всего строк с ключами, keys: ключи этого пользователя }.
  // Всё после «#» — комментарий. Разделитель — тире с пробелами вокруг («ABCD-1234 - KEY»);
  // подойдут и пробел, «:», «|», «;». Тире без пробелов («ABCD-1234-KEY») — нет: в ID и ключах есть дефисы.
  function parse(text, userId) {
    const id = norm(userId);
    const keys = [];
    let pairs = 0;
    for (const line of String(text).split(/\r?\n/)) {
      const parts = line
        .replace(/#.*/, '')
        .split(/[\s:;|=]+/)
        .map((p) => p.replace(/^[-–—]+|[-–—]+$/g, ''))
        .filter(Boolean);
      if (parts.length < 2) continue;
      pairs++;
      if (norm(parts[0]) === id) keys.push(norm(parts[1]));
    }
    return { pairs, keys };
  }

  // Конец срока по введённым ключам, которые есть в файле. Ключи идут по очереди:
  // каждый добавляет 30 дней к концу предыдущего, так что продление заранее дни не съедает.
  function until(lic) {
    const inFile = new Set(lic?.fileKeys || []);
    let end = 0;
    for (const k of [...(lic?.keys || [])].sort((a, b) => a.at - b.at)) {
      if (inFile.has(k.key)) end = Math.max(end, k.at) + TERM;
    }
    return end;
  }

  // lic — запись license из chrome.storage.local:
  // { userId, keys: [{ key, at }], fileKeys, checkedAt, error }.
  // at и checkedAt — время по часам GitHub (заголовок Date), а не по часам компьютера.
  function status(lic, now = Date.now()) {
    // Время не раньше последней проверки: перевод часов назад срок не продлевает.
    now = Math.max(now, lic?.checkedAt || 0);
    const base = { userId: lic?.userId || '', error: lic?.error || '' };
    if (!lic?.keys?.length) return { ...base, ok: false, reason: 'no_key' };
    const end = until(lic);
    if (!end) return { ...base, ok: false, reason: 'revoked' };
    if (now >= end) return { ...base, ok: false, reason: 'expired', until: end };
    if (now - lic.checkedAt > OFFLINE_GRACE) return { ...base, ok: false, reason: 'offline', until: end };
    return { ...base, ok: true, until: end, daysLeft: Math.ceil((end - now) / DAY) };
  }

  const fmtDate = (t) => new Date(t).toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' });

  // where — куда вводить ключ: на странице это окно расширения, в самом окне — раздел ниже.
  function message(st, where = 'в окне расширения (раздел «Лицензия»)') {
    switch (st.reason) {
      case 'no_key':
        return `Нужна лицензия: введите ключ ${where}`;
      case 'revoked':
        return 'Ключ лицензии больше не действует — обратитесь к продавцу';
      case 'expired':
        return `Срок лицензии истёк ${fmtDate(st.until)} — введите новый ключ ${where}`;
      case 'offline':
        return 'Не удаётся проверить лицензию больше 3 дней — нужен доступ к GitHub (raw.githubusercontent.com)';
      default:
        return `Лицензия активна до ${fmtDate(st.until)}`;
    }
  }

  return { FILE_URL, BOT_URL, DAY, TERM, norm, newUserId, parse, until, status, fmtDate, message, buyUrl };
})();

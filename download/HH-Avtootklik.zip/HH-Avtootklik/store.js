// Хранилище расширения: настройки, журнал, общие ключи.
//
// После обновления расширения скрипт, уже загруженный в открытую вкладку, теряет связь с ним
// («Extension context invalidated»). Такие сбои превращаются в одну понятную ошибку 'context',
// чтобы основной цикл остановился спокойно и попросил перезагрузить страницу.
(globalThis.HH ||= {}).store = (() => {
  const DEFAULTS = { minDelay: 30, maxDelay: 120, useLetter: false, letter: '', letterRules: [], bumpResume: true, clearRejections: true, captchaService: 'rucaptcha', polzaKey: '', captchaBreak: 10 };

  const alive = () => {
    try {
      return !!chrome.runtime?.id;
    } catch {
      return false;
    }
  };

  const contextError = (e) => (!alive() || /context invalidated/i.test(e?.message || '') ? new Error('context') : e);

  async function get(keys) {
    if (!alive()) throw new Error('context');
    try {
      return await chrome.storage.local.get(keys);
    } catch (e) {
      throw contextError(e);
    }
  }

  async function set(obj) {
    if (!alive()) throw new Error('context');
    try {
      await chrome.storage.local.set(obj);
    } catch (e) {
      throw contextError(e);
    }
  }

  async function settings() {
    const { settings: s } = await get('settings');
    return { ...DEFAULTS, ...(s || {}) };
  }

  // Журнал пишет фоновая часть расширения: вкладок может быть несколько (отклики, отказы),
  // и прямые записи из разных вкладок затирали бы друг друга. Если фоновая часть не ответила —
  // пишем сами, по очереди внутри этой вкладки.
  let queue = Promise.resolve();
  function writeDirect(entry) {
    const next = queue.then(async () => {
      const { log: list = [] } = await get('log');
      list.push(entry);
      await set({ log: list.slice(-300) });
    });
    queue = next.catch(() => {}); // сбой одной записи не ломает очередь
    return next;
  }

  async function log(msg, kind = 'info') {
    const entry = { t: Date.now(), msg, kind };
    if (!alive()) throw new Error('context');
    try {
      if (await chrome.runtime.sendMessage({ type: 'log', entry })) return;
    } catch (e) {
      const err = contextError(e);
      if (err.message === 'context') throw err;
    }
    await writeDirect(entry);
  }

  return { DEFAULTS, alive, get, set, settings, log };
})();

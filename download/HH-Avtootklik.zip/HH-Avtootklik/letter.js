// Сборка сопроводительного письма. Общий файл: его подключают и окно расширения
// (предпросмотр), и скрипт на странице hh.ru (отправка) — письмо собирается одинаково.
//
// Что умеет шаблон:
//   {Здравствуйте|Добрый день}     — при каждом отклике случайно выбирается один вариант;
//   {Добрый {день|вечер}|Привет}   — варианты можно вкладывать друг в друга;
//   {|Буду рад обсудить детали. }  — пустой вариант: фраза то есть, то нет;
//   {vacancy} / {вакансия}, {company} / {компания} — название вакансии и компании.
var HHLetter = (() => {
  // Подстановки сначала прячем за метками: в названии вакансии бывают «|» и скобки,
  // и они не должны смешаться с вариантами текста.
  const V = '\u0001V\u0001';
  const C = '\u0001C\u0001';
  const GROUP = /\{([^{}]*\|[^{}]*)\}/; // самая вложенная группа с «|»

  function spin(text, rnd = Math.random) {
    let out = text;
    for (let m, guard = 0; (m = GROUP.exec(out)) && guard < 1000; guard++) {
      const options = m[1].split('|');
      out = out.slice(0, m.index) + options[Math.floor(rnd() * options.length)] + out.slice(m.index + m[0].length);
    }
    return out;
  }

  function build(template, item, rnd) {
    const marked = template.replace(/\{(vacancy|вакансия)\}/gi, V).replace(/\{(company|компания)\}/gi, C);
    return spin(marked, rnd)
      .split(V).join(item.title || '')
      .split(C).join(item.company || 'вашу компанию')
      // пустой вариант оставляет двойные пробелы и пробел перед знаком препинания
      .replace(/[ \t]{2,}/g, ' ')
      .replace(/[ \t]+([,.!?;:])/g, '$1')
      .replace(/[ \t]+\n/g, '\n')
      .trim();
  }

  const norm = (s) => String(s || '').toLowerCase().replace(/ё/g, 'е');
  const keywords = (rule) => String(rule.keywords || '').split(',').map((w) => norm(w).trim()).filter(Boolean);

  // Шаблон для вакансии: первый дополнительный, чьё ключевое слово есть в названии;
  // иначе основное письмо. index: номер подошедшего шаблона или -1 для основного.
  function pick(settings, title) {
    const t = norm(title);
    const rules = settings.letterRules || [];
    for (let i = 0; i < rules.length; i++) {
      if (rules[i].text?.trim() && keywords(rules[i]).some((w) => t.includes(w))) return { text: rules[i].text, index: i };
    }
    return { text: settings.letter || '', index: -1 };
  }

  // Готовое письмо для вакансии или '' — если письма выключены или подходящего текста нет.
  function letterFor(settings, item, rnd) {
    if (!settings.useLetter) return '';
    const { text } = pick(settings, item.title);
    return text.trim() ? build(text.trim(), item, rnd) : '';
  }

  // Есть ли хоть один непустой текст письма (основной или дополнительный).
  const hasAnyText = (settings) =>
    !!(settings.letter || '').trim() || (settings.letterRules || []).some((r) => (r.text || '').trim());

  // Сколько разных текстов даёт шаблон — для подсказки в окне расширения.
  function countVariants(text) {
    let total = 1;
    for (let i = 0; i < text.length; i++) {
      if (text[i] !== '{') continue;
      let depth = 0;
      let j = i;
      for (; j < text.length; j++) {
        if (text[j] === '{') depth++;
        else if (text[j] === '}' && --depth === 0) break;
      }
      if (j >= text.length) break; // скобка без пары
      const options = [];
      let start = i + 1;
      depth = 0;
      for (let k = i + 1; k < j; k++) {
        if (text[k] === '{') depth++;
        else if (text[k] === '}') depth--;
        else if (text[k] === '|' && depth === 0) {
          options.push(text.slice(start, k));
          start = k + 1;
        }
      }
      options.push(text.slice(start, j));
      if (options.length > 1) total *= options.reduce((sum, o) => sum + countVariants(o), 0);
      else total *= countVariants(options[0]); // {vacancy} и группы внутри скобок без «|»
      i = j;
    }
    return total;
  }

  return { spin, build, pick, letterFor, hasAnyText, keywords, countVariants };
})();

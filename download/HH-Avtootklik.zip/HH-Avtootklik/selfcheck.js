// «Проверить страницу»: находит ли расширение на открытой странице всё, что ему нужно.
// Ничего не нажимает — только читает страницу. Когда hh.ru меняет вёрстку, здесь сразу видно, что сломалось.
// Результат: [{ status: 'ok' | 'warn' | 'fail', title, detail }].
(globalThis.HH ||= {}).selfCheck = ({ version, recentApplies, dailyLimit, limitOnPage, license }) => {
  const { SEL, isSerp, isLoginPage, serpPage, visible, visibleOne, text, vacancyId } = HH.dom;
  const items = [];
  const add = (status, title, detail = '') => items.push({ status, title, detail });

  add('ok', 'Скрипт на странице', `версия ${version}`);
  if (license) {
    const detail = HHLicense.message(license) + (license.ok ? ` (осталось ${license.daysLeft} дн.)` : '');
    add(!license.ok ? 'fail' : license.daysLeft <= 3 ? 'warn' : 'ok', 'Лицензия', detail);
  }

  if (isLoginPage()) {
    add('fail', 'Вход в аккаунт', 'открыта страница входа — войдите в hh.ru');
    return items;
  }
  const login = visibleOne(SEL.login);
  add(login ? 'warn' : 'ok', 'Вход в аккаунт', login ? 'видна ссылка «Войти» — похоже, вы не вошли в hh.ru' : 'выполнен');

  if (!isSerp()) {
    add('fail', 'Страница поиска', 'откройте поиск вакансий hh.ru — карточки проверяются там');
    return items;
  }
  add('ok', 'Страница поиска', `страница выдачи ${Number(serpPage(location.href)) + 1}`);

  const cards = [...document.querySelectorAll(SEL.card)];
  add(cards.length ? 'ok' : 'fail', 'Карточки вакансий',
    cards.length ? `найдено ${cards.length}` : 'не найдено ни одной — похоже, hh.ru изменил вёрстку');

  if (cards.length) {
    const withBtn = cards.filter((c) => visible(c.querySelector(SEL.respond)));
    const fresh = withBtn.filter((c) => /Откликнуться/i.test(c.querySelector(SEL.respond).textContent));
    add(withBtn.length ? 'ok' : 'fail', 'Кнопки «Откликнуться»',
      withBtn.length ? `есть у ${withBtn.length} из ${cards.length}, ещё без отклика — ${fresh.length}` : 'не найдены — похоже, hh.ru изменил вёрстку');

    const withId = withBtn.filter((c) => vacancyId(c.querySelector(SEL.respond), c)).length;
    add(withBtn.length && withId === withBtn.length ? 'ok' : withId ? 'warn' : 'fail', 'Номера вакансий',
      `читаются у ${withId} из ${withBtn.length}`);

    const titled = cards.filter((c) => text(c, SEL.title)).length;
    add(titled === cards.length ? 'ok' : 'warn', 'Названия вакансий', `читаются у ${titled} из ${cards.length}`);

    const company = cards.filter((c) => text(c, SEL.employer)).length;
    add(company >= cards.length * 0.8 ? 'ok' : 'warn', 'Названия компаний',
      `читаются у ${company} из ${cards.length}${company < cards.length ? ' (у части вакансий компания скрыта — это нормально)' : ''}`);
  }

  const pager = document.querySelector(SEL.next) || document.querySelector(SEL.page);
  add(pager ? 'ok' : 'warn', 'Переход по страницам',
    pager ? 'кнопки страниц найдены' : 'не найдены — это нормально, если страница выдачи одна');

  const captcha = visibleOne(SEL.captcha);
  add(captcha ? 'warn' : 'ok', 'Капча', captcha ? 'сейчас на экране — пройдите её' : 'не показана');

  add(limitOnPage ? 'fail' : recentApplies >= dailyLimit ? 'fail' : recentApplies >= dailyLimit * 0.8 ? 'warn' : 'ok', 'Суточный лимит',
    limitOnPage ? 'hh.ru показывает сообщение о лимите откликов' : `${recentApplies} из ${dailyLimit} откликов за 24 часа (по учёту расширения)`);

  add(document.hidden ? 'warn' : 'ok', 'Видимость вкладки',
    document.hidden ? 'вкладка скрыта — браузер замедляет работу' : 'на экране');

  return items;
};

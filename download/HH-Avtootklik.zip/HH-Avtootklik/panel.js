// Плавающая панель в углу страницы hh.ru: состояние, счётчики, кнопка «Остановить».
// Только отображение — данные и обработчик остановки передаёт content.js.
(globalThis.HH ||= {}).panel = (() => {
  let root = null;
  let onStop = null;

  const STYLE = `
    .box{
      --bg:#fff;--text:#1b1f2a;--muted:#6b7385;--border:#e4e7ef;--soft:#f1f3f8;
      --ok:#16a34a;--warn:#b45309;--err:#dc2626;--err-bg:#fdecec;--accent:#4f46e5;--accent-2:#7c3aed;
      --ease:cubic-bezier(.2,.8,.2,1);
      box-sizing:border-box;width:292px;padding:12px 14px;border-radius:16px;
      font:13px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:var(--text);
      background:var(--bg);border:1px solid var(--border);
      box-shadow:0 18px 40px -12px rgba(16,24,40,.28),0 2px 6px rgba(16,24,40,.06);
      animation:in .5s var(--ease) both;
    }
    @media (prefers-color-scheme: dark){
      .box{--bg:#171a22;--text:#e8eaf0;--muted:#9aa3b5;--border:#2a2f3b;--soft:#1f232d;
           --ok:#4ade80;--warn:#fbbf24;--err:#f87171;--err-bg:rgba(248,113,113,.14);--accent:#818cf8;--accent-2:#a78bfa;
           box-shadow:0 18px 40px -12px rgba(0,0,0,.6)}
    }
    @keyframes in{from{opacity:0;transform:translateY(14px) scale(.98)}to{opacity:1;transform:none}}
    .h{display:flex;align-items:center;gap:8px;font-weight:700}
    .logo{display:grid;place-items:center;width:24px;height:24px;border-radius:7px;
          background:linear-gradient(135deg,#ff5160,#d0021b);box-shadow:0 4px 10px -4px rgba(208,2,27,.6)}
    .logo svg{width:15px;height:15px}
    .title{flex:1}
    .dot{--c:var(--muted);width:8px;height:8px;border-radius:50%;background:var(--c);transition:background-color .3s}
    .box[data-state="run"] .dot{--c:var(--ok);animation:pulse 1.8s ease-out infinite}
    .box[data-state="wait"] .dot{--c:var(--warn);animation:pulse 2.6s ease-out infinite}
    .box[data-state="alert"] .dot{--c:var(--err)}
    @keyframes pulse{0%{box-shadow:0 0 0 0 color-mix(in srgb,var(--c) 55%,transparent)}
                     70%{box-shadow:0 0 0 7px transparent}100%{box-shadow:0 0 0 0 transparent}}
    .n{display:grid;grid-template-columns:repeat(4,1fr);gap:5px;margin:10px 0 8px}
    .n div{display:flex;flex-direction:column;min-width:0;padding:6px 7px;border-radius:10px;background:var(--soft)}
    .n b{font-size:17px;line-height:1.15;font-variant-numeric:tabular-nums;display:inline-block;transform-origin:left center}
    .n span{font-size:10px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .n .ok b{color:var(--ok)} .n .skip b{color:var(--warn)} .n .err b{color:var(--err)} .n .old b{color:var(--muted)}
    .n b.bump{animation:bump .5s var(--ease)}
    @keyframes bump{0%{transform:scale(1)}35%{transform:scale(1.2)}100%{transform:scale(1)}}
    .prog{margin:0 0 8px}
    .prog[hidden]{display:none}
    .n[hidden]{display:none}
    .n[hidden] + .prog{margin-top:12px}  /* без блока счётчиков полоска иначе прилипает к шапке с логотипом */
    .bar.ind i{width:35%!important;animation:ind 1.4s ease-in-out infinite}
    @keyframes ind{0%{margin-left:-35%}100%{margin-left:100%}}
    .bar{height:6px;border-radius:3px;background:var(--soft);overflow:hidden}
    .bar i{display:block;height:100%;width:0;border-radius:3px;background:linear-gradient(90deg,var(--accent),var(--accent-2));transition:width .6s var(--ease)}
    .pt{display:flex;justify-content:space-between;gap:8px;margin-top:5px;font-size:11.5px;color:var(--muted)}
    .pt b{color:var(--text);font-variant-numeric:tabular-nums}
    .lim{margin:0 0 8px;padding:6px 9px;border-radius:10px;background:var(--err-bg);color:var(--err);font-weight:600;font-size:12px}
    .lim:empty{display:none}
    .st{color:var(--muted);overflow-wrap:anywhere;transition:color .3s}
    .box:not([data-state="idle"]) .st{color:var(--text)}
    .box[data-state="alert"] .st{color:var(--err);font-weight:600}
    .stop{display:flex;align-items:center;justify-content:center;gap:6px;width:100%;height:34px;margin-top:10px;
          font:inherit;font-weight:650;border:0;border-radius:10px;cursor:pointer;color:#fff;background:#dc2626;
          transition:transform .15s var(--ease),filter .2s}
    .stop:hover{filter:brightness(1.06)}
    .stop:active{transform:scale(.97)}
    .stop[hidden]{display:none}
    @media (prefers-reduced-motion: reduce){*{animation-duration:1ms!important;animation-iteration-count:1!important;transition-duration:1ms!important}}`;

  const HTML = `
    <div class="box" data-state="idle">
      <div class="h">
        <span class="logo"><svg viewBox="0 0 24 24"><path d="M22 2 2 9l9 4z" fill="#fff"/><path d="M22 2 11 13l4 9z" fill="#ffd9dd"/></svg></span>
        <span class="title">HH Автоотклик</span>
        <span class="dot"></span>
      </div>
      <div class="n">
        <div class="ok"><b data-k="applied">0</b><span>отклики</span></div>
        <div class="skip"><b data-k="skipped">0</b><span>пропуски</span></div>
        <div class="err"><b data-k="errors">0</b><span>ошибки</span></div>
        <div class="old" title="Уже обработаны раньше: «Вы откликнулись», «Вам отказали», «Вы отказались»"><b data-k="earlier">0</b><span>ранее</span></div>
      </div>
      <div class="prog" hidden><div class="bar"><i></i></div><div class="pt"><span class="pp"></span><span class="eta"></span></div></div>
      <div class="lim"></div>
      <div class="st"></div>
      <button class="stop">Остановить</button>
    </div>`;

  function ensure() {
    if (root?.host.isConnected) return root;
    const host = document.createElement('div');
    host.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647;';
    root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>${STYLE}</style>${HTML}`;
    root.querySelector('.stop').addEventListener('click', () => onStop?.());
    document.documentElement.appendChild(host);
    return root;
  }

  // «3 ч 10 мин», «25 мин», «меньше минуты».
  function fmtDuration(ms) {
    const min = Math.round(ms / 60000);
    if (min < 1) return 'меньше минуты';
    if (min < 60) return `${min} мин`;
    return `${Math.floor(min / 60)} ч${min % 60 ? ` ${min % 60} мин` : ''}`;
  }

  // Прогресс по выдаче: процент, «N из M» и оставшееся время по среднему темпу этого запуска.
  function renderProgress(r, pr, active) {
    const box = r.querySelector('.prog');
    box.hidden = !active || !pr?.total;
    if (box.hidden) return;
    const pct = Math.min(100, Math.floor((pr.pos / pr.total) * 100));
    r.querySelector('.bar i').style.width = `${pct}%`;
    r.querySelector('.pp').innerHTML = `<b>${pct}%</b> · ${pr.pos} из ${pr.total}`;
    const passed = pr.pos - pr.startPos;
    const eta = r.querySelector('.eta');
    if (pr.pos >= pr.total) eta.textContent = 'последние вакансии';
    else if (passed < 3) eta.textContent = 'считаю время…'; // пока мало данных о темпе
    else eta.textContent = `осталось ≈ ${fmtDuration(((Date.now() - pr.startedAt) / passed) * (pr.total - pr.pos))}`;
  }

  // Панель во вкладке-помощнике (удаление отказов): без счётчиков откликов, зато с процентом.
  // pr: { title, done, expected (0 — неизвестно), startedAt, status }.
  function renderChore(pr) {
    const r = ensure();
    r.querySelector('.title').textContent = pr.title;
    r.querySelector('.n').hidden = true;
    r.querySelector('.lim').textContent = '';
    r.querySelector('.box').dataset.state = 'run';
    r.querySelector('.stop').hidden = false;
    r.querySelector('.stop').textContent = 'Остановить';
    r.querySelector('.st').textContent = pr.status || '';
    const box = r.querySelector('.prog');
    box.hidden = false;
    const bar = r.querySelector('.bar');
    const eta = r.querySelector('.eta');
    if (!pr.expected) {
      // Счётчика отказов на странице нет: процент считать не от чего, показываем число удалённых.
      bar.classList.add('ind');
      r.querySelector('.pp').innerHTML = `удалено <b>${pr.done}</b>`;
      eta.textContent = '';
      return;
    }
    bar.classList.remove('ind');
    const pct = Math.min(100, Math.floor((pr.done / pr.expected) * 100));
    r.querySelector('.bar i').style.width = `${pct}%`;
    r.querySelector('.pp').innerHTML = `<b>${pct}%</b> · ${pr.done} из ${pr.expected}`;
    if (pr.done >= pr.expected) eta.textContent = 'заканчиваю';
    else if (pr.done < 5) eta.textContent = 'считаю время…';
    else eta.textContent = `осталось ≈ ${fmtDuration(((Date.now() - pr.startedAt) / pr.done) * (pr.expected - pr.done))}`;
  }

  const stateOf = (run, active) =>
    !active ? 'idle' : /^(Следующее действие|Перерыв)/.test(run.status || '') ? 'wait' : 'run';

  function render({ run, active, limitText = '' }) {
    if (!run) return;
    const r = ensure();
    for (const k of ['applied', 'skipped', 'errors', 'earlier']) {
      const el = r.querySelector(`[data-k="${k}"]`);
      const value = String(run[k] ?? 0);
      if (el.textContent === value) continue;
      el.textContent = value;
      el.classList.remove('bump');
      void el.offsetWidth; // перезапуск анимации
      el.classList.add('bump');
    }
    r.querySelector('.box').dataset.state = stateOf(run, active);
    renderProgress(r, run.progress, active);
    r.querySelector('.lim').textContent = limitText;
    r.querySelector('.st').textContent = active ? run.status : `Не запущено. ${run.status || ''}`;
    r.querySelector('.stop').hidden = !active;
  }

  // Красная строка вместо статуса — когда дальше без человека нельзя (например, расширение обновили).
  function alert(message) {
    const r = ensure();
    r.querySelector('.box').dataset.state = 'alert';
    r.querySelector('.st').textContent = message;
    r.querySelector('.stop').hidden = true;
  }

  return { render, renderChore, alert, setOnStop: (fn) => (onStop = fn) };
})();

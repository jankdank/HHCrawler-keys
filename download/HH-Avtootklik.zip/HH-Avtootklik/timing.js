// Паузы и ожидания, которые прерываются кнопкой «Стоп».
//
// В скрытой вкладке (свёрнуто окно, отключён RDP, вкладка-помощник в фоне) браузер замедляет таймеры
// страницы — после 5 минут до одного срабатывания в минуту. Поэтому:
// - ожидания DOM идут через MutationObserver, он не замедляется;
// - паузы в скрытой вкладке отсчитывает фоновая часть расширения (сообщение 'sleep'): её таймеры
//   браузер не замедляет, а ответ доходит до вкладки сразу. Обычный таймер остаётся запасным —
//   что сработает раньше, то и конец паузы.
(globalThis.HH ||= {}).makeTiming = (isActive) => {
  const sleepers = new Set();
  const stopAll = () => [...sleepers].forEach((cancel) => cancel());

  // Пауза в фоновой части расширения; если связи с ней нет — промис просто не завершится.
  function backgroundTimer(ms) {
    try {
      return chrome.runtime.sendMessage({ type: 'sleep', ms }).then(() => {}, () => new Promise(() => {}));
    } catch {
      return new Promise(() => {}); // расширение обновили — остаётся обычный таймер
    }
  }

  function sleep(ms) {
    if (!isActive()) return Promise.reject(new Error('stopped'));
    return new Promise((resolve, reject) => {
      let finished = false;
      const finish = (ok) => {
        if (finished) return;
        finished = true;
        clearTimeout(t);
        sleepers.delete(cancel);
        ok ? resolve() : reject(new Error('stopped'));
      };
      const cancel = () => finish(false);
      const t = setTimeout(() => finish(true), Math.max(0, ms));
      if (document.hidden && ms > 50) backgroundTimer(ms).then(() => finish(true));
      sleepers.add(cancel);
    });
  }

  // Атрибуты, от которых зависит то, что мы ждём: видимость, доступность кнопок, ссылки, значения.
  // Остальные (анимации, счётчики, служебные data-*) только зря будили бы проверку.
  const WATCHED_ATTRS = ['class', 'style', 'hidden', 'aria-hidden', 'aria-expanded', 'aria-disabled', 'disabled', 'open', 'href', 'src', 'value', 'checked', 'data-qa'];

  // Ждёт, пока fn() вернёт истинное значение; по таймауту возвращает null.
  function waitFor(fn, timeout = 10000) {
    if (!isActive()) return Promise.reject(new Error('stopped'));
    const v = fn();
    if (v) return Promise.resolve(v);
    return new Promise((resolve, reject) => {
      const end = Date.now() + timeout;
      let finished = false;
      const done = (val, err) => {
        if (finished) return;
        finished = true;
        obs.disconnect();
        clearInterval(iv);
        clearTimeout(t);
        sleepers.delete(cancel);
        err ? reject(err) : resolve(val);
      };
      const check = () => {
        if (finished) return;
        let r;
        try {
          r = fn();
        } catch (e) {
          return done(null, e);
        }
        if (r) done(r);
        else if (Date.now() >= end) done(null);
      };
      const cancel = () => done(null, new Error('stopped'));
      const obs = new MutationObserver(check);
      obs.observe(document.documentElement, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: WATCHED_ATTRS });
      const iv = setInterval(check, 1000); // смена адреса без изменений DOM
      const t = setTimeout(() => done(fn() || null), timeout);
      if (document.hidden) backgroundTimer(timeout).then(() => done(fn() || null));
      sleepers.add(cancel);
    });
  }

  return { sleep, waitFor, stopAll };
};

/* The report tab owns the request, so closing the popup cannot cancel the analysis. */
(() => {
  const $ = id => document.getElementById(id);
  const id = new URLSearchParams(location.search).get('id');
  let job = null, busy = false;

  function errorView(reason, canContinue = false) {
    $('state').hidden = false; $('state').classList.add('error');
    $('spinner').hidden = true; $('status').textContent = 'Не удалось получить отчёт';
    $('detail').textContent = HHResume.message(reason);
    $('resumeRequest').hidden = !canContinue;
  }

  function renderReport() {
    HHResume.renderMarkdown($('report'), job.report);
    $('meta').textContent = new Date(job.finishedAt).toLocaleString('ru-RU') + ' · ' + (job.modelName || job.model);
    $('state').hidden = true; $('report').hidden = false; $('download').hidden = false;
    $('removeReport').hidden = false;
    document.title = 'Анализ резюме — ' + job.name;
  }

  async function authorization() {
    try { await chrome.runtime.sendMessage({ type: 'licenseCheck' }); } catch (_) { /* A stored, unexpired token can still be used. */ }
    const { license } = await chrome.storage.local.get('license');
    const signed = license?.token;
    if (!signed || signed.ext_id !== license.userId || signed.exp * 1000 <= Date.now()) throw new Error('no_license');
    return { ext_id: license.userId, token: signed };
  }

  async function post(path, payload) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 15000);
    try {
      const response = await fetch(HHLicense.RESUME_URL + path, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, cache: 'no-store',
        signal: controller.signal, body: JSON.stringify(payload),
      });
      const data = await response.json().catch(() => null);
      if (!data || typeof data !== 'object') throw new Error(response.status === 404 ? 'not_configured' : 'bad_response');
      if (!response.ok || data.ok !== true) throw new Error(data.reason || 'provider_unavailable');
      return data;
    } catch (error) {
      if (error.name === 'AbortError' || error instanceof TypeError) throw new Error('network');
      throw error;
    } finally { clearTimeout(timer); }
  }

  async function accept(data) {
    if (data.job_id) job.jobId = data.job_id;
    if (data.status === 'error') {
      job.terminal = true;
      throw new Error(data.reason || 'bad_response');
    }
    if (data.status === 'done') {
      if (typeof data.report !== 'string' || !data.report.trim() || data.report.length > 60000) throw new Error('bad_response');
      job = { ...job, status: 'done', report: data.report, model: String(data.model || ''),
        modelName: String(data.model_name || data.model || ''), finishedAt: Date.now() };
      delete job.text; delete job.error; delete job.terminal;
      await HHResume.save(job);
      renderReport();
      return true;
    }
    if (data.status !== 'pending' || !job.jobId) throw new Error('bad_response');
    job.status = 'pending';
    await HHResume.save(job);
    return false;
  }

  async function run() {
    if (busy) return;
    busy = true; $('removeReport').disabled = true;
    try {
      job = await HHResume.read(id);
      $('fileName').textContent = job.name;
      $('removeReport').hidden = false;
      if (job.status === 'done' && job.report) { renderReport(); return; }
      if (job.status === 'error' && job.terminal) { errorView(job.error); return; }
      $('state').hidden = false; $('state').classList.remove('error');
      $('spinner').hidden = false; $('resumeRequest').hidden = true;
      $('status').textContent = 'Анализируем резюме…';
      $('detail').textContent = 'Обычно это занимает до двух минут. Окно расширения можно закрыть.';
      const auth = await authorization();
      if (!job.jobId) {
        HHResume.validate(job);
        job.status = 'pending'; delete job.error;
        await HHResume.save(job);
        if (await accept(await post('/analyze', { ...auth, request_id: job.id, text: job.text }))) return;
      }
      const deadline = Date.now() + 150000;
      while (Date.now() < deadline) {
        const result = await post('/result', { ...auth, job_id: job.jobId });
        if (await accept(result)) return;
        await new Promise(resolve => setTimeout(resolve, 2500));
      }
      throw new Error('waiting');
    } catch (error) {
      const reason = error.message;
      if (job) {
        job.status = 'error'; job.error = reason;
        if (['unknown_job', 'job_expired', 'request_conflict', 'interrupted'].includes(reason)) job.terminal = true;
        try { await HHResume.save(job); } catch (_) { /* Display errors even when storage is unavailable. */ }
      }
      errorView(reason, !!job && !job.terminal && !['bad_resume', 'too_large'].includes(reason));
    } finally { busy = false; $('removeReport').disabled = false; }
  }

  $('resumeRequest').addEventListener('click', run);
  $('download').addEventListener('click', async () => {
    if (!job?.report) return;
    $('download').disabled = true;
    const url = URL.createObjectURL(new Blob(['\ufeff' + HHResume.html(job)], { type: 'text/html;charset=utf-8' }));
    try {
      const name = job.name.replace(/\.[^.]+$/, '').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').slice(0, 80) || 'resume';
      await chrome.downloads.download({ url, filename: name + '-analysis.html', saveAs: true });
    } catch (_) { $('meta').textContent = 'Файл не сохранён. Нажмите «Сохранить .html», чтобы повторить.'; }
    finally { setTimeout(() => URL.revokeObjectURL(url), 60000); $('download').disabled = false; }
  });

  $('removeReport').addEventListener('click', async () => {
    if (!job || busy) return;
    await chrome.storage.local.remove(HHResume.key(job.id));
    job = null; $('report').replaceChildren(); $('report').hidden = true;
    $('download').hidden = true; $('removeReport').hidden = true;
    $('meta').textContent = ''; $('fileName').textContent = '';
    $('state').hidden = false; $('state').classList.remove('error'); $('spinner').hidden = true;
    $('status').textContent = 'Отчёт удалён из браузера';
    $('detail').textContent = 'Ранее сохранённый .html остаётся в выбранной вами папке.';
    $('resumeRequest').hidden = true;
  });

  run();
})();

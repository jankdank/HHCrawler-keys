// Подбор резюме по названию вакансии. Чистый модуль: без DOM и без hh.ru — только строки и настройки,
// поэтому его можно тестировать отдельно (tools/routing.test.mjs). Общий для окна расширения
// (настройки, кнопка «Проверить», валидация) и для скрипта на странице (выбор резюме перед откликом).
//
// Алгоритм — раздел 4 спецификации: нормализация, поиск по началу слова, стоп-слова, выбор резюме.
;(function () {
  const api = (function () {
    'use strict';

    // Нормализация — одинаково для названия вакансии, ключевых слов и стоп-слов (раздел 4):
    // нижний регистр, «ё»→«е», «1c» латиницей → «1с» кириллицей, разделители → пробел, схлопнуть пробелы.
    function normalize(str) {
      return String(str || '')
        .toLowerCase()
        .replace(/ё/g, 'е')
        .replace(/1c/g, '1с') // латинская «c» в «1c» → кириллическая «с»
        .replace(/[-–—/()[\],.:]+/g, ' ') // дефис, тире, слеш, скобки, запятая, точка, двоеточие
        .replace(/\s+/g, ' ')
        .trim();
    }

    const tokensOf = (str) => normalize(str).split(' ').filter(Boolean);

    // Фраза termTokens есть в titleTokens, если идёт подряд и каждое слово совпадает «по началу слова».
    // Одно слово — частный случай фразы из одного слова: «аналитик» найдёт «аналитика», но не середину.
    function phraseAt(titleTokens, termTokens) {
      for (let i = 0; i + termTokens.length <= titleTokens.length; i++) {
        let ok = true;
        for (let j = 0; j < termTokens.length; j++) {
          if (!titleTokens[i + j].startsWith(termTokens[j])) { ok = false; break; }
        }
        if (ok) return true;
      }
      return false;
    }

    function hasTerm(titleTokens, term) {
      const tt = tokensOf(term);
      return tt.length > 0 && phraseAt(titleTokens, tt);
    }

    const anyTerm = (titleTokens, terms) => (terms || []).some((t) => hasTerm(titleTokens, t));

    // Доступно ли резюме. Список резюме ещё не загружали (пуст) — проверить нечем, считаем доступным:
    // последнее слово скажет форма отклика (ИН-3). Список есть, а резюме в нём нет или помечено скрытым —
    // недоступно (ФТ-5).
    function resumeAvailable(routing, id) {
      if (!id) return false;
      const items = (routing.resumesCache && routing.resumesCache.items) || [];
      if (!items.length) return true;
      const item = items.find((r) => r.id === id);
      return item ? item.available !== false : false;
    }

    // Главная функция. На входе название вакансии и настройки resumeRouting, на выходе:
    //   { resumeId, ruleName, usedDefault, warning, skip, reason }
    // resumeId — хеш резюме для отклика (или null, если отклик надо пропустить);
    // ruleName — название сработавшего правила / «По умолчанию»; skip+reason — когда резюме нет.
    function chooseResume(title, routing) {
      const base = { resumeId: null, ruleName: '', usedDefault: false, warning: '', skip: false, reason: '' };
      const r = (extra) => ({ ...base, ...extra });

      const def = (routing && routing.defaultResumeId) || null;
      const defOk = resumeAvailable(routing, def);
      // Уйти на резюме по умолчанию; если его нет/недоступно — пропустить отклик (раздел 4.6).
      const toDefault = (ruleName, warning) => defOk
        ? r({ resumeId: def, ruleName, usedDefault: true, warning })
        : r({ ruleName, skip: true, reason: 'no_resume', warning: warning || 'no_default' });

      const titleTokens = tokensOf(title);
      if (!titleTokens.length) return toDefault('По умолчанию', 'empty_title'); // пустое название (раздел 9)

      for (const rule of (routing.rules || [])) {
        if (!rule.enabled) continue;
        if (anyTerm(titleTokens, rule.stopWords)) continue; // стоп-слово — правило не сработало
        if (!anyTerm(titleTokens, rule.keywords)) continue; // ни одного ключевого слова
        // Правило совпало — дальше не проверяем (раздел 4.3).
        if (resumeAvailable(routing, rule.resumeId)) return r({ resumeId: rule.resumeId, ruleName: rule.name });
        // Резюме правила недоступно → по умолчанию, к следующему правилу не переходим (раздел 4.4).
        return toDefault(rule.name, 'rule_resume_unavailable');
      }
      return toDefault('По умолчанию', ''); // ни одно правило не подошло (раздел 4.5)
    }

    // Проверка правила для формы настроек (раздел 5). priorRules — правила, стоящие выше по списку.
    function validateRule(rule, priorRules = []) {
      const errors = [];
      const warnings = [];
      const name = (rule.name || '').trim();
      const keys = (rule.keywords || []).map((k) => k.trim()).filter(Boolean);
      const stops = (rule.stopWords || []).map((k) => k.trim()).filter(Boolean);

      if (!name) errors.push({ field: 'name', msg: 'Укажите название' });
      if (!keys.length) errors.push({ field: 'keywords', msg: 'Добавьте хотя бы одно ключевое слово' });
      if (!rule.resumeId) errors.push({ field: 'resume', msg: 'Выберите резюме' });

      // Одно и то же слово в ключевых и в стоп-словах — сохранять нельзя, слово подсветить.
      const stopNorm = new Set(stops.map(normalize).filter(Boolean));
      const conflicts = keys.filter((k) => stopNorm.has(normalize(k)));
      if (conflicts.length) errors.push({ field: 'conflict', msg: 'Слово есть и в ключевых, и в стоп-словах', words: conflicts });

      // Такое же ключевое слово есть в правиле выше — сохранить можно, но по нему правило не сработает.
      const above = new Set();
      for (const pr of priorRules) for (const k of (pr.keywords || [])) above.add(normalize(k));
      const dup = keys.filter((k) => above.has(normalize(k)));
      if (dup.length) warnings.push({ field: 'keywords', msg: 'По этому слову правило не сработает — оно уже есть в правиле выше', words: dup });

      return { ok: errors.length === 0, errors, warnings, conflicts };
    }

    return { normalize, chooseResume, validateRule, hasTerm };
  })();

  (globalThis.HH ||= {}).routing = api; // на странице hh.ru и в окне расширения
  if (typeof module !== 'undefined' && module.exports) module.exports = api; // в тестах (node)
})();

// Only list-row statuses select chats. Confirmation counts are UI actions, not proven removals.
(globalThis.HH ||= {}).makeRejectionChats = ({ sleep, waitFor, humanClick, isActive = () => true,
  save = async () => {}, onProgress = () => {}, log = async () => {}, ensureVisible = async () => false,
  ensureBackground = async () => false }) => {
  const { CHATS, visible, isDisabled } = HH.dom;
  const normalize = value => String(value || '').replace(/\s+/g, ' ').trim();
  const WARNING = 'Вы перестанете получать новые сообщения, если покинете чат';
  const uniqueVisible = (selector, root = document) => {
    const found = [...root.querySelectorAll(selector)].filter(visible);
    return found.length === 1 ? found[0] : null;
  };
  const rows = () => [...document.querySelectorAll(CHATS.row)].filter(visible).flatMap(row => {
    const id = /^chat-cell-(\d+)$/.exec(row.id)?.[1];
    return id ? [{ id, row, status: normalize(row.querySelector(CHATS.status)?.textContent) }] : [];
  });
  const find = id => {
    const found = rows().filter(item => item.id === id);
    return found.length === 1 ? found[0] : null;
  };

  function selected(target) {
    const current = find(target.id)?.row;
    if (!current) return false;
    for (const element of [current, current.parentElement]) {
      if (!element || (element !== current && element.querySelectorAll(CHATS.row).length !== 1)) continue;
      if (element.getAttribute('aria-selected') === 'true' || ['true', 'page'].includes(element.getAttribute('aria-current'))) return true;
    }
    // Derive the route and its ID parameter from this row; never hardcode a company or chat ID.
    try {
      const expected = new URL(current.getAttribute('href'), location.href), actual = new URL(location.href);
      if (expected.origin !== actual.origin || !/^\/chat(?:\/|$)/.test(expected.pathname)) return false;
      for (const [name, value] of expected.searchParams) {
        if (value === target.id && actual.pathname === expected.pathname && actual.searchParams.get(name) === value) return true;
      }
      if (expected.pathname.split('/').includes(target.id) && expected.pathname === actual.pathname) return true;
      if (expected.hash.split(/[/?=&]/).includes(target.id) && expected.hash === actual.hash && expected.pathname === actual.pathname) return true;
    } catch (_) { /* No trustworthy route identity. */ }
    return false;
  }

  function scrollCandidates(row) {
    // Start outside all mounted rows, not inside one clipped chat card.
    let common = row.parentElement;
    for (const item of rows()) while (common && !common.contains(item.row)) common = common.parentElement;
    const scrollable = [], emptyViewports = [];
    const page = document.scrollingElement || document.documentElement;
    for (let element = common; element && element !== page; element = element.parentElement) {
      if (element.clientHeight <= 0) continue;
      const overflow = getComputedStyle(element).overflowY;
      if (/auto|scroll|hidden/.test(overflow) && element.scrollHeight > element.clientHeight + 1) scrollable.push(element);
      // Initially the first batch can exactly fit. Its scroll event still requests the next batch.
      else if (/auto|scroll|hidden/.test(overflow)) emptyViewports.push(element);
    }
    const candidates = [...scrollable, ...emptyViewports];
    if (!candidates.length || page.scrollHeight > page.clientHeight + 1) candidates.push(page);
    return [...new Set(candidates)];
  }
  function scrollContainer(row, preferred = null) {
    const candidates = scrollCandidates(row), page = document.scrollingElement;
    const actual = candidates.find(element => element !== page && element.scrollHeight > element.clientHeight + 1);
    // Keep a successfully selected outer viewport instead of jumping back to a clipping wrapper.
    if (candidates.includes(preferred) && (preferred !== page || !actual)) return preferred;
    return actual || candidates[0];
  }

  const scrollEvent = element => {
    element.dispatchEvent(new Event('scroll', { bubbles: true }));
    if (element === document.scrollingElement) window.dispatchEvent(new Event('scroll'));
  };
  const wheelAt = (row, deltaY) => {
    const rect = row.getBoundingClientRect();
    row.dispatchEvent(new WheelEvent('wheel', { bubbles: true, cancelable: true, deltaY,
      clientX: Math.max(0, Math.min(innerWidth - 1, rect.left + rect.width / 2)),
      clientY: Math.max(0, Math.min(innerHeight - 1, rect.top + rect.height / 2)) }));
  };

  const eligible = target => find(target.id)?.status === 'Отказ' && selected(target);
  function confirmation() {
    const marker = uniqueVisible(CHATS.alert);
    const dialog = marker?.closest('[role="alertdialog"][aria-modal="true"]');
    if (!dialog || !visible(dialog)) return null;
    const warnings = [...dialog.querySelectorAll(CHATS.warning)];
    if (!warnings.some(node => normalize(node.textContent).replace(/[.!]$/, '') === WARNING)) return null;
    const button = uniqueVisible(CHATS.confirm, dialog);
    return button && !isDisabled(button) ? { dialog, button } : null;
  }

  // Recheck at the actual click, after humanClick's delays: the user/site can change selection meanwhile.
  async function guardedClick(resolveButton, condition, onAccepted = () => {}) {
    const dynamic = typeof resolveButton === 'function';
    for (let attempt = 0; attempt < 3; attempt++) {
      const button = dynamic ? resolveButton() : resolveButton;
      if (!button || !visible(button) || isDisabled(button)) throw new Error('кнопка недоступна');
      let clicked = false, blocked = false, stale = false;
      const guard = event => {
        if (event.target !== button && !button.contains(event.target)) return;
        stale = !button.isConnected;
        if (!isActive() || stale || !condition()) {
          event.preventDefault(); event.stopImmediatePropagation(); blocked = true;
        } else { clicked = true; onAccepted(); }
      };
      // The node itself still receives this guard if virtualization detaches it before click().
      button.addEventListener('click', guard, true);
      try { await humanClick(button); }
      finally { button.removeEventListener('click', guard, true); }
      if (clicked && !blocked) return;
      if (dynamic && stale && isActive() && condition()) { await sleep(100); continue; }
      throw new Error(isActive() ? 'чат или подтверждение изменились — очистка остановлена' : 'stopped');
    }
    throw new Error('строка чата постоянно меняется — очистка остановлена');
  }

  const alerts = () => [...document.querySelectorAll('[role="alert"]')].filter(visible).map(node => normalize(node.textContent));

  async function run(initial = {}, activity) {
    const state = { total: 0, attempted: [], startedAt: Date.now(), phase: 'scan', scanned: 0, skipped: 0, ...initial };
    // Old active jobs may have a plan truncated to the first viewport. Recount without repeating clicks.
    if (initial.phase === 'cleanup' && initial.traversalVersion !== 2) state.phase = 'scan';
    state.traversalVersion = 2;
    const attempted = new Set(state.attempted), discovered = new Set();
    const targets = new Set([...(state.targets || []), ...attempted]);
    const completed = new Set(state.completed || (initial.phase ? [] : state.attempted));
    const notify = () => {
      state.targets = [...targets]; state.completed = [...completed];
      state.processed = completed.size;
      state.scanned = Math.max(state.scanned, discovered.size);
      state.expected = state.phase === 'scan' ? 0 : targets.size;
      onProgress(state.total, state.scanned, state.startedAt, {
        phase: state.phase, expected: state.expected, processed: state.processed,
        found: targets.size, skipped: state.skipped, processingStartedAt: state.processingStartedAt,
      });
    };
    const publish = async () => {
      state.attempted = [...attempted];
      notify();
      await save(state);
    };
    if (state.pending) {
      await log(`Чат #${state.pending}: предыдущая попытка прервалась; автоматический повтор пропущен`, 'info');
      attempted.add(state.pending); completed.add(state.pending); state.pending = null;
    }
    await publish();
    if (state.phase === 'done') return { ...state, loaded: true, visited: state.scanned };
    if (!/^\/chat(?:\/|$)/.test(location.pathname)) throw new Error('открыта не страница чатов hh.ru');
    let backgroundWasReady = !!await ensureBackground();
    if (!await waitFor(() => rows().length, 15000)) return { ...state, loaded: false };
    let scroller = scrollContainer(rows()[0].row);
    let bottomStable = 0;
    let requestedVisibility = false;
    let triedScrollers = new WeakSet(), movedScrollers = new WeakSet();
    let observedScroll = activity.serial;
    const waitForUser = async () => {
      while (Date.now() - activity.at < 1000) await sleep(Math.max(1, 1000 - (Date.now() - activity.at)));
    };
    const loading = () => {
      const root = scroller === document.scrollingElement ? rows()[0]?.row.parentElement : scroller;
      const selector = '[aria-busy="true"], [role="progressbar"], [data-qa*="loading" i], [data-qa*="loader" i]';
      return !!root && (root.matches(selector) || [...root.querySelectorAll(selector)].some(visible));
    };
    const waitForLoading = async () => {
      if (loading() && !await waitFor(() => !loading(), 30000)) {
        throw new Error('подгрузка чатов не завершилась — конец списка не подтверждён');
      }
    };
    const requestVisibility = async () => {
      if (!document.hidden || requestedVisibility) return;
      requestedVisibility = true;
      if (await ensureVisible()) {
        await log('Для подгрузки списка активирована вкладка чатов', 'info');
        if (!await waitFor(() => !document.hidden, 5000)) {
          throw new Error('вкладка чатов остаётся скрытой — откройте окно браузера для подгрузки списка');
        }
        if (scroller.isConnected) scrollEvent(scroller);
        await sleep(600);
      } else throw new Error('не удалось активировать вкладку чатов для подгрузки полного списка');
    };
    const ensureRendering = async () => {
      if (!document.hidden) return;
      if (await ensureBackground()) {
        backgroundWasReady = true;
        if (await waitFor(() => !document.hidden, 5000)) return;
        throw new Error('браузер не включил фоновое обновление списка чатов');
      }
      if (backgroundWasReady) throw new Error('фоновая работа чатов прервана — перезагрузите вкладку чатов для продолжения');
      await requestVisibility();
      if (document.hidden) throw new Error('список чатов скрыт, а фоновая работа недоступна — откройте вкладку чатов и проверьте разрешения расширения');
    };
    const resetScroll = async () => {
      await ensureRendering();
      const currentRows = rows();
      // Reset both a custom viewport and its page fallback before replaying the counted plan.
      for (const element of currentRows[0] ? scrollCandidates(currentRows[0].row).reverse() : []) {
        if (element.isConnected) { element.scrollTop = 0; scrollEvent(element); }
      }
      await sleep(600);
      await ensureRendering();
      scroller = rows()[0] ? scrollContainer(rows()[0].row, scroller) : scroller;
      // Some custom lists move rows with transforms and keep scrollTop/scrollHeight unchanged.
      // Native scrollTop = 0 alone cannot replay their counted plan or an initially restored position.
      if (scroller.scrollHeight <= scroller.clientHeight + 1) {
        await requestVisibility();
        let stable = 0;
        for (let step = 0; ; step++) {
          if (step >= 5000) throw new Error('не удалось вернуться к началу списка чатов');
          const current = rows(), ids = current.map(item => item.id).join(',');
          if (!current.length) throw new Error('список чатов исчез при возврате к началу');
          scroller = scrollContainer(current[0].row, scroller);
          wheelAt(current[0].row, -Math.max(80, scroller.clientHeight * 0.75));
          scrollEvent(scroller);
          await sleep(1000);
          await ensureRendering();
          await waitForLoading();
          if (scroller.scrollHeight > scroller.clientHeight + 1) {
            scroller.scrollTop = 0; scrollEvent(scroller); await sleep(600); break;
          }
          await waitFor(() => rows().map(item => item.id).join(',') !== ids, 2500);
          stable = rows().map(item => item.id).join(',') === ids ? stable + 1 : 0;
          if (stable >= 3) break;
        }
      }
      bottomStable = 0;
      triedScrollers = new WeakSet(); movedScrollers = new WeakSet();
    };
    const advance = async () => {
      await ensureRendering();
      // Checkpoint writes yield to React; the previously read row nodes may already be detached.
      let currentRows = rows();
      if (!currentRows.length) currentRows = await waitFor(() => { const fresh = rows(); return fresh.length ? fresh : null; }, 3000);
      if (!currentRows) throw new Error('список чатов обновляется и не появился снова — очистка остановлена');
      scroller = scrollContainer(currentRows[0].row, scroller) || (scroller?.isConnected ? scroller : null);
      if (!scroller || !scroller.isConnected) throw new Error('не удалось найти прокрутку списка чатов');
      triedScrollers.add(scroller);
      const before = { top: scroller.scrollTop, height: scroller.scrollHeight, viewport: scroller.clientHeight, ids: currentRows.map(item => item.id).join(',') };
      scroller.scrollTop = Math.min(scroller.scrollHeight - scroller.clientHeight, scroller.scrollTop + Math.max(80, scroller.clientHeight * 0.75));
      scrollEvent(scroller);
      await sleep(1000);
      await ensureRendering();
      const moved = Math.abs(scroller.scrollTop - before.top) > 1;
      if (moved) movedScrollers.add(scroller);
      const reachedEdge = () => scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 2;
      // An inactive virtualizer may expose only one screen and no scroll range at all.
      if ((moved || reachedEdge()) && document.hidden && !requestedVisibility && rows().map(item => item.id).join(',') === before.ids) {
        await requestVisibility();
      }
      const inViewport = () => {
        const bounds = scroller === document.scrollingElement ? { top: 0, bottom: innerHeight } : scroller.getBoundingClientRect();
        return rows().some(item => {
          const rect = item.row.getBoundingClientRect();
          return rect.bottom > Math.max(0, bounds.top) && rect.top < Math.min(innerHeight, bounds.bottom);
        });
      };
      if (moved && !inViewport() && !await waitFor(inViewport, 10000)) {
        throw new Error('список чатов не обновился после прокрутки — очистка остановлена');
      }
      const changed = () => !scroller.isConnected || scroller.scrollHeight !== before.height || scroller.clientHeight !== before.viewport || rows().map(item => item.id).join(',') !== before.ids;
      // At a provisional bottom, give the site a chance to append another page before declaring EOF.
      if (reachedEdge() && !changed()) {
        const last = rows().at(-1)?.row;
        if (last) {
          // Browser-native alignment also scrolls an ancestor that CSS metrics failed to identify.
          last.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'instant' });
          wheelAt(last, Math.max(80, scroller.clientHeight * 0.75));
        }
        await waitFor(changed, 2500);
      }
      await waitForLoading();
      await ensureRendering();
      if (!changed() && !movedScrollers.has(scroller)) {
        const first = rows()[0];
        const next = first && scrollCandidates(first.row).find(element => !triedScrollers.has(element));
        if (next) { scroller = next; bottomStable = 0; return false; }
      }
      const nextIds = rows().map(item => item.id).join(',');
      const atBottom = scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 2;
      if (atBottom && Math.abs(scroller.scrollTop - before.top) < 2 && scroller.scrollHeight === before.height && nextIds === before.ids) bottomStable++;
      else bottomStable = 0;
      if (bottomStable < 3) return false;
      // A clipped inner wrapper reaching its bottom is not the end of the outer chat list.
      const first = rows()[0];
      const next = first && scrollCandidates(first.row).find(element => !triedScrollers.has(element));
      if (next) { scroller = next; bottomStable = 0; return false; }
      return true;
    };
    const finish = async () => {
      let missing = 0;
      for (const id of targets) if (!completed.has(id)) { completed.add(id); missing++; }
      state.skipped += missing;
      if (missing) await log(`Чаты из плана не найдены в списке: ${missing}; подтверждение выхода не нажималось`, 'info');
      state.phase = 'done';
      await publish();
      return { ...state, loaded: true, visited: state.scanned };
    };

    await resetScroll();
    if (state.phase === 'scan') {
      // Count the full virtualized list before clicking anything. This is the progress denominator.
      for (let step = 0; ; step++) {
        if (step >= 5000) throw new Error('достигнут предел подсчёта чатов; очистка не начата');
        await sleep(100);
        await ensureRendering();
        await waitForUser();
        if (observedScroll !== activity.serial) {
          observedScroll = activity.serial;
          await log('Ручная прокрутка списка чатов: возвращаюсь к началу для полного подсчёта', 'info');
          await resetScroll(); continue;
        }
        const currentRows = rows();
        for (const item of currentRows) {
          discovered.add(item.id);
          if (item.status === 'Отказ') targets.add(item.id);
        }
        await publish();
        if (await advance() && observedScroll === activity.serial) break;
      }
      state.phase = 'cleanup'; state.processingStartedAt = Date.now();
      await publish();
      await log(`Подсчёт чатов: просмотрено ${state.scanned}, найдено отказов ${targets.size}`, 'info');
      await resetScroll();
    }
    if (completed.size === targets.size) return finish();

    for (let step = 0; step < 5000; step++) {
      await sleep(100);
      await ensureRendering();
      await waitForUser();
      if (observedScroll !== activity.serial) {
        observedScroll = activity.serial;
        await log('Ручная прокрутка списка чатов: продолжаю оставшийся план с начала списка', 'info');
        await resetScroll(); continue;
      }
      const currentRows = rows();
      for (const item of currentRows) discovered.add(item.id);
      let changed = false;
      for (const item of currentRows) if (targets.has(item.id) && !completed.has(item.id) && item.status !== 'Отказ') {
        completed.add(item.id); state.skipped++; changed = true;
      }
      if (changed) await publish(); else notify();
      if (completed.size === targets.size) return finish();
      const target = currentRows.find(item => targets.has(item.id) && item.status === 'Отказ' && !completed.has(item.id) && !attempted.has(item.id));
      if (target) {
        const generation = activity.serial;
        const click = (button, condition, accepted) => guardedClick(button,
          () => activity.serial === generation && condition(), accepted);
        let markedAttempt = false, confirmationSent = false, activeConfirmation = null;
        try {
          bottomStable = 0;
          target.row.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'instant' });
          await sleep(300);
          const freshRow = find(target.id);
          if (!freshRow || freshRow.status !== 'Отказ') continue;
          await click(() => find(target.id)?.row, () => find(target.id)?.status === 'Отказ');
          const menu = await waitFor(() => selected(target) && uniqueVisible(CHATS.menu), 12000);
          if (!menu) throw new Error(`не удалось подтвердить выбор чата #${target.id}`);
          await sleep(500);
          await click(() => uniqueVisible(CHATS.menu), () => eligible(target));
          const leave = await waitFor(() => uniqueVisible(CHATS.leave), 6000);
          if (!leave) throw new Error('пункт «Покинуть чат» не найден');
          await click(() => uniqueVisible(CHATS.leave), () => eligible(target));
          const confirm = await waitFor(confirmation, 6000);
          if (!confirm) throw new Error('не найдено ожидаемое окно подтверждения выхода');
          activeConfirmation = confirm;
          if (!eligible(target)) throw new Error(`статус или выбор чата #${target.id} изменился`);
          const priorAlerts = new Set(alerts());
          // Durable checkpoint before the irreversible click prevents a duplicate after a reload.
          attempted.add(target.id); state.pending = target.id;
          markedAttempt = true;
          await publish();
          await click(confirm.button, () => {
            const fresh = confirmation();
            return eligible(target) && fresh?.button === confirm.button && fresh.dialog === confirm.dialog;
          }, () => { confirmationSent = true; });
          state.total++;
          await publish();
          const closed = await waitFor(() => !confirm.dialog.isConnected || !visible(confirm.dialog), 12000);
          if (!closed) throw new Error(`hh.ru не закрыл подтверждение для чата #${target.id}; повторять не буду`);
          await sleep(800);
          const error = alerts().find(value => !priorAlerts.has(value) && /ошибк|не удалось|попробуйте|недоступ/i.test(value));
          if (error) throw new Error('hh.ru сообщил об ошибке после подтверждения выхода');
          state.pending = null; completed.add(target.id);
          await publish();
          await log(`Чат #${target.id}: нажато подтверждение «Покинуть чат»`, 'info');
          // The final HH success signal is not known yet. Row disappearance alone is never called success.
          continue;
        } catch (error) {
          if (activity.serial !== generation && !confirmationSent && isActive() && !['stopped', 'context'].includes(error.message)) {
            // The capture guard never accepted the final click, so this durable intent can be undone.
            if (markedAttempt) { attempted.delete(target.id); state.pending = null; await publish(); }
            await waitForUser();
            if (activeConfirmation?.dialog.isConnected && visible(activeConfirmation.dialog)) {
              const dialog = activeConfirmation.dialog;
              if (confirmation()?.dialog !== dialog) throw error;
              const cancel = [...dialog.querySelectorAll('button')].filter(button => visible(button)
                && !button.matches(CHATS.confirm) && /^(Отмена|Отменить|Остаться в чате)$/i.test(normalize(button.textContent)));
              if (cancel.length === 1) await guardedClick(cancel[0], () => confirmation()?.dialog === dialog);
              else HH.dom.pressEscape();
              if (!await waitFor(() => !dialog.isConnected || !visible(dialog), 4000)) {
                throw new Error('закройте окно подтверждения выхода и перезагрузите вкладку для продолжения очистки');
              }
            }
            // The next iteration waits for the user and rewinds, preserving the rest of the counted plan.
            continue;
          }
          throw error;
        }
      }

      if (await advance() && observedScroll === activity.serial) return finish();
    }
    throw new Error('достигнут предел прокрутки списка; очистка остановлена');
  }

  return { run: async initial => {
    const activity = { serial: 0, at: 0 };
    const onScrollInput = event => { if (event.isTrusted) { activity.serial++; activity.at = Date.now(); } };
    for (const name of ['wheel', 'touchmove']) document.addEventListener(name, onScrollInput, { capture: true, passive: true });
    try { return await run(initial, activity); }
    finally { for (const name of ['wheel', 'touchmove']) document.removeEventListener(name, onScrollInput, true); }
  } };
};

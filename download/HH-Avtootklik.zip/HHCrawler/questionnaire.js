/* Employer forms: literal facts may proceed; drafts require a trusted user click. No answer text in logs. */
(globalThis.HH ||= {}).quiz = (() => {
  const selector = 'textarea[name^="task_"],input[name^="task_"],select[name^="task_"]';
  const norm = value => String(value || '').replace(/\s+/g, ' ').trim();
  const label = field => norm([...field.labels || []].map(el => el.textContent).join(' ') || field.getAttribute('aria-label'));
  const htmlText = value => norm(new DOMParser().parseFromString(String(value), 'text/html').body.textContent);
  const idOf = field => /^task_(\d+)(?:_text)?$/.exec(field.name)?.[1];
  const visible = field => HH.dom.visible(field) || !!field.closest('label') && HH.dom.visible(field.closest('label'));

  function findTests(value, depth = 0) {
    if (!value || typeof value !== 'object' || depth > 14) return null;
    if (value.vacancyTests) return value.vacancyTests;
    for (const child of Object.values(value)) { const found = findTests(child, depth + 1); if (found) return found; }
    return null;
  }

  function tasksFromState(vacancyId) {
    for (const element of document.querySelectorAll('template,script')) {
      const value = element.textContent || '';
      if (value.length > 2000000 || !value.includes('vacancyTests')) continue;
      try {
        const tasks = findTests(JSON.parse(value))?.[String(vacancyId)]?.tasks;
        if (Array.isArray(tasks)) return new Map(tasks.map(task => [String(task.id), task]));
      } catch (_) { /* Not executable page code. Only JSON is considered. */ }
    }
    return new Map();
  }

  function questionText(fields, id) {
    const first = fields[0];
    if (first.tagName === 'TEXTAREA' && label(first)) return label(first);
    let block = first.parentElement;
    for (let parent = block?.parentElement, depth = 0; parent && parent !== document.body && depth < 7; parent = parent.parentElement, depth++) {
      if ([...parent.querySelectorAll(selector)].some(field => idOf(field) !== id)) break;
      block = parent;
    }
    const copy = block.cloneNode(true);
    for (const element of copy.querySelectorAll('input,textarea,select,button,script,style')) element.remove();
    for (const field of fields.filter(field => ['radio', 'checkbox'].includes(field.type))) {
      for (const element of [...copy.querySelectorAll('label')]) if (norm(element.textContent) === label(field)) element.remove();
    }
    return norm(copy.textContent).replace(/Писать тут/gi, '').trim();
  }

  function read(scope, vacancyId) {
    const fields = [...scope.querySelectorAll(selector)].filter(field => !field.disabled && visible(field));
    const groups = new Map(), tasks = tasksFromState(vacancyId);
    for (const field of fields) {
      const id = idOf(field);
      if (!id || field.tagName === 'SELECT' || !['textarea', 'text', 'radio', 'checkbox'].includes(field.type)) throw new Error('bad_questions');
      if (!groups.has(id)) groups.set(id, []);
      groups.get(id).push(field);
    }
    return [...groups].map(([id, fields]) => {
      const texts = fields.filter(field => field.tagName === 'TEXTAREA' || field.type === 'text');
      if (texts.length > 1 || texts.length && fields.length > 1) throw new Error('bad_questions');
      const type = texts.length ? 'text' : fields[0].type === 'checkbox' ? 'multiple' : 'single';
      if (type !== 'text' && fields.some(field => field.type !== fields[0].type)) throw new Error('bad_questions');
      const options = type === 'text' ? [] : fields.map(field => ({ id: field.value, text: label(field) }));
      const task = tasks.get(id);
      const question = task?.description ? htmlText(task.description) : questionText(fields, id);
      if (!question || question.length > 2000 || options.some(option => !option.text) || new Set(options.map(o => o.id)).size !== options.length) throw new Error('bad_questions');
      return { id, question, type, options, fields };
    });
  }

  const schema = questions => JSON.stringify(questions.map(({ fields, ...question }) => question));
  const values = questions => JSON.stringify(questions.map(q => q.type === 'text' ? q.fields[0].value : q.fields.filter(f => f.checked).map(f => f.value).sort()));
  const publicQuestions = questions => questions.map(({ fields, ...question }) => question);

  async function fill(questions, answers, helpers) {
    for (let index = 0; index < questions.length; index++) {
      const q = questions[index], answer = answers[index];
      if (q.fields.some(field => !field.isConnected)) throw new Error('form_changed');
      if (q.type === 'text') {
        await helpers.type(q.fields[0], answer.text);
        if (q.fields[0].value !== answer.text) throw new Error('form_changed');
      } else {
        for (const field of q.fields) {
          const wanted = answer.choice.includes(field.value);
          if (field.checked !== wanted && (wanted || q.type === 'multiple')) await helpers.click(field.closest('label') || field);
        }
        if (JSON.stringify(q.fields.filter(f => f.checked).map(f => f.value).sort()) !== JSON.stringify([...answer.choice].sort())) throw new Error('form_changed');
      }
    }
  }

  function validate(questions, response) {
    if (!Array.isArray(response) || response.length !== questions.length) throw new Error('bad_response');
    const answers = new Map();
    for (const a of response) {
      if (!a || typeof a.id !== 'string' || answers.has(a.id)) throw new Error('bad_response');
      answers.set(a.id, a);
    }
    return questions.map(q => {
      const a = answers.get(q.id);
      if (!a || typeof a.text !== 'string' || a.text.length > 4000 || typeof a.evidence !== 'string' || !Array.isArray(a.choice)) throw new Error('bad_response');
      if (new Set(a.choice).size !== a.choice.length || a.choice.some(id => !q.options.some(option => option.id === id)) || q.type === 'single' && a.choice.length > 1) throw new Error('bad_response');
      const populated = q.type === 'text' ? !!a.text.trim() : !!a.choice.length;
      return { ...a, requires_review: a.requires_review !== false || a.status !== 'confirmed' || !populated };
    });
  }

  function review(questions, answers, isActive) {
    return new Promise(resolve => {
      const host = document.createElement('div'); host.id = 'hh-resume-review';
      const shadow = host.attachShadow({ mode: 'closed' });
      const style = document.createElement('style');
      style.textContent = ':host{all:initial;position:fixed;z-index:2147483647;right:20px;bottom:20px;max-width:540px;width:calc(100vw - 40px);color:#202634;font:14px/1.5 system-ui}section{background:#fff;border:2px solid #3574d7;border-radius:12px;box-shadow:0 8px 40px #0005;padding:18px;max-height:75vh;overflow:auto}h2{font-size:18px;margin:0 0 8px}fieldset{border:1px solid #d8deea;margin:12px 0;padding:10px}legend{font-weight:600}textarea{display:block;box-sizing:border-box;width:100%;min-height:72px;font:inherit}label{display:block;margin:6px 0}blockquote{margin:8px 0;color:#536277;white-space:pre-wrap}button{padding:10px;margin:8px 8px 0 0;cursor:pointer;font:inherit}p{margin:8px 0}.error{color:#b52b32}';
      const section = document.createElement('section'); section.setAttribute('role', 'dialog'); section.setAttribute('aria-label', 'Проверка ответов на анкету');
      const heading = document.createElement('h2'); heading.textContent = 'Проверьте ответы работодателю';
      const detail = document.createElement('p'); detail.textContent = 'Черновики не отправлены. Проверьте каждый ответ, исправьте неточности и подтвердите продолжение.';
      section.append(heading, detail);
      const editors = questions.map((q, index) => {
        const fieldset = document.createElement('fieldset'), legend = document.createElement('legend');
        legend.textContent = q.question; fieldset.append(legend);
        const a = answers[index];
        let controls;
        if (q.type === 'text') {
          const input = document.createElement('textarea'); input.value = a.text; fieldset.append(input); controls = [input];
        } else controls = q.options.map(option => {
          const label = document.createElement('label'), input = document.createElement('input');
          input.type = q.type === 'single' ? 'radio' : 'checkbox'; input.name = 'review-' + q.id; input.value = option.id;
          input.checked = a.choice.includes(option.id); label.append(input, document.createTextNode(' ' + option.text)); fieldset.append(label); return input;
        });
        const evidence = document.createElement('blockquote');
        evidence.textContent = a.evidence ? 'Цитата из резюме: «' + a.evidence + '»' : 'Подтверждения в резюме нет. Заполните ответ самостоятельно.';
        fieldset.append(evidence); section.append(fieldset); return controls;
      });
      const error = document.createElement('p'); error.className = 'error'; error.setAttribute('role', 'alert');
      const accept = document.createElement('button'); accept.type = 'button'; accept.textContent = 'Проверил ответы — продолжить';
      const skip = document.createElement('button'); skip.type = 'button'; skip.textContent = 'Пропустить анкету';
      const done = value => { clearInterval(timer); host.remove(); resolve(value); };
      accept.addEventListener('click', event => {
        if (!event.isTrusted || !isActive()) return;
        const result = questions.map((q, index) => ({ ...answers[index],
          text: q.type === 'text' ? editors[index][0].value.trim() : '',
          choice: q.type === 'text' ? [] : editors[index].filter(input => input.checked).map(input => input.value) }));
        if (result.some((answer, index) => questions[index].type === 'text' ? !answer.text : !answer.choice.length)) {
          error.textContent = 'Заполните все ответы перед продолжением.'; return;
        }
        done(result);
      });
      skip.addEventListener('click', event => { if (event.isTrusted) done(null); });
      section.append(error, accept, skip); shadow.append(style, section); document.documentElement.append(host);
      const timer = setInterval(() => {
        if (!isActive() || questions.some(q => q.fields.some(field => !field.isConnected))) done(null);
      }, 500);
      accept.focus();
    });
  }

  async function prepare(scope, item, resume, options) {
    const originalURL = location.href;
    const questions = read(scope, item.id);
    if (!questions.length || questions.length > 20) throw new Error('bad_questions');
    const originalSchema = schema(questions), originalValues = values(questions);
    const unchanged = () => isCurrent() && schema(read(scope, item.id)) === originalSchema;
    const isCurrent = () => options.isActive() && location.href === originalURL && questions.every(q => q.fields.every(field => field.isConnected));
    const call = async (path, payload) => {
      const result = await chrome.runtime.sendMessage({ type: 'resumeAPI', path, payload });
      if (!result?.ok) throw new Error(result?.reason || 'network');
      return result;
    };
    let data = await call('/answers', { request_id: options.requestId, text: resume.text, questions: publicQuestions(questions) });
    const deadline = Date.now() + 150000;
    while (data.status === 'pending' && Date.now() < deadline) {
      if (!unchanged() || values(questions) !== originalValues) throw new Error('form_changed');
      await options.sleep(2500);
      data = await call('/result', { job_id: data.job_id });
    }
    if (data.status !== 'done') throw new Error(data.reason || 'waiting');
    if (!unchanged() || values(questions) !== originalValues) throw new Error('form_changed');
    let answers = validate(questions, data.answers);
    // Preserve pre-existing user entries and always review them instead of overwriting silently.
    const existing = questions.some(q => q.type === 'text' ? q.fields[0].value.trim() : q.fields.some(field => field.checked));
    if (existing) answers = answers.map((answer, index) => {
      const q = questions[index];
      return { ...answer, requires_review: true,
        text: q.type === 'text' && q.fields[0].value.trim() ? q.fields[0].value : answer.text,
        choice: q.type !== 'text' && q.fields.some(f => f.checked) ? q.fields.filter(f => f.checked).map(f => f.value) : answer.choice };
    });
    if (answers.some(answer => answer.requires_review)) {
      options.onReview();
      answers = await review(questions, answers, options.isActive);
      if (!answers) return null;
      if (!unchanged() || values(questions) !== originalValues) throw new Error('form_changed');
    }
    await fill(questions, answers, options);
    const filled = values(questions);
    return { count: questions.length, valid: () => unchanged() && values(questions) === filled };
  }

  function submit(scope) {
    const buttons = [...scope.querySelectorAll('button,input[type="submit"]')].filter(HH.dom.visible);
    return buttons.find(button => /^(откликнуться|отправить|отправить отклик|ответить и откликнуться)$/i.test(norm(button.textContent || button.value))) || null;
  }

  return { read, prepare, submit, validate };
})();

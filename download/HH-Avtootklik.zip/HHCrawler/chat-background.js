// Chrome debugger access is opt-in in the product and scoped to our own HH chat helper.
// Only visibility/focus emulation and navigation notifications are enabled.
globalThis.HHChatBackground = ({ isHelper, isEnabled = async () => false }) => {
  const owned = new Set(), blocked = new Set(), pending = new Map();
  const isChat = url => /^https:\/\/hh\.ru\/chat(?:[/?#]|$)/.test(String(url || ''));
  let listening = false;

  async function release(tabId) {
    blocked.delete(tabId);
    if (!owned.delete(tabId)) return;
    try { await chrome.debugger.sendCommand({ tabId }, 'Emulation.setFocusEmulationEnabled', { enabled: false }); } catch (_) {}
    try { await chrome.debugger.detach({ tabId }); } catch (_) {}
  }

  function observe() {
    if (listening) return;
    listening = true;
    chrome.debugger.onDetach.addListener((source, reason) => {
      if (!owned.delete(source.tabId)) return;
      if (reason !== 'target_closed') blocked.add(source.tabId);
    });
    chrome.debugger.onEvent.addListener((source, method, params) => {
      if (!owned.has(source.tabId) || method !== 'Page.frameNavigated' || params.frame?.parentId) return;
      if (!isChat(params.frame?.url)) release(source.tabId).then(() => blocked.add(source.tabId));
    });
  }

  async function ensure({ tabId, url, resume = false }) {
    if (tabId == null || !isChat(url) || !await isHelper(tabId)) return { ok: false, reason: 'not-helper' };
    if (!await isEnabled()) return { ok: false, reason: 'disabled' };
    if (!chrome.permissions?.contains || !await chrome.permissions.contains({ permissions: ['debugger'] })) {
      return { ok: false, reason: 'permission' };
    }
    if (!chrome.debugger?.sendCommand) return { ok: false, reason: 'unavailable', error: 'Браузер не поддерживает фоновый режим' };
    if (resume) blocked.delete(tabId);
    if (blocked.has(tabId)) return { ok: false, reason: 'detached' };
    if (pending.has(tabId)) return pending.get(tabId);
    observe();
    const work = (async () => {
      try {
        // An existing session may survive a service-worker restart. sendCommand is allowed only
        // if this extension owns it; a different debugger is never detached or replaced.
        let frameTree;
        try { frameTree = await chrome.debugger.sendCommand({ tabId }, 'Page.getFrameTree', {}); }
        catch (_) {
          await chrome.debugger.attach({ tabId }, '1.3');
          owned.add(tabId);
          frameTree = await chrome.debugger.sendCommand({ tabId }, 'Page.getFrameTree', {});
        }
        owned.add(tabId);
        if (!isChat(frameTree.frameTree?.frame?.url) || !await isHelper(tabId)) {
          await release(tabId);
          return { ok: false, reason: 'not-helper' };
        }
        await chrome.debugger.sendCommand({ tabId }, 'Emulation.setFocusEmulationEnabled', { enabled: true });
        await chrome.debugger.sendCommand({ tabId }, 'Page.enable', {});
        return { ok: true };
      } catch (error) {
        await release(tabId);
        return { ok: false, reason: 'unavailable', error: String(error.message || error) };
      }
    })();
    pending.set(tabId, work);
    try { return await work; } finally { pending.delete(tabId); }
  }

  chrome.permissions?.onRemoved?.addListener(permission => {
    if (permission.permissions?.includes('debugger')) Promise.all([...owned].map(release)).catch(() => {});
  });
  return { ensure, release, releaseAll: () => Promise.all([...owned].map(release)) };
};

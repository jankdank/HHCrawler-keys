// Селекторы hh.ru и помощники для работы со страницей. Без состояния — только чтение DOM.
// Скрипты расширения на странице грузятся по порядку (manifest.json) и делят общий объект HH.
(globalThis.HH ||= {}).dom = (() => {
  // Атрибуты data-qa hh.ru. Когда hh меняет вёрстку, править нужно здесь.
  const SEL = {
    card: '[data-qa~="vacancy-serp__vacancy"]',
    title: '[data-qa="serp-item__title"]',
    employer: '[data-qa="vacancy-serp__vacancy-employer"]',
    respond: '[data-qa="vacancy-serp__vacancy_response"]',
    next: '[data-qa="pager-next"]',
    page: '[data-qa="pager-page"]',
    popup: '[data-qa="vacancy-response-popup"]',
    submit: '[data-qa="vacancy-response-submit-popup"]',
    letterToggle: '[data-qa="vacancy-response-letter-toggle"]',
    letterInput: '[data-qa="vacancy-response-popup-form-letter-input"]',
    relocation: '[data-qa="relocation-warning-confirm"]',
    captcha: '[data-qa="account-captcha-input"], img[src*="captcha"], iframe[src*="captcha"]',
    login: 'a[href*="/account/login"], [data-qa="login"]',
  };

  // Выбор резюме (функция «Выбор резюме по названию вакансии», с 2.10.0).
  // ЗАГЛУШКА: точные селекторы hh.ru ещё не подтверждены на живой странице (нужен вывод из DOM).
  // Пока RESUME.ready = false, расширение резюме в форме не выбирает (см. content.js), поэтому
  // пустые селекторы ничего не ломают. Заполнить по DOM окна отклика и страницы /applicant/resumes.
  const RESUME = {
    ready: false, // станет true, когда селекторы ниже проверены на hh.ru
    // В окне отклика (SEL.popup) каждый вариант резюме и его хеш hh.ru/resume/<хеш>:
    formOption: '', // напр. 'input[type=radio][name="resume"]' или '[data-qa="resume-option"]'
    formOptionResumeHref: 'a[href*="/resume/"]', // ссылка рядом с вариантом, из неё берём хеш
    // На странице /applicant/resumes — карточка резюме, её ссылка (хеш) и название:
    pageItem: '', // напр. '[data-qa="resume"]'
    pageItemHref: 'a[href*="/resume/"]',
    pageItemTitle: '', // напр. '[data-qa="resume-title"]'
  };

  // Селекторы /chat из DOM-выгрузки пользователя; статус читается только в строке списка.
  const CHATS = {
    row: 'a[id^="chat-cell-"][data-qa^="chatik-open-chat-"]',
    status: '[data-qa="chat-cell-last-message"]',
    menu: 'button[data-qa="chatik-chat-menu"]',
    leave: 'button[data-qa="chatik-chat-leave-chat"]',
    alert: '[data-qa="chatik-leave-chat-alert"]',
    warning: '[data-qa="title-description"]',
    confirm: 'button[data-qa="chatik-leave-chat-confirm-button"]',
  };

  // Хеш резюме из адреса hh.ru/resume/<хеш> (буквы/цифры), иначе null.
  const resumeHash = (href) => (String(href || '').match(/\/resume\/([0-9a-f]+)/i) || [])[1] || null;

  const isSerp = () => location.pathname.startsWith('/search/vacancy');
  const isLoginPage = () => location.pathname.startsWith('/account/login');

  // Номер страницы выдачи по адресу ('0', '1', …) или null, если это не выдача.
  const serpPage = (url) => {
    const u = new URL(url, location.origin);
    return u.pathname.startsWith('/search/vacancy') ? u.searchParams.get('page') || '0' : null;
  };

  const rand = (min, max) => Math.floor(min + Math.random() * (max - min + 1));
  const text = (root, sel) => (root.querySelector(sel)?.textContent || '').trim();
  const visible = (el) => !!el && el.isConnected && el.getClientRects().length > 0;

  // Первый ВИДИМЫЙ элемент по селектору. querySelector вернул бы первый в разметке,
  // а им может оказаться скрытый дубль (hh.ru держит в DOM старые элементы окон).
  const visibleOne = (sel) => [...document.querySelectorAll(sel)].find(visible) || null;

  const btnText = (b) => (b.textContent || b.value || '').replace(/\s+/g, ' ').trim();
  const isDisabled = (b) => b.disabled || b.getAttribute('aria-disabled') === 'true';
  const buttonByText = (root, re) =>
    [...root.querySelectorAll('button, a[role="button"]')].find((b) => visible(b) && re.test(b.textContent.trim()));

  function vacancyId(btn, card) {
    const m =
      (btn?.getAttribute('href') || '').match(/vacancyId=(\d+)/) ||
      (card?.querySelector(SEL.title)?.getAttribute('href') || '').match(/vacancy\/(\d+)/);
    return m ? m[1] : null;
  }

  function pressEscape() {
    const o = { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true };
    document.activeElement?.dispatchEvent(new KeyboardEvent('keydown', o));
    document.dispatchEvent(new KeyboardEvent('keydown', o));
  }

  // Строка под счётчиками: до какого времени действует суточный лимит hh.ru ('' — лимита нет).
  const limitLine = (l) => {
    if (!l || l.until <= Date.now()) return '';
    const t = new Date(l.until).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
    return `Лимит 24 ч до ${t}${l.exact ? '' : ' (не позже)'}`;
  };

  return { SEL, RESUME, CHATS, resumeHash, isSerp, isLoginPage, serpPage, rand, text, visible, visibleOne, btnText, isDisabled, buttonByText, vacancyId, pressEscape, limitLine };
})();

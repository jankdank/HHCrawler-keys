// Страница «Что нового»: показывает CHANGELOG.md из папки расширения.
// Файл .md браузер открывает как текст в неверной кодировке, поэтому разбираем его здесь сами:
// «# …» — заголовок файла (пропускаем), «## 2.8.0 …» — версия, «- …» — пункт. Только textContent, без HTML.
(async () => {
  const current = chrome.runtime.getManifest().version;
  document.getElementById('current').textContent = `У вас версия ${current}`;
  const box = document.getElementById('log');
  let text = '';
  try {
    text = await (await fetch(chrome.runtime.getURL('CHANGELOG.md'))).text();
  } catch {}
  const sections = [];
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (line.startsWith('## ')) sections.push({ title: line.slice(3).trim(), items: [] });
    else if (/^[-*] /.test(line) && sections.length) sections[sections.length - 1].items.push(line.slice(2).trim());
  }
  if (!sections.length) {
    box.innerHTML = '';
    const p = document.createElement('p');
    p.className = 'empty';
    p.textContent = 'Список изменений не найден.';
    box.append(p);
    return;
  }
  box.innerHTML = '';
  box.style.display = 'grid';
  box.style.gap = '12px';
  for (const s of sections) {
    const sec = document.createElement('section');
    const h = document.createElement('h2');
    h.textContent = s.title;
    if (s.title.split(/\s/)[0] === current) {
      sec.className = 'now';
      const tag = document.createElement('span');
      tag.className = 'tag';
      tag.textContent = 'ваша версия';
      h.append(tag);
    }
    const ul = document.createElement('ul');
    for (const item of s.items) {
      const li = document.createElement('li');
      li.textContent = item;
      ul.append(li);
    }
    sec.append(h, ul);
    box.append(sec);
  }
})();

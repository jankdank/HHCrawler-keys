// Лицензия: проверка на сервере.
//
// Расширение спрашивает сервер (API_URL): «действует ли лицензия для этого ID?», при первом вводе
// ключа передаёт его. Сервер отвечает сроком окончания и подписью над «ID:срок». Подпись проверяется
// встроенным публичным ключом PUBKEY (ECDSA P-256) — подделать срок без секретного ключа сервера нельзя,
// а список ключей на сервере, не в публичном файле. Если сервер недоступен, расширение работает ещё 3 дня.
//
// Общий файл: подключают фоновая часть (ходит на сервер и пишет запись license), окно расширения и
// скрипт на странице (только читают). Здесь — расчёты и проверка подписи, без прямой работы с хранилищем.
var HHLicense = (() => {
  // Адрес сервера лицензий. Должен быть по HTTPS (за nginx). Поменяйте на свой домен.
  const API_URL = 'https://lic.movera.blog/api/license';
  // Капча через общий ключ RuCaptcha: ключ хранится на сервере, решать можно только с лицензией.
  const CAPTCHA_URL = API_URL.replace(/\/license$/, '/captcha');
  // Какая версия сейчас в боте (кнопка «Скачать») — чтобы предложить обновиться.
  const VERSION_URL = API_URL.replace(/\/license$/, '/version');
  // Публичный ключ сервера (base64, несжатая точка P-256). Бот печатает его в журнале при запуске:
  // «Публичный ключ лицензий …». Вставьте сюда и пересоберите расширение.
  const PUBKEY = 'BNbv4PnJO/kBTDixPp1C6dC2qKjmEZdcG6xtWq+oyoySplbvIeJeAF+7FU3OMqC5bzY8/GIjVOLvtyhPsNFpGkY=';
  const DAY = 24 * 60 * 60 * 1000;
  const GRACE = 3 * DAY; // столько расширение работает без связи с сервером
  const ID_ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ'; // без I, L, O, U — их путают с 1, 0 и V
  // Бот, где продаются ключи. Ссылка передаёт ID (start=hh_<ID>), и бот сразу предлагает тариф.
  const BOT_URL = 'https://t.me/LicenseHelper_bot';
  const buyUrl = (userId) => (userId ? `${BOT_URL}?start=hh_${userId}` : BOT_URL);
  // Перенос лицензии на этот ID (после переустановки ID новый): бот спросит, с какого старого ID
  const moveUrl = (userId) => (userId ? `${BOT_URL}?start=move_${userId}` : BOT_URL);

  // «2.10.0» новее «2.9.1»: сравниваем числа по частям, а не строки.
  function newer(a, b) {
    const pa = String(a || '').split('.').map(Number);
    const pb = String(b || '').split('.').map(Number);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const x = pa[i] || 0;
      const y = pb[i] || 0;
      if (x !== y) return x > y;
    }
    return false;
  }

  const norm = (s) => String(s || '').replace(/\s+/g, '').toUpperCase();

  function newUserId() {
    const chars = [...crypto.getRandomValues(new Uint8Array(8))].map((b) => ID_ALPHABET[b % 32]).join('');
    return `${chars.slice(0, 4)}-${chars.slice(4)}`;
  }

  const b64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

  let keyPromise = null;
  function publicKey(pub = PUBKEY) {
    if (!keyPromise) {
      keyPromise = crypto.subtle.importKey('raw', b64(pub), { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
    }
    return keyPromise;
  }

  // Проверяет подпись ответа сервера. tok = { ext_id, exp, sig }. Срок (exp) — в секундах.
  async function verifyToken(tok, pub = PUBKEY) {
    if (!pub || !tok || !tok.sig || !tok.ext_id || !tok.exp) return false;
    try {
      const data = new TextEncoder().encode(`${tok.ext_id}:${tok.exp}`);
      return await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, await publicKey(pub), b64(tok.sig), data);
    } catch {
      return false;
    }
  }

  // lic — запись license из chrome.storage.local, которую пишет фоновая часть:
  // { userId, exp (мс, 0 — лицензии нет), checkedAt (мс), reason, error }.
  // exp и срок проверяет сервер; здесь — только истёк ли он и давно ли была связь.
  function status(lic, now = Date.now()) {
    now = Math.max(now, lic?.checkedAt || 0); // перевод часов назад срок не продлевает
    const base = { userId: lic?.userId || '', error: lic?.error || '' };
    const exp = lic?.exp || 0;
    const stale = !lic?.checkedAt || now - lic.checkedAt > GRACE;
    if (exp && now >= exp) return { ...base, ok: false, reason: 'expired', until: exp };
    if (exp && !stale) return { ...base, ok: true, until: exp, daysLeft: Math.ceil((exp - now) / DAY) };
    if (exp && stale) return { ...base, ok: false, reason: 'offline', until: exp };
    if (lic?.reason === 'revoked' || lic?.reason === 'bad_key') return { ...base, ok: false, reason: 'revoked' };
    return { ...base, ok: false, reason: 'no_key' };
  }

  const fmtDate = (t) => new Date(t).toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' });

  // where — куда вводить ключ: на странице это окно расширения, в самом окне — раздел ниже.
  function message(st, where = 'в окне расширения (раздел «Лицензия»)') {
    switch (st.reason) {
      case 'no_key':
        return `Нужна лицензия: введите ключ ${where}`;
      case 'revoked':
        return 'Ключ лицензии больше не действует — обратитесь к продавцу';
      case 'expired':
        return `Срок лицензии истёк ${fmtDate(st.until)} — введите новый ключ ${where}`;
      case 'offline':
        return 'Не удаётся проверить лицензию больше 3 дней — нужен доступ к серверу лицензий (интернет)';
      default:
        return `Лицензия активна до ${fmtDate(st.until)}`;
    }
  }

  return { API_URL, CAPTCHA_URL, VERSION_URL, newer, BOT_URL, PUBKEY, DAY, GRACE, norm, newUserId, buyUrl, moveUrl, verifyToken, status, fmtDate, message };
})();

const DEFAULTS = { maxApplications: 0, minDelay: 30, maxDelay: 60, useLetter: false, letter: '', letterRules: [], bumpResume: true, clearRejections: true, captchaService: 'rucaptcha', polzaKey: '', captchaBreak: 5 };
const $ = (id) => document.getElementById(id);

// ---------- плавные блоки ----------
const setOpen = (id, open) => $(id).classList.toggle('open', !!open);

// Полоса с текстом: при закрытии текст не стираем, чтобы он плавно уехал вместе с полосой.
function showBanner(foldId, el, text) {
  if (text) el.textContent = text;
  setOpen(foldId, !!text);
}
const showMsg = (text) => showBanner('msgFold', $('msg'), text);

const syncLetterState = () => {
  const on = $('useLetter').checked;
  $('letter').disabled = !on;
  setOpen('letterFold', on);
  setOpen('letterOffFold', !on);
};

// Видно в заголовке, когда раздел «Перед стартом» свёрнут.
const syncPrestartSummary = () => {
  const on = [$('bumpResume').checked && 'резюме', $('clearRejections').checked && 'отказы'].filter(Boolean);
  // Подсказка в заголовке свёрнутого раздела.
  $('prestartSummary').textContent = on.length ? on.join(' + ') : 'выключено';
};

// Видно в заголовке, когда раздел «Пауза» свёрнут.
const syncPauseSummary = () => {
  $('pauseSummary').textContent = `${$('minDelay').value || '?'}–${$('maxDelay').value || '?'} сек`;
  // Очень короткие паузы hh.ru замечает: растёт шанс капчи и блокировки.
  const fast = Math.max(1, parseInt($('maxDelay').value, 10) || 0) < 10;
  $('pauseWarn').hidden = !fast;
};

// Показывает поле ключа только для выбранного сервиса капчи.
const SERVICE_NAMES = { rucaptcha: 'RuCaptcha', qwen: 'Нейросеть' };
const syncCaptchaService = () => {
  const qwen = $('captchaService').value === 'qwen';
  setOpen('rucaptchaKeyRow', !qwen);
  setOpen('polzaKeyRow', qwen);
  // RuCaptcha — общий ключ на сервере, свой нужен только нейросети
  const keyNote = !qwen ? 'общий ключ' : $('polzaKey').value.trim() ? 'ключ задан' : 'нет ключа';
  $('captchaSummary').textContent = `${SERVICE_NAMES[$('captchaService').value] || ''} · ${keyNote}`;
};

// ---------- сворачиваемые разделы ----------
// Открыт ли раздел по умолчанию. «Капча» нужна редко — свёрнута. Выбор пользователя помним в этом окне.
// «Лицензия» свёрнута, пока ключ действует; без него раскрывается сама (renderLicense).
const SECTIONS = { license: false, pause: true, prestart: true, letter: true, captcha: false, resume: false, log: true };

function setSectionOpen(name, open, remember = true) {
  const btn = document.querySelector(`[data-section-toggle="${name}"]`);
  btn.setAttribute('aria-expanded', String(open));
  setOpen(btn.getAttribute('aria-controls'), open);
  if (remember) try { localStorage.setItem(`open:${name}`, open ? '1' : '0'); } catch {}
}

function initSections() {
  for (const [name, byDefault] of Object.entries(SECTIONS)) {
    let open = byDefault;
    try {
      const saved = localStorage.getItem(`open:${name}`);
      if (saved !== null) open = saved === '1';
      else if (name === 'captcha') open = localStorage.getItem('captchaOpen') === '1'; // ключ версии 1.8.3
    } catch {}
    setSectionOpen(name, open, false);
    document.querySelector(`[data-section-toggle="${name}"]`).addEventListener('click', (e) => {
      setSectionOpen(name, e.currentTarget.getAttribute('aria-expanded') !== 'true');
    });
  }
}

// ---------- подсказки компактных настроек ----------
function initSettingHelp() {
  let active = null;
  let closeTimer;

  function hide() {
    clearTimeout(closeTimer);
    if (!active) return;
    active.tooltip.hidden = true;
    active.button.classList.remove('help-open');
    active = null;
  }

  function show(button) {
    clearTimeout(closeTimer);
    for (let parent = button.parentElement; parent; parent = parent.parentElement) {
      if (parent.matches('.fold:not(.open)')) { hide(); return; }
    }
    if (active?.button === button) return;
    hide();
    const tooltip = $(button.getAttribute('aria-describedby'));
    const content = tooltip.querySelector('.tooltip-content');
    const anchor = button.getBoundingClientRect();
    const row = button.closest('.switch-row, .rules-head, .card-row').getBoundingClientRect();
    const margin = 12, gap = 9;
    const width = document.documentElement.clientWidth;
    const height = document.documentElement.clientHeight;
    tooltip.style.width = `${Math.min(row.width, width - 2 * margin)}px`;
    content.style.maxHeight = `${height - 2 * margin - 2}px`;
    tooltip.hidden = false;
    const below = Math.max(0, height - anchor.bottom - gap - margin);
    const above = Math.max(0, anchor.top - gap - margin);
    const side = tooltip.offsetHeight <= below || below >= above ? 'below' : 'above';
    content.style.maxHeight = `${Math.max(0, (side === 'below' ? below : above) - 2)}px`;
    const left = Math.max(margin, Math.min(row.left, width - tooltip.offsetWidth - margin));
    const top = side === 'below' ? anchor.bottom + gap : anchor.top - gap - tooltip.offsetHeight;
    tooltip.style.left = `${left}px`;
    tooltip.style.top = `${Math.max(margin, top)}px`;
    tooltip.style.setProperty('--arrow-x', `${Math.max(12, Math.min(anchor.left + anchor.width / 2 - left, tooltip.offsetWidth - 12))}px`);
    tooltip.dataset.side = side;
    button.classList.add('help-open');
    active = { button, tooltip };
  }

  function scheduleHide() {
    clearTimeout(closeTimer);
    closeTimer = setTimeout(() => {
      if (active && !active.button.matches(':hover, :focus') && !active.tooltip.matches(':hover')) hide();
    }, 150);
  }

  for (const button of document.querySelectorAll('.setting-help')) {
    const tooltip = $(button.getAttribute('aria-describedby'));
    button.addEventListener('mouseenter', () => show(button));
    button.addEventListener('focus', () => show(button));
    button.addEventListener('click', () => show(button));
    button.addEventListener('mouseleave', scheduleHide);
    button.addEventListener('blur', scheduleHide);
    tooltip.addEventListener('mouseenter', () => clearTimeout(closeTimer));
    tooltip.addEventListener('mouseleave', scheduleHide);
  }
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') hide(); });
  document.addEventListener('click', (e) => {
    if (active && !active.button.contains(e.target) && !active.tooltip.contains(e.target)) hide();
  });
  window.addEventListener('resize', hide);
  window.addEventListener('scroll', (e) => {
    if (!active || active.tooltip.contains(e.target)) return;
    const button = active.button;
    const rect = button.getBoundingClientRect();
    hide();
    // Tab может сам прокрутить окно к кнопке — сохраняем подсказку у видимого фокуса.
    if ((button === document.activeElement || button.matches(':hover')) && rect.top >= 0 && rect.bottom <= document.documentElement.clientHeight) show(button);
  }, true);
}

// Та же строка, что и на панели на странице: до какого времени действует суточный лимит hh.ru.
const limitLine = (l) => {
  if (!l || l.until <= Date.now()) return '';
  const t = new Date(l.until).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  return `Лимит 24 ч до ${t}${l.exact ? '' : ' (не позже)'}`;
};

async function loadSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  const s = { ...DEFAULTS, ...(settings || {}) };
  $('maxApplications').value = s.maxApplications || '';
  $('minDelay').value = s.minDelay;
  $('maxDelay').value = s.maxDelay;
  $('useLetter').checked = s.useLetter;
  $('letter').value = s.letter;
  renderRules(s.letterRules || []);
  $('captchaService').value = s.captchaService || 'rucaptcha';
  $('polzaKey').value = s.polzaKey || '';
  $('captchaBreak').value = s.captchaBreak ?? DEFAULTS.captchaBreak;
  $('bumpResume').checked = !!s.bumpResume;
  $('clearRejections').checked = !!s.clearRejections;
  syncPrestartSummary();
  syncLetterState();
  syncPauseSummary();
  syncCaptchaService();
}

async function saveSettings() {
  const targetInput = $('maxApplications');
  const maxApplications = targetInput.value === '' ? 0 : Number(targetInput.value);
  const validTarget = !targetInput.validity.badInput && Number.isSafeInteger(maxApplications)
    && (targetInput.value === '' || maxApplications > 0);
  targetInput.setCustomValidity(validTarget ? '' : 'Укажите целое число от 1 или оставьте поле пустым');
  if (!validTarget) return false;
  // Минимум — 1 секунда. Пустое поле — значение по умолчанию.
  const sec = (id, byDefault) => {
    const n = parseInt($(id).value, 10);
    return Number.isFinite(n) ? Math.max(1, n) : byDefault;
  };
  let min = sec('minDelay', DEFAULTS.minDelay);
  let max = sec('maxDelay', DEFAULTS.maxDelay);
  if (max < min) [min, max] = [max, min];
  // Пустое/некорректное поле — значение по умолчанию; явный 0 — перерыв отключён.
  const brk = parseInt($('captchaBreak').value, 10);
  const captchaBreak = Number.isFinite(brk) && brk >= 0 ? brk : DEFAULTS.captchaBreak;
  await chrome.storage.local.set({
    settings: {
      maxApplications,
      minDelay: min,
      maxDelay: max,
      useLetter: $('useLetter').checked,
      letter: $('letter').value,
      letterRules: collectRules(),
      captchaService: $('captchaService').value,
      polzaKey: $('polzaKey').value.trim(),
      captchaBreak,
      bumpResume: $('bumpResume').checked,
      clearRejections: $('clearRejections').checked,
    },
  });
  return true;
}

// ---------- счётчики: плавно докручиваются до нового значения ----------
const shown = {};
function setCount(id, value) {
  const el = $(id);
  const from = shown[id] ?? 0;
  shown[id] = value;
  if (from === value) {
    el.textContent = value;
    return;
  }
  const tile = el.closest('.stat');
  tile.classList.remove('bump');
  void tile.offsetWidth; // перезапуск анимации
  tile.classList.add('bump');
  const start = performance.now();
  const dur = 550;
  const step = (now) => {
    const k = Math.min(1, (now - start) / dur);
    el.textContent = Math.round(from + (value - from) * (1 - (1 - k) ** 3));
    if (k < 1 && shown[id] === value) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

// ---------- журнал: новые записи въезжают, старые не перерисовываются ----------
const fmtTime = (t) => {
  const d = new Date(t);
  const time = d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  return d.toDateString() === new Date().toDateString()
    ? time
    : `${d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' })} ${time}`;
};

function makeEntry(e, key) {
  const row = document.createElement('div');
  row.className = `entry ${e.kind || 'info'}`;
  row.dataset.key = key;
  const time = document.createElement('span');
  time.className = 'time';
  time.textContent = fmtTime(e.t);
  const text = document.createElement('span');
  text.className = 'text';
  const m = /^([✔↷✖])\s*/.exec(e.msg || '');
  if (m) {
    const mark = document.createElement('span');
    mark.className = 'mark';
    mark.textContent = m[1];
    text.append(mark, e.msg.slice(m[0].length));
  } else {
    text.textContent = e.msg;
  }
  row.append(time, text);
  return row;
}

let logReady = false;
function renderLog(log) {
  const list = $('log');
  const items = log.slice(-100).reverse();
  const existing = new Map([...list.children].map((el) => [el.dataset.key, el]));
  const rows = items.map((e) => {
    const key = `${e.t}|${e.msg}`;
    let row = existing.get(key);
    if (!row) {
      row = makeEntry(e, key);
      if (logReady) {
        row.classList.add('enter');
        // Иначе анимация повторялась бы при каждом переносе строки в списке.
        row.addEventListener('animationend', () => row.classList.remove('enter'), { once: true });
      }
    }
    return row;
  });
  list.replaceChildren(...rows);
  logReady = true;
  $('logCount').textContent = log.length ? String(log.length) : '';
  $('logEmpty').hidden = log.length > 0;
}

// ---------- состояние ----------
const STATE_LABELS = { idle: 'Остановлено', run: 'Работает', wait: 'Пауза', stale: 'Прервано' };

async function render() {
  const { active, run, log = [], limit, chore_bump: bump, chore_clear: clear, license, update } =
    await chrome.storage.local.get(['active', 'run', 'log', 'limit', 'chore_bump', 'chore_clear', 'license', 'update']);
  const lic = HHLicense.status(license);
  // «Старт» доступен всегда: он перезапускает работу в текущей вкладке, даже если
  // в памяти остался «запущен» от вкладки, которую перезагрузили или закрыли.
  // Кроме одного случая — ключ ещё не введён. Истёкший или отозванный ключ «Старт» проверит заново.
  $('start').disabled = lic.reason === 'no_key';
  renderLicense(license, lic);
  renderUpdate(update);
  // Помощник (поднятие резюме / удаление отказов) может работать, когда отклики уже закончились —
  // «Стоп» тогда остаётся доступным, чтобы его можно было остановить.
  const choreRunning = bump?.state === 'running' || clear?.state === 'running';
  $('stop').disabled = !active && !choreRunning;
  // Отсчёт перерыва обновляет run раз в 5 с. Если обновлений давно нет — работа прервалась.
  const lastAlive = Math.max(run?.heartbeat || 0, run?.breakUntil || 0);
  const stale = !!active && Date.now() - lastAlive > 3 * 60 * 1000;
  showBanner('hintFold', $('hint'), stale
    ? 'Работа прервалась: вкладку перезагрузили, закрыли или обновили расширение. Нажмите «Старт».'
    : '');

  const state = !active ? 'idle' : stale ? 'stale' : /^(Следующее действие|Перерыв)/.test(run?.status || '') ? 'wait' : 'run';
  document.body.dataset.state = state;
  $('pillText').textContent = STATE_LABELS[state];

  for (const k of ['applied', 'skipped', 'errors', 'earlier']) setCount(k, run?.[k] ?? 0);
  $('applicationGoal').hidden = !run?.successLimit;
  $('applicationGoal').textContent = run?.successLimit
    ? `Успешных за запуск: ${run.successCount ?? run.applied ?? 0} из ${run.successLimit}` : '';
  showBanner('limitFold', $('limit'), limitLine(limit));
  // Статус пишет скрипт на странице. Когда запуск не идёт, старая строка — уже история,
  // показывать её не нужно: что было, видно в журнале.
  $('status').textContent = active ? run?.status || 'Запуск…' : 'Не запущено';
  $('resetCaptchaBreak').disabled = !run?.breakUntil;
  // Что делают вкладки-помощники прямо сейчас.
  const chores = [];
  if (bump?.state === 'running') {
    const pct = bump.expected ? ` (${Math.min(100, Math.floor((bump.total / bump.expected) * 100))}%)` : '';
    chores.push(`поднимаю резюме${bump.total ? `: ${bump.total}${bump.expected ? ` из ${bump.expected}` : ''}${pct}` : ''}`);
  }
  if (clear?.state === 'running') {
    const pct = clear.expected ? ` (${Math.min(100, Math.floor((clear.total / clear.expected) * 100))}%)` : '';
    chores.push(`удаляю отказы${clear.total ? `: ${clear.total}${clear.expected ? ` из ${clear.expected}` : ''}${pct}` : ''}`);
  }
  $('chores').textContent = chores.length ? `В отдельной вкладке: ${chores.join(', ')}` : '';
  renderLog(log);
}

// ---------- лицензия (license.js) ----------
let licenseOpened = false;
// Новая версия в боте: полоса-ссылка на бота, где кнопка «Скачать» и инструкция по установке.
function renderUpdate(update) {
  const current = chrome.runtime.getManifest().version;
  const latest = update?.latest;
  const text = HHLicense.newer(latest, current)
    ? `Доступна версия ${latest} (у вас ${current}) — нажмите, чтобы скачать в боте.`
    : '';
  $('update').href = HHLicense.BOT_URL;
  showBanner('updateFold', $('update'), text);
}

function renderLicense(license, st) {
  $('userId').textContent = license?.userId || '…';
  $('buyLink').href = HHLicense.buyUrl(license?.userId);
  $('moveLink').href = HHLicense.moveUrl(license?.userId);
  $('moveRow').hidden = st.ok;
  const sum = $('licenseSummary');
  sum.textContent = st.ok ? `до ${HHLicense.fmtDate(st.until)}` : st.reason === 'no_key' ? 'нет ключа' : 'не действует';
  sum.className = `summary ${!st.ok ? 'bad' : st.daysLeft <= 3 ? 'warn' : 'good'}`;

  // Полоса над кнопками: без лицензии — что делать, в последние 3 дня — когда закончится.
  let banner = '';
  if (!st.ok) banner = HHLicense.message(st, 'в разделе «Лицензия» ниже');
  else if (st.daysLeft <= 3) banner = `Лицензия заканчивается ${HHLicense.fmtDate(st.until)} (осталось ${st.daysLeft} дн.) — попросите у продавца новый ключ.`;
  $('licBanner').className = `banner ${st.ok ? 'warn' : 'danger'}`;
  showBanner('licBannerFold', $('licBanner'), banner);

  const info = [];
  if (st.ok) info.push(`Действует до ${HHLicense.fmtDate(st.until)}, осталось ${st.daysLeft} дн. Новый ключ продлевает срок.`);
  if (st.error) info.push(`Последняя проверка ключа не удалась: ${st.error}.`);
  $('licenseInfo').textContent = info.join(' ');

  // Без лицензии раздел раскрывается сам — один раз за открытие окна, дальше решает пользователь.
  if (!st.ok && !licenseOpened) {
    licenseOpened = true;
    setSectionOpen('license', true, false);
  }
}

function sayLicense(text, kind = '') {
  $('licenseMsg').textContent = text;
  $('licenseMsg').className = `note ${kind}`;
}

async function activateLicense() {
  const key = $('licenseKey').value.trim();
  if (!key) return sayLicense('Вставьте ключ, который прислал продавец.', 'bad');
  $('activate').disabled = true;
  sayLicense('Проверяю ключ…');
  let res = null;
  try {
    res = await chrome.runtime.sendMessage({ type: 'licenseActivate', key });
  } catch {}
  $('activate').disabled = false;
  if (!res) return sayLicense('Расширение не ответило — попробуйте ещё раз.', 'bad');
  if (!res.ok) return sayLicense(res.error, 'bad');
  $('licenseKey').value = '';
  sayLicense(res.already ? 'Этот ключ уже активирован.' : `Ключ принят: доступ до ${HHLicense.fmtDate(res.status.until)}.`, 'good');
}

$('activate').addEventListener('click', activateLicense);
$('licenseKey').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    activateLicense();
  }
});

$('copyUserId').addEventListener('click', async () => {
  const id = $('userId').textContent;
  if (!/\w/.test(id)) return;
  try {
    await navigator.clipboard.writeText(id);
    $('copyText').textContent = 'Скопировано';
  } catch {
    getSelection().selectAllChildren($('userId')); // скопировать можно будет вручную
  }
  setTimeout(() => ($('copyText').textContent = 'Копировать'), 1500);
});

// ---------- кнопки ----------
$('start').addEventListener('click', async () => {
  showMsg('');
  if ($('useLetter').checked && !HHLetter.hasAnyText({ letter: $('letter').value, letterRules: collectRules() })) {
    showMsg('Письма включены, но нет ни одного текста письма.');
    return;
  }
  if (!(await saveSettings())) {
    showMsg('Укажите целое число успешных откликов от 1 или оставьте поле пустым.');
    $('maxApplications').focus();
    return;
  }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try {
    const res = await chrome.tabs.sendMessage(tab.id, { type: 'start' });
    if (!res?.ok) showMsg(res?.error || 'Не удалось запустить');
  } catch {
    showMsg('Откройте страницу поиска вакансий на hh.ru (если она уже открыта — обновите её).');
  }
});

$('stop').addEventListener('click', async () => {
  // stopChores закрывает и вкладки-помощники (резюме, отказы).
  await chrome.storage.local.set({ active: false, stopChores: Date.now() });
});

// Обнуляет перерыв после капчи: content script увидит это в storage и продолжит, не дожидаясь конца.
$('resetCaptchaBreak').addEventListener('click', async () => {
  const { run } = await chrome.storage.local.get('run');
  if (!run?.breakUntil) return;
  // Статус меняем сами: если скрипт на странице уже не работает, обновить строку больше некому.
  // Когда он работает, он тут же перепишет её своим отсчётом или следующим действием.
  await chrome.storage.local.set({ run: { ...run, breakUntil: 0, status: 'Таймер капчи сброшен' } });
});

// ---------- очистка журнала с вопросом про счётчики ----------
let lastFocus = null;
function openDialog() {
  lastFocus = document.activeElement;
  const d = $('clearDialog');
  d.classList.add('open');
  d.setAttribute('aria-hidden', 'false');
  setTimeout(() => $('clearAll').focus(), 50);
}
function closeDialog() {
  const d = $('clearDialog');
  d.classList.remove('open');
  d.setAttribute('aria-hidden', 'true');
  lastFocus?.focus?.();
}

async function clearLog(withCounters) {
  const patch = { log: [] };
  if (withCounters) {
    const { run } = await chrome.storage.local.get('run');
    if (run) patch.run = { ...run, applied: 0, skipped: 0, errors: 0, earlier: 0 };
    // Сигнал скрипту на странице: у него свои копии счётчиков, иначе он вернёт старые значения.
    patch.resetCounters = Date.now();
  }
  closeDialog();
  await chrome.storage.local.set(patch);
}

$('clear').addEventListener('click', openDialog);
$('clearAll').addEventListener('click', () => clearLog(true));
$('clearLogOnly').addEventListener('click', () => clearLog(false));
for (const el of document.querySelectorAll('[data-close]')) el.addEventListener('click', closeDialog);
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && $('clearDialog').classList.contains('open')) {
    e.preventDefault();
    closeDialog();
  }
});

// ---------- проверка страницы ----------
const MARKS = { ok: '✓', warn: '!', fail: '✕' };

function showCheck(items) {
  $('checkList').replaceChildren(...items.map((it, i) => {
    const li = document.createElement('li');
    li.className = `check-item ${it.status}`;
    li.style.setProperty('--i', i);
    const mark = document.createElement('span');
    mark.className = 'check-mark';
    mark.textContent = MARKS[it.status] || '?';
    const body = document.createElement('div');
    const title = document.createElement('div');
    title.className = 'check-title';
    title.textContent = it.title;
    const detail = document.createElement('div');
    detail.className = 'check-detail';
    detail.textContent = it.detail || '';
    body.append(title, detail);
    li.append(mark, body);
    return li;
  }));
  const fails = items.filter((i) => i.status === 'fail').length;
  const warns = items.filter((i) => i.status === 'warn').length;
  const summary = $('checkSummary');
  summary.className = fails ? 'bad' : warns ? '' : 'good';
  summary.textContent = fails
    ? `Найдены проблемы: ${fails}. Без их исправления отклики не пойдут.`
    : warns ? `Работать можно, но есть замечания: ${warns}.` : 'Всё в порядке — расширение видит всё, что нужно.';
}

async function runSelfCheck() {
  $('checkSummary').className = '';
  $('checkSummary').textContent = 'Проверяю…';
  $('checkList').replaceChildren();
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let res = null;
  try {
    res = await chrome.tabs.sendMessage(tab.id, { type: 'selfcheck' });
  } catch {}
  if (!res?.ok) {
    showCheck([{ status: 'fail', title: 'Скрипт на странице', detail: res?.error
      ? `ошибка проверки: ${res.error}`
      : 'не отвечает. Откройте поиск вакансий на hh.ru; если он уже открыт — обновите страницу (F5).' }]);
    return;
  }
  const items = [...res.items];
  if (res.running) {
    // Защиту от выгрузки ставит фоновая часть расширения, на странице её не видно.
    const t = await chrome.tabs.get(tab.id).catch(() => null);
    if (t) items.push(t.autoDiscardable === false
      ? { status: 'ok', title: 'Защита от выгрузки', detail: 'включена — браузер не выгрузит вкладку из памяти' }
      : { status: 'warn', title: 'Защита от выгрузки', detail: 'не включена — перезапустите работу кнопкой «Старт»' });
  }
  showCheck(items);
}

$('selfCheck').addEventListener('click', () => {
  lastFocus = document.activeElement;
  const d = $('checkDialog');
  d.classList.add('open');
  d.setAttribute('aria-hidden', 'false');
  runSelfCheck();
});
$('checkAgain').addEventListener('click', runSelfCheck);
for (const el of document.querySelectorAll('[data-close-check]')) {
  el.addEventListener('click', () => {
    const d = $('checkDialog');
    d.classList.remove('open');
    d.setAttribute('aria-hidden', 'true');
    lastFocus?.focus?.();
  });
}
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && $('checkDialog').classList.contains('open')) {
    e.preventDefault();
    $('checkDialog').classList.remove('open');
    $('checkDialog').setAttribute('aria-hidden', 'true');
  }
});

// ---------- настройки ----------
$('useLetter').addEventListener('change', () => {
  syncLetterState();
  saveSettings();
});
for (const id of ['maxApplications', 'minDelay', 'maxDelay', 'letter', 'polzaKey', 'captchaBreak']) $(id).addEventListener('change', saveSettings);
$('polzaKey').addEventListener('input', syncCaptchaService);
for (const id of ['minDelay', 'maxDelay']) $(id).addEventListener('input', syncPauseSummary);

for (const id of ['bumpResume', 'clearRejections']) {
  $(id).addEventListener('change', () => {
    syncPrestartSummary();
    saveSettings();
  });
}

$('captchaService').addEventListener('change', () => {
  syncCaptchaService();
  saveSettings();
});

// ---------- письма: шаблоны под вакансии ----------
function collectRules() {
  return [...document.querySelectorAll('#rules .rule:not(.removing)')].map((r) => ({
    keywords: r.querySelector('.rule-keys').value,
    text: r.querySelector('.rule-text').value,
  }));
}

function numberRules() {
  const rules = [...document.querySelectorAll('#rules .rule:not(.removing)')];
  rules.forEach((r, i) => (r.querySelector('.rule-num').textContent = i + 1));
}

function makeRule(rule = {}) {
  const el = $('ruleTemplate').content.firstElementChild.cloneNode(true);
  el.querySelector('.rule-keys').value = rule.keywords || '';
  el.querySelector('.rule-text').value = rule.text || '';
  return el;
}

function renderRules(rules) {
  $('rules').replaceChildren(...rules.map((r) => {
    const el = makeRule(r);
    el.classList.add('open');
    return el;
  }));
  numberRules();
}

$('addRule').addEventListener('click', () => {
  const el = makeRule();
  $('rules').append(el);
  numberRules();
  void el.offsetHeight; // сначала закрытое положение, затем — плавное раскрытие
  el.classList.add('open');
  setTimeout(() => el.querySelector('.rule-keys').focus(), 200);
});

function removeRule(el) {
  el.classList.add('removing');
  el.classList.remove('open');
  numberRules();
  saveSettings();
  setTimeout(() => el.remove(), 400); // после анимации сворачивания
}

$('rules').addEventListener('change', saveSettings);

// ---------- письма: вставка и предпросмотр ----------
const editorOf = (el) => el.closest('.letter-editor');
const textareaOf = (editor) => editor.querySelector('textarea');

// Вставка в место курсора; caret — сдвиг курсора от начала вставки (иначе курсор встаёт в конец).
function insertAt(ta, text, caret) {
  if (ta.disabled) return;
  const start = ta.selectionStart;
  ta.setRangeText(text, start, ta.selectionEnd, 'end');
  if (caret != null) ta.setSelectionRange(start + caret, start + caret);
  ta.focus();
  ta.dispatchEvent(new Event('input', { bubbles: true }));
  saveSettings();
}

// Пример письма: для основного — условная вакансия, для шаблона — вакансия с его первым словом.
function sampleItem(editor) {
  const rule = editor.closest('.rule');
  let title = editor.dataset.sample || 'Программист 1С';
  if (rule) {
    const word = HHLetter.keywords({ keywords: rule.querySelector('.rule-keys').value })[0];
    title = word ? word[0].toUpperCase() + word.slice(1) : 'Вакансия';
  }
  return { title, company: 'ООО «Пример»' };
}

const plural = (n, one, few, many) =>
  n % 10 === 1 && n % 100 !== 11 ? one : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? few : many;

function refreshPreview(editor, animate = true) {
  const tpl = textareaOf(editor).value.trim();
  const box = editor.querySelector('.preview-text');
  box.textContent = tpl ? HHLetter.build(tpl, sampleItem(editor)) : 'Здесь появится пример письма — сначала напишите текст.';
  if (animate) {
    box.classList.remove('swap');
    void box.offsetWidth;
    box.classList.add('swap');
  }
  const n = tpl ? HHLetter.countVariants(tpl) : 0;
  editor.querySelector('.preview-count').textContent =
    n > 1 ? `${n > 999999 ? 'больше миллиона' : n.toLocaleString('ru-RU')} ${plural(n, 'вариант', 'варианта', 'вариантов')}` : n === 1 ? 'один вариант текста' : '';
  editor.querySelector('[data-reroll]').hidden = n < 2;
}

function togglePreview(editor) {
  const fold = editor.querySelector('.preview-fold');
  const open = !fold.classList.contains('open');
  if (open) refreshPreview(editor, false);
  fold.classList.toggle('open', open);
  editor.querySelector('[data-preview]').setAttribute('aria-pressed', String(open));
}

// Один обработчик на все кнопки внутри писем (основного и шаблонов).
document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-insert], [data-spin], [data-preview], [data-reroll], [data-remove]');
  if (!btn) return;
  if (btn.matches('[data-remove]')) return removeRule(btn.closest('.rule'));
  const editor = editorOf(btn);
  if (!editor) return;
  const ta = textareaOf(editor);
  if (btn.matches('[data-insert]')) insertAt(ta, btn.dataset.insert);
  else if (btn.matches('[data-spin]')) {
    // Выделенное слово становится первым вариантом: «привет» → {привет|}, курсор — для второго.
    const sel = ta.value.slice(ta.selectionStart, ta.selectionEnd);
    insertAt(ta, `{${sel}|}`, sel.length + 2);
  } else if (btn.matches('[data-preview]')) togglePreview(editor);
  else if (btn.matches('[data-reroll]')) refreshPreview(editor);
});

// Сохраняем и во время набора: окно расширения закрывается щелчком мимо, и «change» может не успеть.
let saveTimer = 0;
document.addEventListener('input', () => {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveSettings, 500);
});

// Открытый пример обновляется по мере набора текста.
let previewTimer = 0;
document.addEventListener('input', (e) => {
  const editor = e.target.closest?.('.letter-editor, .rule');
  if (!editor) return;
  clearTimeout(previewTimer);
  previewTimer = setTimeout(() => {
    for (const ed of (editor.matches('.rule') ? editor : editor.parentElement).querySelectorAll('.letter-editor')) {
      if (ed.querySelector('.preview-fold.open')) refreshPreview(ed);
    }
  }, 350);
});

// Перерыв после капчи от прошлого запуска уже не нужен: иначе он остаётся висеть в статусе.
async function dropStaleBreak() {
  const { active, run } = await chrome.storage.local.get(['active', 'run']);
  if (!active && run?.breakUntil) await chrome.storage.local.set({ run: { ...run, breakUntil: 0 } });
}

// ---------- резюме для анкет (в разработке) ----------
const fmtFileSize = (n) => (n < 1024 ? `${n} Б` : n < 1024 * 1024 ? `${Math.round(n / 1024)} КБ` : `${(n / 1024 / 1024).toFixed(1)} МБ`);
function renderResume(r) {
  const has = !!r?.name;
  $('resumeStatus').textContent = has ? `Загружено: ${r.name} (${fmtFileSize(r.size)})` : 'Файл не загружен.';
  $('resumeSummary').textContent = has ? r.name : '';
  $('resumeRemove').disabled = !has;
}
async function loadResume() {
  const { resume } = await chrome.storage.local.get('resume');
  renderResume(resume);
}
$('resumePick').addEventListener('click', () => $('resumeFile').click());
$('resumeFile').addEventListener('change', async (e) => {
  const file = e.target.files?.[0];
  e.target.value = '';
  if (!file) return;
  if (file.size > 1024 * 1024) {
    $('resumeStatus').textContent = 'Файл больше 1 МБ — сократите резюме.';
    return;
  }
  const text = await file.text();
  const resume = { name: file.name, size: file.size, at: Date.now(), text };
  await chrome.storage.local.set({ resume });
  renderResume(resume);
});
$('resumeRemove').addEventListener('click', async () => {
  await chrome.storage.local.remove('resume');
  renderResume(null);
});

// ---------- выбор резюме по названию вакансии (resume routing, 2.10.0) ----------
const ROUTING_DEFAULTS = { schemaVersion: 1, enabled: false, defaultResumeId: null, matchMode: 'wordStart', rules: [], resumesCache: { updatedAt: null, items: [] } };
let routingCache = { updatedAt: null, items: [] }; // последний загруженный список резюме {id,title,available?}

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const splitTerms = (s) => String(s || '').split(',').map((w) => w.trim()).filter(Boolean);

async function loadRouting() {
  const { resumeRouting } = await chrome.storage.local.get('resumeRouting');
  const r = { ...ROUTING_DEFAULTS, ...(resumeRouting || {}) };
  routingCache = { ...ROUTING_DEFAULTS.resumesCache, ...(r.resumesCache || {}) };
  $('routingEnabled').checked = !!r.enabled;
  renderRoutingRules(r.rules || []);
  syncResumeLists(r.defaultResumeId || '');
  syncResumeCacheNote();
  syncRoutingSummary();
  syncMultiWarn();
}

// <option> для списков резюме. Недоступные (скрытые/удалённые) и «нет в списке» помечаем.
function resumeOptionsHtml(selectedId) {
  const items = routingCache.items || [];
  const opts = [`<option value="">— ${items.length ? 'выберите резюме' : 'обновите список резюме'} —</option>`];
  for (const it of items) {
    const mark = it.available === false ? ' (недоступно)' : '';
    opts.push(`<option value="${esc(it.id)}"${it.id === selectedId ? ' selected' : ''}>${esc(it.title || it.id)}${mark}</option>`);
  }
  if (selectedId && !items.some((i) => i.id === selectedId)) {
    opts.push(`<option value="${esc(selectedId)}" selected>резюме ${esc(selectedId)} (нет в списке)</option>`);
  }
  return opts.join('');
}

// Перезаполнить все списки резюме, сохранив текущий выбор в каждом.
function syncResumeLists(defaultId) {
  const def = defaultId !== undefined ? defaultId : ($('defaultResume').value || '');
  $('defaultResume').innerHTML = resumeOptionsHtml(def);
  for (const sel of document.querySelectorAll('#routingRules .rr-resume')) {
    sel.innerHTML = resumeOptionsHtml(sel.dataset.resumeId || sel.value || '');
  }
}

function makeRoutingRule(rule = {}) {
  const el = $('routingRuleTemplate').content.firstElementChild.cloneNode(true);
  el.dataset.id = rule.id || `rr${Math.random().toString(36).slice(2, 9)}`;
  el.querySelector('.rr-name').value = rule.name || '';
  el.querySelector('.rr-enabled').checked = rule.enabled !== false;
  el.querySelector('.rr-keys').value = (rule.keywords || []).join(', ');
  el.querySelector('.rr-stops').value = (rule.stopWords || []).join(', ');
  const sel = el.querySelector('.rr-resume');
  sel.dataset.resumeId = rule.resumeId || '';
  sel.innerHTML = resumeOptionsHtml(rule.resumeId || '');
  wireRoutingRule(el);
  return el;
}

function renderRoutingRules(rules) {
  $('routingRules').replaceChildren(...rules.map((r) => { const el = makeRoutingRule(r); el.classList.add('open'); return el; }));
  numberRoutingRules();
  validateRoutingRules();
}

function routingRows() {
  return [...document.querySelectorAll('#routingRules .routing-rule:not(.removing)')];
}
function numberRoutingRules() {
  routingRows().forEach((r, i) => (r.querySelector('.rule-num').textContent = i + 1));
}

function collectRoutingRules() {
  return routingRows().map((el) => ({
    id: el.dataset.id,
    name: el.querySelector('.rr-name').value.trim(),
    enabled: el.querySelector('.rr-enabled').checked,
    keywords: splitTerms(el.querySelector('.rr-keys').value),
    stopWords: splitTerms(el.querySelector('.rr-stops').value),
    resumeId: el.querySelector('.rr-resume').value || null,
  }));
}

// Показать ошибки/предупреждения по каждому правилу (раздел 5). Данные не блокируем — модуль подбора
// сам пропускает неполные правила; но пользователю подсвечиваем, что так правило не сработает.
function validateRoutingRules() {
  const prior = [];
  for (const el of routingRows()) {
    const rule = {
      name: el.querySelector('.rr-name').value,
      keywords: splitTerms(el.querySelector('.rr-keys').value),
      stopWords: splitTerms(el.querySelector('.rr-stops').value),
      resumeId: el.querySelector('.rr-resume').value || null,
    };
    const v = HH.routing.validateRule(rule, prior);
    const msg = el.querySelector('.rr-msg');
    const parts = [
      ...v.errors.map((e) => e.msg + (e.words ? `: ${e.words.join(', ')}` : '')),
      ...v.warnings.map((w) => w.msg + (w.words ? `: ${w.words.join(', ')}` : '')),
    ];
    msg.hidden = parts.length === 0;
    msg.textContent = parts.join('\n');
    msg.classList.toggle('err', v.errors.length > 0);
    msg.classList.toggle('warn', v.errors.length === 0 && v.warnings.length > 0);
    prior.push(rule);
  }
}

let routingSaveTimer = null;
function scheduleRoutingSave() {
  clearTimeout(routingSaveTimer);
  routingSaveTimer = setTimeout(saveRoutingNow, 300); // не писать на каждый символ
}
function onRoutingChange() {
  validateRoutingRules();
  syncRoutingSummary();
  scheduleRoutingSave();
}

function wireRoutingRule(el) {
  el.addEventListener('input', onRoutingChange);
  el.querySelector('.rr-enabled').addEventListener('change', onRoutingChange);
  el.querySelector('.rr-resume').addEventListener('change', (e) => { e.target.dataset.resumeId = e.target.value; onRoutingChange(); });
  el.querySelector('[data-remove]').addEventListener('click', () => removeRoutingRule(el));
  const handle = el.querySelector('.drag-handle');
  handle.addEventListener('dragstart', (e) => { dragEl = el; el.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', el.dataset.id); } catch {} });
  handle.addEventListener('dragend', () => clearDrag());
}

function removeRoutingRule(el) {
  el.classList.add('removing');
  el.classList.remove('open');
  numberRoutingRules();
  saveRoutingNow();
  setTimeout(() => el.remove(), 400);
}

async function saveRoutingNow() {
  const prev = (await chrome.storage.local.get('resumeRouting')).resumeRouting || {};
  let enabled = $('routingEnabled').checked;
  const defaultResumeId = $('defaultResume').value || null;
  if (enabled && !defaultResumeId) { enabled = false; $('routingEnabled').checked = false; } // нельзя включить без резюме по умолчанию (ФТ-2)
  await chrome.storage.local.set({
    resumeRouting: {
      ...ROUTING_DEFAULTS, ...prev,
      schemaVersion: 1, matchMode: 'wordStart',
      enabled, defaultResumeId,
      rules: collectRoutingRules(),
      resumesCache: prev.resumesCache || routingCache,
    },
  });
  syncRoutingSummary();
}

// ---- перетаскивание правил ----
let dragEl = null;
function clearDrag() {
  dragEl?.classList.remove('dragging');
  dragEl = null;
  routingRows().forEach((r) => r.classList.remove('drop-before', 'drop-after'));
}
$('routingRules').addEventListener('dragover', (e) => {
  if (!dragEl) return;
  e.preventDefault();
  const over = e.target.closest('.routing-rule');
  routingRows().forEach((r) => r.classList.remove('drop-before', 'drop-after'));
  if (!over || over === dragEl) return;
  const rect = over.getBoundingClientRect();
  over.classList.add(e.clientY > rect.top + rect.height / 2 ? 'drop-after' : 'drop-before');
});
$('routingRules').addEventListener('drop', (e) => {
  if (!dragEl) return;
  e.preventDefault();
  const over = e.target.closest('.routing-rule');
  if (over && over !== dragEl) {
    const rect = over.getBoundingClientRect();
    const after = e.clientY > rect.top + rect.height / 2;
    over.parentNode.insertBefore(dragEl, after ? over.nextSibling : over);
  }
  clearDrag();
  numberRoutingRules();
  validateRoutingRules();
  saveRoutingNow();
});

$('addRoutingRule').addEventListener('click', () => {
  const el = makeRoutingRule({ enabled: true });
  $('routingRules').append(el);
  numberRoutingRules();
  validateRoutingRules();
  syncRoutingSummary();
  void el.offsetHeight;
  el.classList.add('open');
  setTimeout(() => el.querySelector('.rr-name').focus(), 150);
});

$('routingEnabled').addEventListener('change', () => {
  if ($('routingEnabled').checked && !$('defaultResume').value) {
    $('routingEnabled').checked = false;
    $('resumesCacheNote').textContent = 'Сначала выберите резюме по умолчанию (обновите список резюме, если он пуст).';
    return;
  }
  saveRoutingNow();
  syncMultiWarn();
});
$('defaultResume').addEventListener('change', () => { saveRoutingNow(); syncMultiWarn(); });

$('refreshResumes').addEventListener('click', async () => {
  $('resumesCacheNote').textContent = 'Открываю список резюме на hh.ru…';
  try {
    const res = await chrome.runtime.sendMessage({ type: 'openChore', chore: 'resumes', origin: 'https://hh.ru' });
    if (!res?.ok) $('resumesCacheNote').textContent = 'Не удалось открыть список резюме' + (res?.error ? ` (${res.error})` : '') + '.';
    // Результат (resumeRouting.resumesCache) подхватится слушателем storage ниже.
  } catch {
    $('resumesCacheNote').textContent = 'Не удалось открыть список резюме (расширение перезапускается).';
  }
});

$('routingTestBtn').addEventListener('click', () => {
  const title = $('routingTestTitle').value.trim();
  const out = $('routingTestOut');
  if (!title) { out.textContent = 'Введите название вакансии.'; out.className = 'note bad'; return; }
  const routing = { enabled: true, defaultResumeId: $('defaultResume').value || null, matchMode: 'wordStart', rules: collectRoutingRules(), resumesCache: routingCache };
  const p = HH.routing.chooseResume(title, routing);
  const titleOf = (id) => (routingCache.items || []).find((i) => i.id === id)?.title || (id ? `резюме ${id}` : '');
  if (p.skip) { out.textContent = 'Отклик был бы пропущен: нет доступного резюме.'; out.className = 'note bad'; return; }
  const warn = p.warning === 'rule_resume_unavailable' ? ' (резюме правила недоступно — взято по умолчанию)' : '';
  out.textContent = `Правило: ${p.ruleName || 'По умолчанию'} → резюме: ${titleOf(p.resumeId)}${warn}`;
  out.className = 'note ok';
});

function syncResumeCacheNote() {
  const items = routingCache.items || [];
  const when = routingCache.updatedAt
    ? new Date(routingCache.updatedAt).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })
    : null;
  $('resumesCacheNote').textContent = items.length
    ? `Загружено резюме: ${items.length}${when ? `, обновлено ${when}` : ''}.`
    : 'Список резюме ещё не загружен. Нажмите «Обновить список резюме» — hh.ru откроется в соседней вкладке.';
}
function syncRoutingSummary() {
  $('routingSummary').textContent = $('routingEnabled').checked ? `вкл · правил: ${routingRows().length}` : '';
}
function syncMultiWarn() {
  const multi = (routingCache.items || []).length > 1;
  $('routingMultiWarn').hidden = !(multi && !$('routingEnabled').checked);
}

// Список резюме обновился в фоновой вкладке — перезаполнить выпадающие списки, не трогая правила.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes.resumeRouting) return;
  const r = changes.resumeRouting.newValue || {};
  routingCache = { ...ROUTING_DEFAULTS.resumesCache, ...(r.resumesCache || {}) };
  syncResumeLists(undefined);
  syncResumeCacheNote();
  syncMultiWarn();
});

$('ver').textContent = `версия ${chrome.runtime.getManifest().version}`;
initSections();
initSettingHelp();

chrome.storage.onChanged.addListener(render);
// Фоновая часть создаёт ID при первом запуске и сверяет ключ с файлом, если давно не сверяла.
chrome.runtime.sendMessage({ type: 'licenseInit' }).catch(() => {});
dropStaleBreak();
Promise.all([loadSettings(), loadRouting(), render(), loadResume()]).finally(() => {
  // Блоки уже в нужном положении — дальше раскрываются плавно.
  setTimeout(() => document.body.classList.remove('preload'), 60);
});

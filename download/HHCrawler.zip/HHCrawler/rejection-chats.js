// Only list-row statuses select chats. Confirmation counts are UI actions, not proven removals.
(globalThis.HH ||= {}).makeRejectionChats = ({ sleep, waitFor, humanClick, isActive = () => true,
  save = async () => {}, onProgress = () => {}, log = async () => {} }) => {
  const { CHATS, visible, isDisabled } = HH.dom;
  const normalize = value => String(value || '').replace(/\s+/g, ' ').trim();
  const WARNING = 'Вы перестанете получать новые сообщения, если покинете чат';
  const uniqueVisible = (selector, root = document) => {
    const found = [...root.querySelectorAll(selector)].filter(visible);
    return found.length === 1 ? found[0] : null;
  };
  const rows = () => [...document.querySelectorAll(CHATS.row)].filter(visible).flatMap(row => {
    const id = /^chat-cell-(\d+)$/.exec(row.id)?.[1];
    return id ? [{ id, row, status: normalize(row.querySelector(CHATS.status)?.textContent) }] : [];
  });
  const find = id => {
    const found = rows().filter(item => item.id === id);
    return found.length === 1 ? found[0] : null;
  };

  function selected(target) {
    const current = find(target.id)?.row;
    if (!current) return false;
    for (const element of [current, current.parentElement]) {
      if (!element || (element !== current && element.querySelectorAll(CHATS.row).length !== 1)) continue;
      if (element.getAttribute('aria-selected') === 'true' || ['true', 'page'].includes(element.getAttribute('aria-current'))) return true;
    }
    // Derive the route and its ID parameter from this row; never hardcode a company or chat ID.
    try {
      const expected = new URL(current.getAttribute('href'), location.href), actual = new URL(location.href);
      if (expected.origin !== actual.origin || !/^\/chat(?:\/|$)/.test(expected.pathname)) return false;
      for (const [name, value] of expected.searchParams) {
        if (value === target.id && actual.pathname === expected.pathname && actual.searchParams.get(name) === value) return true;
      }
      if (expected.pathname.split('/').includes(target.id) && expected.pathname === actual.pathname) return true;
      if (expected.hash.split(/[/?=&]/).includes(target.id) && expected.hash === actual.hash && expected.pathname === actual.pathname) return true;
    } catch (_) { /* No trustworthy route identity. */ }
    return false;
  }

  function scrollContainer(row) {
    for (let element = row.parentElement; element && element !== document.body; element = element.parentElement) {
      if (/auto|scroll/.test(getComputedStyle(element).overflowY) && element.scrollHeight > element.clientHeight + 1) return element;
    }
    return null;
  }

  const eligible = target => find(target.id)?.status === 'Отказ' && selected(target);
  function confirmation() {
    const marker = uniqueVisible(CHATS.alert);
    const dialog = marker?.closest('[role="alertdialog"][aria-modal="true"]');
    if (!dialog || !visible(dialog)) return null;
    const warnings = [...dialog.querySelectorAll(CHATS.warning)];
    if (!warnings.some(node => normalize(node.textContent).replace(/[.!]$/, '') === WARNING)) return null;
    const button = uniqueVisible(CHATS.confirm, dialog);
    return button && !isDisabled(button) ? { dialog, button } : null;
  }

  // Recheck at the actual click, after humanClick's delays: the user/site can change selection meanwhile.
  async function guardedClick(resolveButton, condition) {
    const dynamic = typeof resolveButton === 'function';
    for (let attempt = 0; attempt < 3; attempt++) {
      const button = dynamic ? resolveButton() : resolveButton;
      if (!button || !visible(button) || isDisabled(button)) throw new Error('кнопка недоступна');
      let clicked = false, blocked = false, stale = false;
      const guard = event => {
        if (event.target !== button && !button.contains(event.target)) return;
        stale = !button.isConnected;
        if (!isActive() || stale || !condition()) {
          event.preventDefault(); event.stopImmediatePropagation(); blocked = true;
        } else clicked = true;
      };
      // The node itself still receives this guard if virtualization detaches it before click().
      button.addEventListener('click', guard, true);
      try { await humanClick(button); }
      finally { button.removeEventListener('click', guard, true); }
      if (clicked && !blocked) return;
      if (dynamic && stale && isActive() && condition()) { await sleep(100); continue; }
      throw new Error(isActive() ? 'чат или подтверждение изменились — очистка остановлена' : 'stopped');
    }
    throw new Error('строка чата постоянно меняется — очистка остановлена');
  }

  const alerts = () => [...document.querySelectorAll('[role="alert"]')].filter(visible).map(node => normalize(node.textContent));

  async function run(initial = {}) {
    const state = { total: 0, attempted: [], startedAt: Date.now(), ...initial };
    const attempted = new Set(state.attempted), discovered = new Set();
    const publish = async () => {
      state.attempted = [...attempted];
      await save(state);
      onProgress(state.total, discovered.size, state.startedAt);
    };
    if (state.pending) {
      await log(`Чат #${state.pending}: предыдущая попытка прервалась; автоматический повтор пропущен`, 'info');
      attempted.add(state.pending); state.pending = null;
    }
    await publish();
    if (!/^\/chat(?:\/|$)/.test(location.pathname)) throw new Error('открыта не страница чатов hh.ru');
    if (!await waitFor(() => rows().length, 15000)) return { ...state, loaded: false };
    let scroller = scrollContainer(rows()[0].row);
    if (scroller) { scroller.scrollTop = 0; scroller.dispatchEvent(new Event('scroll', { bubbles: true })); await sleep(600); }
    let bottomStable = 0;

    for (let step = 0; step < 5000; step++) {
      await sleep(100);
      const currentRows = rows();
      for (const item of currentRows) discovered.add(item.id);
      onProgress(state.total, discovered.size, state.startedAt);
      const target = currentRows.find(item => item.status === 'Отказ' && !attempted.has(item.id));
      if (target) {
        bottomStable = 0;
        target.row.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'instant' });
        await sleep(300);
        const freshRow = find(target.id);
        if (!freshRow || freshRow.status !== 'Отказ') continue;
        await guardedClick(() => find(target.id)?.row, () => find(target.id)?.status === 'Отказ');
        const menu = await waitFor(() => selected(target) && uniqueVisible(CHATS.menu), 12000);
        if (!menu) throw new Error(`не удалось подтвердить выбор чата #${target.id}`);
        await sleep(500);
        await guardedClick(() => uniqueVisible(CHATS.menu), () => eligible(target));
        const leave = await waitFor(() => uniqueVisible(CHATS.leave), 6000);
        if (!leave) throw new Error('пункт «Покинуть чат» не найден');
        await guardedClick(() => uniqueVisible(CHATS.leave), () => eligible(target));
        const confirm = await waitFor(confirmation, 6000);
        if (!confirm) throw new Error('не найдено ожидаемое окно подтверждения выхода');
        if (!eligible(target)) throw new Error(`статус или выбор чата #${target.id} изменился`);
        const priorAlerts = new Set(alerts());
        // Durable checkpoint before the irreversible click prevents a duplicate after a reload.
        attempted.add(target.id); state.pending = target.id;
        await publish();
        await guardedClick(confirm.button, () => {
          const fresh = confirmation();
          return eligible(target) && fresh?.button === confirm.button && fresh.dialog === confirm.dialog;
        });
        state.total++;
        await publish();
        const closed = await waitFor(() => !confirm.dialog.isConnected || !visible(confirm.dialog), 12000);
        if (!closed) throw new Error(`hh.ru не закрыл подтверждение для чата #${target.id}; повторять не буду`);
        await sleep(800);
        const error = alerts().find(value => !priorAlerts.has(value) && /ошибк|не удалось|попробуйте|недоступ/i.test(value));
        if (error) throw new Error('hh.ru сообщил об ошибке после подтверждения выхода');
        state.pending = null;
        await publish();
        await log(`Чат #${target.id}: нажато подтверждение «Покинуть чат»`, 'info');
        // The final HH success signal is not known yet. Row disappearance alone is never called success.
        continue;
      }

      scroller = currentRows[0] ? scrollContainer(currentRows[0].row) : scroller;
      if (!scroller || !scroller.isConnected) return { ...state, loaded: true, visited: discovered.size };
      const before = { top: scroller.scrollTop, height: scroller.scrollHeight, ids: currentRows.map(item => item.id).join(',') };
      scroller.scrollTop = Math.min(scroller.scrollHeight - scroller.clientHeight, scroller.scrollTop + Math.max(80, scroller.clientHeight * 0.75));
      scroller.dispatchEvent(new Event('scroll', { bubbles: true }));
      await sleep(1000);
      const nextIds = rows().map(item => item.id).join(',');
      const atBottom = scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 2;
      if (atBottom && Math.abs(scroller.scrollTop - before.top) < 2 && scroller.scrollHeight === before.height && nextIds === before.ids) bottomStable++;
      else bottomStable = 0;
      if (bottomStable >= 3) return { ...state, loaded: true, visited: discovered.size };
    }
    throw new Error('достигнут предел прокрутки списка; очистка остановлена');
  }

  return { run };
};

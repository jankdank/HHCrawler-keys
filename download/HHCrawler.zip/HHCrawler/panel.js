// Плавающая панель в углу страницы hh.ru: состояние, счётчики, кнопка «Остановить».
// Только отображение — данные и обработчик остановки передаёт content.js.
(globalThis.HH ||= {}).panel = (() => {
  let root = null;
  let onStop = null;
  let collapsed = false;
  const COLLAPSED_KEY = 'panelCollapsed';

  const STYLE = `
    .box{
      --bg:#fff;--text:#1b1f2a;--muted:#6b7385;--border:#e4e7ef;--soft:#f1f3f8;
      --ok:#16a34a;--warn:#b45309;--err:#dc2626;--err-bg:#fdecec;--accent:#4f46e5;--accent-2:#7c3aed;
      --ease:cubic-bezier(.2,.8,.2,1);
      box-sizing:border-box;width:292px;max-width:calc(100vw - 32px);padding:12px 14px;border-radius:16px;max-height:calc(100vh - 32px);overflow:auto;
      font:13px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:var(--text);
      background:var(--bg);border:1px solid var(--border);
      box-shadow:0 18px 40px -12px rgba(16,24,40,.28),0 2px 6px rgba(16,24,40,.06);
      animation:in .5s var(--ease) both;
    }
    @media (prefers-color-scheme: dark){
      .box{--bg:#171a22;--text:#e8eaf0;--muted:#9aa3b5;--border:#2a2f3b;--soft:#1f232d;
           --ok:#4ade80;--warn:#fbbf24;--err:#f87171;--err-bg:rgba(248,113,113,.14);--accent:#818cf8;--accent-2:#a78bfa;
           box-shadow:0 18px 40px -12px rgba(0,0,0,.6)}
    }
    @keyframes in{from{opacity:0;transform:translateY(14px) scale(.98)}to{opacity:1;transform:none}}
    .h{display:flex;align-items:center;gap:8px;font-weight:700}
    .logo{display:grid;place-items:center;width:24px;height:24px;border-radius:7px;
          background:linear-gradient(135deg,#ff5160,#d0021b);box-shadow:0 4px 10px -4px rgba(208,2,27,.6)}
    .logo svg{width:15px;height:15px}
    .title{flex:1;min-width:0;white-space:nowrap}
    .box[data-collapsed="true"]{width:240px}
    .details[hidden]{display:none}
    .collapse{display:grid;place-items:center;flex:none;width:26px;height:26px;padding:0;
      border:0;border-radius:7px;background:var(--soft);color:var(--muted);cursor:pointer}
    .collapse:hover{color:var(--text)}
    .collapse:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
    .collapse svg{width:16px;height:16px;transform:rotate(180deg)}
    .box[data-collapsed="true"] .collapse svg{transform:none}
    .dot{--c:var(--muted);width:8px;height:8px;border-radius:50%;background:var(--c);transition:background-color .3s}
    .box[data-state="run"] .dot{--c:var(--ok);animation:pulse 1.8s ease-out infinite}
    .box[data-state="wait"] .dot{--c:var(--warn);animation:pulse 2.6s ease-out infinite}
    .box[data-state="alert"] .dot{--c:var(--err)}
    @keyframes pulse{0%{box-shadow:0 0 0 0 color-mix(in srgb,var(--c) 55%,transparent)}
                     70%{box-shadow:0 0 0 7px transparent}100%{box-shadow:0 0 0 0 transparent}}
    .n{display:grid;grid-template-columns:repeat(4,1fr);gap:5px;margin:10px 0 8px}
    .n div{display:flex;flex-direction:column;min-width:0;padding:6px 7px;border-radius:10px;background:var(--soft)}
    .n b{font-size:17px;line-height:1.15;font-variant-numeric:tabular-nums;display:inline-block;transform-origin:left center}
    .n span{font-size:10px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .n .ok b{color:var(--ok)} .n .skip b{color:var(--warn)} .n .err b{color:var(--err)} .n .old b{color:var(--muted)}
    .n b.bump{animation:bump .5s var(--ease)}
    @keyframes bump{0%{transform:scale(1)}35%{transform:scale(1.2)}100%{transform:scale(1)}}
    .progress-stack{display:flex;flex-direction:column;gap:10px;margin:10px 0 8px}
    .progress-stack[hidden]{display:none}
    .prog{margin:0}
    .chat-details{margin-top:3px;font-size:10px;color:var(--muted)}
    .chat-details[hidden]{display:none}
    .prog[hidden]{display:none}
    .lbl{font-size:10.5px;color:var(--muted);margin:0 0 4px}
    .lbl:empty{display:none}
    .n[hidden]{display:none}
    .n[hidden] + .progress-stack{margin-top:12px}  /* без блока счётчиков полоска иначе прилипает к шапке с логотипом */
    .bar.ind i{width:35%!important;animation:ind 1.4s ease-in-out infinite}
    @keyframes ind{0%{margin-left:-35%}100%{margin-left:100%}}
    .bar{height:6px;border-radius:3px;background:var(--soft);overflow:hidden}
    .bar i{display:block;height:100%;width:0;border-radius:3px;background:linear-gradient(90deg,var(--accent),var(--accent-2));transition:width .6s var(--ease)}
    .pt{display:flex;justify-content:space-between;gap:8px;margin-top:5px;font-size:11.5px;color:var(--muted)}
    .pt b{color:var(--text);font-variant-numeric:tabular-nums}
    .lim{margin:0 0 8px;padding:6px 9px;border-radius:10px;background:var(--err-bg);color:var(--err);font-weight:600;font-size:12px}
    .lim:empty{display:none}
    .st{color:var(--muted);overflow-wrap:anywhere;transition:color .3s}
    .box:not([data-state="idle"]) .st{color:var(--text)}
    .box[data-state="alert"] .st{color:var(--err);font-weight:600}
    .stop{display:flex;align-items:center;justify-content:center;gap:6px;width:100%;height:34px;margin-top:10px;
          font:inherit;font-weight:650;border:0;border-radius:10px;cursor:pointer;color:#fff;background:#dc2626;
          transition:transform .15s var(--ease),filter .2s}
    .stop:hover{filter:brightness(1.06)}
    .stop:active{transform:scale(.97)}
    .stop[hidden]{display:none}
    @media (prefers-reduced-motion: reduce){*{animation-duration:1ms!important;animation-iteration-count:1!important;transition-duration:1ms!important}}`;

  const HTML = `
    <div class="box" data-state="idle">
      <div class="h">
        <span class="logo"><svg viewBox="0 0 24 24"><path d="M22 2 2 9l9 4z" fill="#fff"/><path d="M22 2 11 13l4 9z" fill="#ffd9dd"/></svg></span>
        <span class="title">HH Автоотклик</span>
        <span class="dot"></span>
        <button type="button" class="collapse" aria-expanded="true" aria-controls="hh-progress-details" aria-label="Свернуть панель прогресса" title="Свернуть панель прогресса"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg></button>
      </div>
      <div class="details" id="hh-progress-details">
      <div class="n">
        <div class="ok"><b data-k="applied">0</b><span>отклики</span></div>
        <div class="skip"><b data-k="skipped">0</b><span>пропуски</span></div>
        <div class="err"><b data-k="errors">0</b><span>ошибки</span></div>
        <div class="old" title="Уже обработаны раньше: «Вы откликнулись», «Вам отказали», «Вы отказались»"><b data-k="earlier">0</b><span>ранее</span></div>
      </div>
      <div class="progress-stack" hidden>
        <div class="prog apply" hidden><div class="lbl"></div><div class="bar"><i></i></div><div class="pt"><span class="pp"></span><span class="eta"></span></div></div>
        <div class="prog bump" hidden><div class="lbl">Поднятие резюме</div><div class="bar"><i></i></div><div class="pt"><span class="pp"></span><span class="eta"></span></div></div>
        <div class="prog chore" hidden><div class="lbl">Удаление отказов</div><div class="bar"><i></i></div><div class="pt"><span class="pp"></span><span class="eta"></span></div></div>
        <div class="prog chats" hidden><div class="lbl">Удаление чатов с отказами</div><div class="bar" role="progressbar" aria-label="Удаление чатов с отказами" aria-valuemin="0" aria-valuemax="100"><i></i></div><div class="pt"><span class="pp"></span><span class="eta"></span></div><div class="chat-details" hidden></div></div>
      </div>
      <div class="lim"></div>
      <div class="st"></div>
      <button class="stop">Остановить</button>
      </div>
    </div>`;

  function syncCollapsed(r) {
    r.querySelector('.box').dataset.collapsed = String(collapsed);
    r.querySelector('.details').hidden = collapsed;
    const button = r.querySelector('.collapse');
    const label = collapsed ? 'Развернуть панель прогресса' : 'Свернуть панель прогресса';
    button.setAttribute('aria-expanded', String(!collapsed));
    button.setAttribute('aria-label', label);
    button.title = label;
  }

  function ensure() {
    if (root?.host.isConnected) return root;
    const host = document.createElement('div');
    host.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647;';
    root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>${STYLE}</style>${HTML}`;
    root.querySelector('.stop').addEventListener('click', () => onStop?.());
    const current = root;
    let clicked = false;
    syncCollapsed(current);
    current.querySelector('.collapse').addEventListener('click', () => {
      clicked = true;
      collapsed = !collapsed;
      syncCollapsed(current);
      try { globalThis.chrome?.storage?.local?.set({ [COLLAPSED_KEY]: collapsed })?.catch(() => {}); }
      catch (_) { /* Folding remains usable if the extension context was invalidated. */ }
    });
    try {
      globalThis.chrome?.storage?.local?.get(COLLAPSED_KEY)?.then(saved => {
        if (!clicked && current.host.isConnected && typeof saved[COLLAPSED_KEY] === 'boolean') {
          collapsed = saved[COLLAPSED_KEY];
          syncCollapsed(current);
        }
      }).catch(() => {});
    } catch (_) { /* Start expanded when extension storage is unavailable. */ }
    document.documentElement.appendChild(host);
    return root;
  }

  // «3 ч 10 мин», «25 мин», «меньше минуты».
  function fmtDuration(ms) {
    const min = Math.round(ms / 60000);
    if (min < 1) return 'меньше минуты';
    if (min < 60) return `${min} мин`;
    return `${Math.floor(min / 60)} ч${min % 60 ? ` ${min % 60} мин` : ''}`;
  }

  // При заданной цели считаем только успешные отклики, иначе — прогресс по выдаче.
  function renderProgress(r, run, active) {
    const box = r.querySelector('.prog.apply');
    const pr = run.progress;
    if (run.successLimit > 0) {
      const done = Math.max(0, Math.min(run.successLimit, run.successCount ?? run.applied ?? 0));
      const pct = Math.floor(done / run.successLimit * 100);
      const startedAt = pr?.startedAt || run.startedAt;
      box.hidden = false; // Итог остаётся виден после достижения цели или ранней остановки.
      box.querySelector('.bar').classList.remove('ind');
      box.querySelector('.lbl').textContent = 'Успешные отклики';
      box.querySelector('.bar i').style.width = `${pct}%`;
      box.querySelector('.pp').innerHTML = `<b>${pct}%</b> · ${done} из ${run.successLimit}`;
      box.querySelector('.eta').textContent = done >= run.successLimit ? 'цель достигнута'
        : !active ? 'запуск завершён'
        : done < 3 || !startedAt ? 'считаю время…'
        : `осталось ≈ ${fmtDuration(((Date.now() - startedAt) / done) * (run.successLimit - done))}`;
      return;
    }
    box.hidden = !active || !pr?.total;
    if (box.hidden) return;
    box.querySelector('.lbl').textContent = 'Отклики на вакансии';
    const pct = Math.min(100, Math.floor((pr.pos / pr.total) * 100));
    box.querySelector('.bar i').style.width = `${pct}%`;
    box.querySelector('.pp').innerHTML = `<b>${pct}%</b> · ${pr.pos} из ${pr.total}`;
    const passed = pr.pos - pr.startPos;
    const eta = box.querySelector('.eta');
    if (pr.pos >= pr.total) eta.textContent = 'последние вакансии';
    else if (passed < 3) eta.textContent = 'считаю время…'; // пока мало данных о темпе
    else eta.textContent = `осталось ≈ ${fmtDuration(((Date.now() - pr.startedAt) / passed) * (pr.total - pr.pos))}`;
  }

  // Общая полоска вкладки-помощника на основной странице и во всех вкладках-помощниках.
  // box — элемент полоски; c: запись chore_* из хранилища { state, total (сделано), expected (0 — неизвестно), startedAt }.
  // verb — слово для случая без процента («удалено», «поднято»); eta=false — без оценки времени (быстрые задачи).
  function renderMirror(box, c, verb, showEta = true) {
    box.hidden = c?.state !== 'running';
    if (box.hidden) return;
    const done = c.total || 0;
    const expected = c.expected || 0;
    const bar = box.querySelector('.bar');
    const pp = box.querySelector('.pp');
    const eta = box.querySelector('.eta');
    if (!expected) {
      // Сколько всего — неизвестно: процент считать не от чего, показываем сделанное число.
      bar.classList.add('ind');
      pp.innerHTML = `${verb} <b>${done}</b>`;
      eta.textContent = '';
      return;
    }
    bar.classList.remove('ind');
    const pct = Math.min(100, Math.floor((done / expected) * 100));
    box.querySelector('.bar i').style.width = `${pct}%`;
    pp.innerHTML = `<b>${pct}%</b> · ${done} из ${expected}`;
    if (!showEta) eta.textContent = '';
    else if (done >= expected) eta.textContent = 'заканчиваю';
    else if (c.startedAt && done >= 5) eta.textContent = `осталось ≈ ${fmtDuration(((Date.now() - c.startedAt) / done) * (expected - done))}`;
    else eta.textContent = done < 5 ? 'считаю время…' : '';
  }

  // Процент относится к обработке плана; фактические нажатия подтверждения считаются отдельно.
  function renderChats(box, c) {
    renderMirror(box, c && { ...c, state: c.state === 'paused' ? 'running' : c.state, total: c.processed ?? c.total, startedAt: c.processingStartedAt || c.startedAt }, 'подтверждений');
    if (box.hidden) return;
    const bar = box.querySelector('.bar'), pp = box.querySelector('.pp'), eta = box.querySelector('.eta');
    const details = box.querySelector('.chat-details');
    details.hidden = !c.phase;
    if (c.phase === 'scan') {
      bar.removeAttribute('aria-valuenow');
      pp.textContent = `Подсчёт: найдено ${c.found || 0}`;
      eta.textContent = `просмотрено ${c.scanned || 0}`;
      details.hidden = true;
      bar.setAttribute('aria-valuetext', `Подсчёт чатов с отказами: найдено ${c.found || 0}`);
    } else if (c.expected > 0) {
      const done = Math.max(0, Math.min(c.expected, c.processed ?? c.total ?? 0));
      const pct = Math.floor(done / c.expected * 100);
      pp.innerHTML = `<b>${pct}%</b> · ${done} из ${c.expected}`;
      details.textContent = `Подтверждений выхода: ${c.total || 0}` + (c.skipped ? ` · пропущено: ${c.skipped}` : '');
      bar.setAttribute('aria-valuenow', String(pct));
      bar.setAttribute('aria-valuetext', `Обработано ${done} из ${c.expected}; подтверждений выхода: ${c.total || 0}`);
      if (c.phase === 'done') eta.textContent = 'завершено';
    } else {
      bar.removeAttribute('aria-valuenow');
      bar.setAttribute('aria-valuetext', `Подтверждений выхода: ${c.total || 0}`);
      if (c.phase === 'done') { pp.textContent = 'Чатов с отказами нет'; eta.textContent = ''; details.hidden = true; }
      else eta.textContent = c.scanned ? `просмотрено ${c.scanned}` : 'подсчёт чатов…';
    }
    if (c.state === 'paused') {
      bar.classList.remove('ind');
      if (!c.expected) box.querySelector('.bar i').style.width = '0%';
      eta.textContent = 'Приостановлено — перезагрузите вкладку чатов для продолжения';
      bar.setAttribute('aria-valuetext', 'Очистка чатов приостановлена');
    }
  }

  // Полоска поднятия резюме. Заполняется ПЛАВНО по времени (каждую секунду), а не скачками
  // по одному резюме: внутри «слота» одного резюме бар растёт по оценке времени (perMs) и у границы
  // слота притормаживает; когда резюме реально поднято — переходит к следующему слоту (slotAt — его начало).
  // c: { state, total (поднято), expected (сколько резюме), slotAt, perMs }.
  function renderBumpMirror(box, c) {
    box.hidden = c?.state !== 'running';
    if (box.hidden) return;
    const bar = box.querySelector('.bar');
    const pp = box.querySelector('.pp');
    const eta = box.querySelector('.eta');
    const expected = c.expected || 0;
    if (!expected) {
      // Сколько резюме — ещё неизвестно: бегущая полоска без процента.
      bar.classList.add('ind');
      pp.textContent = 'поднимаю резюме';
      eta.textContent = '';
      return;
    }
    bar.classList.remove('ind');
    const done = c.total || 0;
    const slotW = 100 / expected;                 // доля одного резюме в полоске
    const base = (done / expected) * 100;          // уже поднятые резюме
    const fill = (c.slotAt && c.perMs)             // плавное заполнение текущего слота по времени
      ? Math.min(0.95, Math.max(0, (Date.now() - c.slotAt) / c.perMs)) * slotW
      : 0;
    const pct = Math.min(99, Math.floor(base + fill));
    bar.querySelector('i').style.width = `${pct}%`;
    pp.innerHTML = `<b>${pct}%</b>`;
    eta.textContent = `резюме ${done} из ${expected}`;
  }

  // Строка статуса, когда отклики не идут, а помощник в соседней вкладке ещё работает.
  function choreStatus(chore, bump, chats) {
    const parts = [];
    if (bump?.state === 'running') parts.push('поднятие резюме');
    if (chore?.state === 'running') parts.push('удаление отказов');
    if (chats?.state === 'running') parts.push('очистка чатов');
    return parts.length ? `Идёт ${parts.join(' и ')} в отдельной вкладке` : '';
  }

  const stateOf = (run, active) =>
    !active ? 'idle' : /^(Следующее действие|Перерыв)/.test(run.status || '') ? 'wait' : 'run';

  function render({ run, active, limitText = '', chore = null, bump = null, chats = null }) {
    const choreRunning = chore?.state === 'running' || bump?.state === 'running' || chats?.state === 'running';
    const chatsPaused = chats?.state === 'paused';
    const hasHelper = choreRunning || chatsPaused;
    if (!run && !hasHelper && !root?.host.isConnected) return;
    active = !!run && active;
    const r = ensure();
    r.querySelector('.title').textContent = 'HH Автоотклик';
    r.querySelector('.n').hidden = !run;
    for (const k of ['applied', 'skipped', 'errors', 'earlier']) {
      const el = r.querySelector(`[data-k="${k}"]`);
      const value = String(run?.[k] ?? 0);
      if (el.textContent === value) continue;
      el.textContent = value;
      el.classList.remove('bump');
      void el.offsetWidth; // перезапуск анимации
      el.classList.add('bump');
    }
    // Помощник (удаление отказов / поднятие резюме) работает параллельно и может продолжаться,
    // когда отклики уже закончились: тогда панель остаётся «живой» и кнопка «Остановить» видна.
    r.querySelector('.box').dataset.state = active ? stateOf(run, active) : (choreRunning ? 'run' : chatsPaused ? 'wait' : 'idle');
    if (run) renderProgress(r, run, active);
    else r.querySelector('.prog.apply').hidden = true;
    renderMirror(r.querySelector('.prog.chore'), chore, 'удалено');
    renderChats(r.querySelector('.prog.chats'), chats);
    renderBumpMirror(r.querySelector('.prog.bump'), bump);
    r.querySelector('.progress-stack').hidden = ![...r.querySelectorAll('.prog')].some(box => !box.hidden);
    r.querySelector('.lim').textContent = limitText;
    r.querySelector('.st').textContent = active ? run.status
      : chatsPaused ? 'Очистка чатов приостановлена. Перезагрузите вкладку чатов для продолжения.'
      : choreRunning ? choreStatus(chore, bump, chats)
      : `Не запущено. ${run?.status || ''}`;
    r.querySelector('.stop').hidden = !active && !hasHelper;
  }

  // Красная строка вместо статуса — когда дальше без человека нельзя (например, расширение обновили).
  function alert(message) {
    const r = ensure();
    r.querySelector('.box').dataset.state = 'alert';
    r.querySelector('.st').textContent = message;
    r.querySelector('.stop').hidden = true;
  }

  return { render, alert, setOnStop: (fn) => (onStop = fn) };
})();

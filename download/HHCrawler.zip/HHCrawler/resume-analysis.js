/* Shared helpers for the popup and the HTML report. No provider credentials. */
globalThis.HHResume = (() => {
  const MAX_CHARS = 40000;
  const PREFIX = 'resumeAnalysis:';
  const validId = id => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id || '');
  const key = id => PREFIX + id;
  const errors = {
    bad_resume: 'В файле слишком мало текста для анализа. Загрузите полное резюме (не менее 80 символов).',
    too_large: 'Для анализа нужно резюме не длиннее 40 000 символов. Сократите файл и загрузите его заново.',
    no_license: 'Для анализа нужна действующая лицензия. Проверьте её в окне расширения.',
    not_configured: 'Анализ резюме пока не подключён на сервере. Повторите позже.',
    model_not_available: 'Модель DeepSeek Flash сейчас недоступна для анализа. Повторите позже.',
    limit: 'Достигнут лимит запусков анализа за 24 часа. Попробуйте позже; готовые отчёты можно читать без ограничений.',
    already_running: 'Другое ваше резюме уже анализируется. Дождитесь его отчёта.',
    busy: 'Сервис анализа занят. Повторите позже.',
    provider_unavailable: 'Сервис ИИ не ответил. Попробуйте позже.',
    network: 'Нет связи с сервером анализа. Проверьте соединение и нажмите «Продолжить».',
    waiting: 'Анализ ещё не завершён. Нажмите «Продолжить», чтобы проверить результат.',
    unknown_job: 'Срок хранения запроса на сервере истёк. Запустите новый анализ из окна расширения.',
    job_expired: 'Запрос больше не хранится на сервере. Запустите новый анализ из окна расширения.',
    missing_report: 'Отчёт не найден на этом устройстве. Запустите анализ из окна расширения.',
    request_conflict: 'Текст этого запроса изменился. Запустите новый анализ из окна расширения.',
    interrupted: 'Анализ был прерван перезапуском сервера. Запустите новый анализ из окна расширения.',
    bad_response: 'Сервис ИИ вернул неполный ответ. Попробуйте позже.',
    incomplete_report: 'ИИ достиг лимита длины ответа и не завершил отчёт. Это ограничение генерации, а не размера файла резюме. Сообщите код ошибки администратору.',
    unsupported_format: 'Загрузите резюме в PDF с текстом. DOC и другие форматы сначала сохраните в PDF.',
    file_too_large: 'Файл больше 5 МБ. Сократите резюме и загрузите заново.',
    bad_file: 'Файл повреждён или не соответствует формату. Сохраните его заново в поддерживаемом формате.',
    no_text: 'В PDF нет доступного текста. Выполните распознавание скана и загрузите текстовый PDF или TXT.',
    extractor_not_configured: 'На сервере не установлен обработчик PDF/DOC. Сообщите администратору.',
    extraction_timeout: 'Не удалось прочитать файл за отведённое время. Сохраните его в TXT и повторите.',
    bad_questions: 'Не удалось прочитать анкету. Заполните её вручную.',
    bad_upload: 'Передача файла прервалась или истекло время загрузки. Выберите файл заново.',
  };
  function message(reason) {
    const known = typeof reason === 'string' && Object.hasOwn(errors, reason);
    const text = known ? errors[reason] : 'Не удалось выполнить анализ. Попробуйте позже.';
    return text + '\nКод ошибки: ' + (known ? reason : 'unknown_error');
  }

  function validate(resume) {
    if (typeof resume?.text !== 'string' || Array.from(resume.text.trim()).length < 80) throw new Error('bad_resume');
    // Count Unicode code points, matching Python's len() on the server.
    if (Array.from(resume.text).length > MAX_CHARS) throw new Error('too_large');
  }

  async function create(resume) {
    validate(resume);
    const id = crypto.randomUUID();
    const job = { id, name: String(resume.name || 'Резюме'), text: resume.text, createdAt: Date.now(), status: 'new' };
    const all = await chrome.storage.local.get(null);
    const older = Object.entries(all).filter(([k, value]) => k.startsWith(PREFIX) && value?.createdAt)
      .sort((a, b) => b[1].createdAt - a[1].createdAt).slice(9)
      .filter(([, value]) => value.status === 'done' || value.status === 'error' || Date.now() - value.createdAt > 86400000)
      .map(([k]) => k);
    await chrome.storage.local.set({ [key(id)]: job });
    if (older.length) await chrome.storage.local.remove(older);
    return job;
  }

  async function read(id) {
    if (!validId(id)) throw new Error('missing_report');
    const job = (await chrome.storage.local.get(key(id)))[key(id)];
    if (!job || job.id !== id) throw new Error('missing_report');
    return job;
  }

  const save = job => chrome.storage.local.set({ [key(job.id)]: job });

  // Render only a small Markdown subset with DOM nodes. Model HTML stays literal text.
  function inline(target, text) {
    const pattern = /\*\*([^*\n]+)\*\*/g;
    let from = 0;
    for (const match of text.matchAll(pattern)) {
      target.append(document.createTextNode(text.slice(from, match.index)));
      const strong = document.createElement('strong'); strong.textContent = match[1]; target.append(strong);
      from = match.index + match[0].length;
    }
    target.append(document.createTextNode(text.slice(from)));
  }

  function renderMarkdown(target, markdown) {
    target.replaceChildren();
    let list = null, paragraph = null;
    for (const line of String(markdown).replace(/\r\n?/g, '\n').split('\n')) {
      const trimmed = line.trim();
      if (!trimmed) { list = paragraph = null; continue; }
      const heading = /^(#{1,4})\s+(.+)$/.exec(trimmed);
      const item = /^(?:[-*+]\s+|\d+[.)]\s+)(.+)$/.exec(trimmed);
      if (heading) {
        const el = document.createElement('h' + Math.min(4, Math.max(2, heading[1].length)));
        inline(el, heading[2]); target.append(el); list = paragraph = null;
      } else if (item) {
        const tag = /^\d/.test(trimmed) ? 'OL' : 'UL';
        if (!list || list.tagName !== tag) { list = document.createElement(tag.toLowerCase()); target.append(list); }
        const el = document.createElement('li'); inline(el, item[1]); list.append(el); paragraph = null;
      } else {
        if (!paragraph) { paragraph = document.createElement('p'); target.append(paragraph); }
        else paragraph.append(document.createTextNode('\n'));
        inline(paragraph, line); list = null;
      }
    }
  }

  const escape = value => String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function html(job) {
    const content = document.createElement('div'); renderMarkdown(content, job.report);
    return '<!doctype html>\n<html lang="ru"><head><meta charset="utf-8">' +
      '<meta name="viewport" content="width=device-width,initial-scale=1">' +
      '<meta http-equiv="Content-Security-Policy" content="default-src &#39;none&#39;; style-src &#39;unsafe-inline&#39;">' +
      '<title>Анализ резюме — ' + escape(job.name) + '</title><style>' +
      'body{max-width:850px;margin:40px auto;padding:0 24px;font:16px/1.7 system-ui,sans-serif;color:#1b1f2a}' +
      'h1,h2,h3,h4{line-height:1.3}h2{margin-top:32px}p{white-space:pre-wrap}li{margin:8px 0}' +
      '.meta,footer{color:#616b7c;font-size:14px}footer{border-top:1px solid #ddd;margin-top:40px;padding-top:16px}' +
      '</style></head><body><h1>Анализ резюме</h1><p class="meta">' + escape(job.name) +
      ' · ' + escape(new Date(job.finishedAt).toLocaleString('ru-RU')) + ' · ' + escape(job.modelName || job.model) +
      '</p><main>' + content.innerHTML + '</main><footer>HH Автоотклик · Рекомендации ИИ. ' +
      'Проверьте факты перед изменением резюме.</footer></body></html>';
  }

  return { MAX_CHARS, key, message, validate, create, read, save, renderMarkdown, html };
})();
